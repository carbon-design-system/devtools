/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./App/background/index.js":
/*!*********************************!*\
  !*** ./App/background/index.js ***!
  \*********************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tasks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tasks */ "./App/background/tasks/index.js");

Object(_tasks__WEBPACK_IMPORTED_MODULE_0__["validatePage"])();
Object(_tasks__WEBPACK_IMPORTED_MODULE_0__["injectGrid"])();

/***/ }),

/***/ "./App/background/tasks/index.js":
/*!***************************************!*\
  !*** ./App/background/tasks/index.js ***!
  \***************************************/
/*! exports provided: validatePage, injectGrid */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _validatePage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./validatePage */ "./App/background/tasks/validatePage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "validatePage", function() { return _validatePage__WEBPACK_IMPORTED_MODULE_0__["validatePage"]; });

/* harmony import */ var _injectGrid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./injectGrid */ "./App/background/tasks/injectGrid.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "injectGrid", function() { return _injectGrid__WEBPACK_IMPORTED_MODULE_1__["injectGrid"]; });




/***/ }),

/***/ "./App/background/tasks/injectGrid.js":
/*!********************************************!*\
  !*** ./App/background/tasks/injectGrid.js ***!
  \********************************************/
/*! exports provided: injectGrid */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "injectGrid", function() { return injectGrid; });
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utilities */ "./App/utilities/index.js");
 // prevent multiple inserts

function injectGrid() {
  Object(_utilities__WEBPACK_IMPORTED_MODULE_0__["getMessage"])(function (request) {
    if (request.runningCarbon === true) {
      Object(_utilities__WEBPACK_IMPORTED_MODULE_0__["insertScript"])('/static/inject/index.js');
      Object(_utilities__WEBPACK_IMPORTED_MODULE_0__["insertCSS"])('/static/inject/index.css');
    }
  });
}



/***/ }),

/***/ "./App/background/tasks/validatePage.js":
/*!**********************************************!*\
  !*** ./App/background/tasks/validatePage.js ***!
  \**********************************************/
/*! exports provided: validatePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "validatePage", function() { return validatePage; });
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utilities */ "./App/utilities/index.js");
 // prevent multiple inserts

function validatePage() {
  Object(_utilities__WEBPACK_IMPORTED_MODULE_0__["getMessage"])(function (request, sender, sendResponse) {
    if (request.popup === true) {
      Object(_utilities__WEBPACK_IMPORTED_MODULE_0__["insertScript"])('/static/validate/index.js');
    }
  });
}



/***/ }),

/***/ "./App/utilities/carbonPrefix.js":
/*!***************************************!*\
  !*** ./App/utilities/carbonPrefix.js ***!
  \***************************************/
/*! exports provided: carbonPrefix */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "carbonPrefix", function() { return carbonPrefix; });
var carbonPrefix = 'bx';


/***/ }),

/***/ "./App/utilities/getMessage.js":
/*!*************************************!*\
  !*** ./App/utilities/getMessage.js ***!
  \*************************************/
/*! exports provided: getMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMessage", function() { return getMessage; });
function getMessage(callback) {
  chrome.runtime.onMessage.addListener(callback);
}



/***/ }),

/***/ "./App/utilities/getStorage.js":
/*!*************************************!*\
  !*** ./App/utilities/getStorage.js ***!
  \*************************************/
/*! exports provided: getStorage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getStorage", function() { return getStorage; });
function getStorage(key, callback) {
  chrome.storage.sync.get(key, function (data) {
    if (key) {
      if (data && data[key]) {
        callback(data[key]);
      }
    } else if (key === null) {
      if (data) {
        callback(data);
      }
    }
  });
}



/***/ }),

/***/ "./App/utilities/index.js":
/*!********************************!*\
  !*** ./App/utilities/index.js ***!
  \********************************/
/*! exports provided: getMessage, sendMessage, insertScript, insertCSS, setStorage, getStorage, storageChanged, storageTrueFalse, onCommand, carbonPrefix */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _getMessage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./getMessage */ "./App/utilities/getMessage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getMessage", function() { return _getMessage__WEBPACK_IMPORTED_MODULE_0__["getMessage"]; });

/* harmony import */ var _sendMessage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sendMessage */ "./App/utilities/sendMessage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "sendMessage", function() { return _sendMessage__WEBPACK_IMPORTED_MODULE_1__["sendMessage"]; });

/* harmony import */ var _insertScript__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./insertScript */ "./App/utilities/insertScript.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "insertScript", function() { return _insertScript__WEBPACK_IMPORTED_MODULE_2__["insertScript"]; });

/* harmony import */ var _insertCSS__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./insertCSS */ "./App/utilities/insertCSS.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "insertCSS", function() { return _insertCSS__WEBPACK_IMPORTED_MODULE_3__["insertCSS"]; });

/* harmony import */ var _setStorage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./setStorage */ "./App/utilities/setStorage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "setStorage", function() { return _setStorage__WEBPACK_IMPORTED_MODULE_4__["setStorage"]; });

/* harmony import */ var _getStorage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./getStorage */ "./App/utilities/getStorage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getStorage", function() { return _getStorage__WEBPACK_IMPORTED_MODULE_5__["getStorage"]; });

/* harmony import */ var _storageChanged__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./storageChanged */ "./App/utilities/storageChanged.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "storageChanged", function() { return _storageChanged__WEBPACK_IMPORTED_MODULE_6__["storageChanged"]; });

/* harmony import */ var _storageTrueFalse__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./storageTrueFalse */ "./App/utilities/storageTrueFalse.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "storageTrueFalse", function() { return _storageTrueFalse__WEBPACK_IMPORTED_MODULE_7__["storageTrueFalse"]; });

/* harmony import */ var _onCommand__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./onCommand */ "./App/utilities/onCommand.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "onCommand", function() { return _onCommand__WEBPACK_IMPORTED_MODULE_8__["onCommand"]; });

/* harmony import */ var _carbonPrefix__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./carbonPrefix */ "./App/utilities/carbonPrefix.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "carbonPrefix", function() { return _carbonPrefix__WEBPACK_IMPORTED_MODULE_9__["carbonPrefix"]; });












/***/ }),

/***/ "./App/utilities/insertCSS.js":
/*!************************************!*\
  !*** ./App/utilities/insertCSS.js ***!
  \************************************/
/*! exports provided: insertCSS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "insertCSS", function() { return insertCSS; });
function insertCSS(filepath, callback) {
  chrome.tabs.insertCSS({
    file: filepath
  }, callback);
}



/***/ }),

/***/ "./App/utilities/insertScript.js":
/*!***************************************!*\
  !*** ./App/utilities/insertScript.js ***!
  \***************************************/
/*! exports provided: insertScript */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "insertScript", function() { return insertScript; });
function insertScript(filepath, callback) {
  chrome.tabs.executeScript({
    file: filepath
  }, callback);
}



/***/ }),

/***/ "./App/utilities/onCommand.js":
/*!************************************!*\
  !*** ./App/utilities/onCommand.js ***!
  \************************************/
/*! exports provided: onCommand */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onCommand", function() { return onCommand; });
function onCommand(callback) {
  chrome.commands.onCommand.addListener(callback);
}



/***/ }),

/***/ "./App/utilities/sendMessage.js":
/*!**************************************!*\
  !*** ./App/utilities/sendMessage.js ***!
  \**************************************/
/*! exports provided: sendMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendMessage", function() { return sendMessage; });
function sendMessage(msg, callback) {
  chrome.runtime.sendMessage(msg, callback);
}



/***/ }),

/***/ "./App/utilities/setStorage.js":
/*!*************************************!*\
  !*** ./App/utilities/setStorage.js ***!
  \*************************************/
/*! exports provided: setStorage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setStorage", function() { return setStorage; });
function setStorage(data) {
  if (chrome && chrome.storage && chrome.storage.sync) {
    chrome.storage.sync.set(data);
  }
}



/***/ }),

/***/ "./App/utilities/storageChanged.js":
/*!*****************************************!*\
  !*** ./App/utilities/storageChanged.js ***!
  \*****************************************/
/*! exports provided: storageChanged */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "storageChanged", function() { return storageChanged; });
function storageChanged(callback) {
  chrome.storage.onChanged.addListener(callback);
}



/***/ }),

/***/ "./App/utilities/storageTrueFalse.js":
/*!*******************************************!*\
  !*** ./App/utilities/storageTrueFalse.js ***!
  \*******************************************/
/*! exports provided: storageTrueFalse */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "storageTrueFalse", function() { return storageTrueFalse; });
function storageTrueFalse(data, ifTrue, ifFalse) {
  if (data && (data === true || data.newValue === true)) {
    ifTrue();
  } else if (data && (data === false || data.newValue === false)) {
    ifFalse();
  }
}



/***/ }),

/***/ 2:
/*!***************************************!*\
  !*** multi ./App/background/index.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./App/background/index.js */"./App/background/index.js");


/***/ })

/******/ });
//# sourceMappingURL=index.js.map