/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./App/background/index.js":
/*!*********************************!*\
  !*** ./App/background/index.js ***!
  \*********************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _tasks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tasks */ "./App/background/tasks/index.js");

Object(_tasks__WEBPACK_IMPORTED_MODULE_0__["setBadge"])();
Object(_tasks__WEBPACK_IMPORTED_MODULE_0__["validatePage"])();
Object(_tasks__WEBPACK_IMPORTED_MODULE_0__["injectGrid"])();

/***/ }),

/***/ "./App/background/tasks/index.js":
/*!***************************************!*\
  !*** ./App/background/tasks/index.js ***!
  \***************************************/
/*! exports provided: validatePage, injectGrid, setBadge, createBadge */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _validatePage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./validatePage */ "./App/background/tasks/validatePage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "validatePage", function() { return _validatePage__WEBPACK_IMPORTED_MODULE_0__["validatePage"]; });

/* harmony import */ var _injectGrid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./injectGrid */ "./App/background/tasks/injectGrid.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "injectGrid", function() { return _injectGrid__WEBPACK_IMPORTED_MODULE_1__["injectGrid"]; });

/* harmony import */ var _setBadge__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./setBadge */ "./App/background/tasks/setBadge.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "setBadge", function() { return _setBadge__WEBPACK_IMPORTED_MODULE_2__["setBadge"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createBadge", function() { return _setBadge__WEBPACK_IMPORTED_MODULE_2__["createBadge"]; });





/***/ }),

/***/ "./App/background/tasks/injectGrid.js":
/*!********************************************!*\
  !*** ./App/background/tasks/injectGrid.js ***!
  \********************************************/
/*! exports provided: injectGrid */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "injectGrid", function() { return injectGrid; });
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utilities */ "./App/utilities/index.js");
 // TODO: prevent multiple inserts

function injectGrid() {
  Object(_utilities__WEBPACK_IMPORTED_MODULE_0__["getMessage"])(function (msg, sender) {
    if (msg.runningCarbon) {
      var frameId = msg.ignoreValidation ? 0 : sender.frameId;
      Object(_utilities__WEBPACK_IMPORTED_MODULE_0__["insertScript"])(null, {
        file: '/static/inject/index.js',
        frameId: frameId
      });
      Object(_utilities__WEBPACK_IMPORTED_MODULE_0__["insertCSS"])(null, {
        file: '/static/inject/index.css',
        frameId: frameId
      });
    }
  });
}



/***/ }),

/***/ "./App/background/tasks/setBadge.js":
/*!******************************************!*\
  !*** ./App/background/tasks/setBadge.js ***!
  \******************************************/
/*! exports provided: setBadge, createBadge */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setBadge", function() { return setBadge; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createBadge", function() { return createBadge; });
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utilities */ "./App/utilities/index.js");
/* harmony import */ var _carbon_colors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @carbon/colors */ "./node_modules/@carbon/colors/es/index.js");


var iconColor = '#888D94';

function setBadge() {
  Object(_utilities__WEBPACK_IMPORTED_MODULE_0__["experimentalStatusChanged"])(updateBadgeByRules);
  Object(_utilities__WEBPACK_IMPORTED_MODULE_0__["getExperimentalStatus"])(updateBadgeByRules);
}

function updateBadgeByRules(experimental) {
  var dev = "development" === 'development';

  if (experimental && dev) {
    createBadge('DEV', _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["magenta"][50]);
  } else if (experimental) {
    createBadge('EXP', _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["magenta"][50]);
  } else if (dev) {
    createBadge('DEV', iconColor);
  } else {
    createBadge('', iconColor);
  }
}

function createBadge(text, color) {
  chrome.browserAction.setBadgeText({
    text: text
  });
  chrome.browserAction.setBadgeBackgroundColor({
    color: color
  });
}



/***/ }),

/***/ "./App/background/tasks/validatePage.js":
/*!**********************************************!*\
  !*** ./App/background/tasks/validatePage.js ***!
  \**********************************************/
/*! exports provided: validatePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "validatePage", function() { return validatePage; });
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../utilities */ "./App/utilities/index.js");
 // TODO: prevent multiple inserts
// TODO: Can declarativeContent be used in place of validation scripts? https://developer.chrome.com/extensions/declarativeContent
/// WHEN POP UP IS OPENED VALIDATE PAGE

function validatePage() {
  Object(_utilities__WEBPACK_IMPORTED_MODULE_0__["getMessage"])(function (msg) {
    if (msg.popup) {
      insertValidation();
    }
  });
}

function insertValidation(callback) {
  Object(_utilities__WEBPACK_IMPORTED_MODULE_0__["insertScript"])(null, {
    file: '/static/validate/index.js',
    allFrames: true,
    matchAboutBlank: true
  }, function () {
    if (chrome.runtime.lastError) {
      console.log(chrome.runtime.lastError.message);
    } else if (typeof callback === 'function') {
      callback();
    }
  });
}



/***/ }),

/***/ "./App/utilities/activeTab.js":
/*!************************************!*\
  !*** ./App/utilities/activeTab.js ***!
  \************************************/
/*! exports provided: activeTab */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "activeTab", function() { return activeTab; });
function activeTab(callback) {
  chrome.tabs.query({
    currentWindow: true,
    active: true
  }, function (tabs) {
    return callback(tabs[0]);
  });
}



/***/ }),

/***/ "./App/utilities/experimental.js":
/*!***************************************!*\
  !*** ./App/utilities/experimental.js ***!
  \***************************************/
/*! exports provided: experimentalFlag, setExperimentalStatus, getExperimentalStatus, experimentalStatusChanged */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "experimentalFlag", function() { return experimentalFlag; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setExperimentalStatus", function() { return setExperimentalStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getExperimentalStatus", function() { return getExperimentalStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "experimentalStatusChanged", function() { return experimentalStatusChanged; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/preact/compat/dist/compat.module.js");
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index */ "./App/utilities/index.js");


experimentalStatusChanged(setExperimentalStatus);
getExperimentalStatus(setExperimentalStatus);

function experimentalFlag(inverse, callback) {
  var experimental = window.generalExperimental;

  if (typeof inverse === 'function') {
    callback = inverse;
  } else if (inverse === true) {
    experimental = !window.generalExperimental;
  }

  return experimental ? callback() : null;
}

function setExperimentalStatus(newStatus) {
  window.generalExperimental = newStatus;
}

function getExperimentalStatus(callback) {
  Object(_index__WEBPACK_IMPORTED_MODULE_1__["getStorage"])(['generalExperimental'], function (_ref) {
    var generalExperimental = _ref.generalExperimental;
    callback(generalExperimental);
  });
}

function experimentalStatusChanged(callback) {
  Object(_index__WEBPACK_IMPORTED_MODULE_1__["storageChanged"])('generalExperimental', function (generalExperimental) {
    callback(generalExperimental);
  });
}



/***/ }),

/***/ "./App/utilities/getMessage.js":
/*!*************************************!*\
  !*** ./App/utilities/getMessage.js ***!
  \*************************************/
/*! exports provided: getMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMessage", function() { return getMessage; });
function getMessage(callback) {
  chrome.runtime.onMessage.addListener(callback);
}



/***/ }),

/***/ "./App/utilities/getStorage.js":
/*!*************************************!*\
  !*** ./App/utilities/getStorage.js ***!
  \*************************************/
/*! exports provided: getStorage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getStorage", function() { return getStorage; });
function getStorage(key, callback) {
  chrome.storage.local.get(key, callback);
}



/***/ }),

/***/ "./App/utilities/index.js":
/*!********************************!*\
  !*** ./App/utilities/index.js ***!
  \********************************/
/*! exports provided: getMessage, sendMessage, insertScript, insertCSS, setStorage, getStorage, storageChanged, storageTrueFalse, onCommand, activeTab, onTabUpdated, onTabRemoved, experimentalFlag, setExperimentalStatus, getExperimentalStatus, experimentalStatusChanged, remtopx */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _getMessage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./getMessage */ "./App/utilities/getMessage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getMessage", function() { return _getMessage__WEBPACK_IMPORTED_MODULE_0__["getMessage"]; });

/* harmony import */ var _sendMessage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sendMessage */ "./App/utilities/sendMessage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "sendMessage", function() { return _sendMessage__WEBPACK_IMPORTED_MODULE_1__["sendMessage"]; });

/* harmony import */ var _insertScript__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./insertScript */ "./App/utilities/insertScript.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "insertScript", function() { return _insertScript__WEBPACK_IMPORTED_MODULE_2__["insertScript"]; });

/* harmony import */ var _insertCSS__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./insertCSS */ "./App/utilities/insertCSS.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "insertCSS", function() { return _insertCSS__WEBPACK_IMPORTED_MODULE_3__["insertCSS"]; });

/* harmony import */ var _setStorage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./setStorage */ "./App/utilities/setStorage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "setStorage", function() { return _setStorage__WEBPACK_IMPORTED_MODULE_4__["setStorage"]; });

/* harmony import */ var _getStorage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./getStorage */ "./App/utilities/getStorage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getStorage", function() { return _getStorage__WEBPACK_IMPORTED_MODULE_5__["getStorage"]; });

/* harmony import */ var _storageChanged__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./storageChanged */ "./App/utilities/storageChanged.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "storageChanged", function() { return _storageChanged__WEBPACK_IMPORTED_MODULE_6__["storageChanged"]; });

/* harmony import */ var _storageTrueFalse__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./storageTrueFalse */ "./App/utilities/storageTrueFalse.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "storageTrueFalse", function() { return _storageTrueFalse__WEBPACK_IMPORTED_MODULE_7__["storageTrueFalse"]; });

/* harmony import */ var _onCommand__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./onCommand */ "./App/utilities/onCommand.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "onCommand", function() { return _onCommand__WEBPACK_IMPORTED_MODULE_8__["onCommand"]; });

/* harmony import */ var _activeTab__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./activeTab */ "./App/utilities/activeTab.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "activeTab", function() { return _activeTab__WEBPACK_IMPORTED_MODULE_9__["activeTab"]; });

/* harmony import */ var _onTabUpdated__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./onTabUpdated */ "./App/utilities/onTabUpdated.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "onTabUpdated", function() { return _onTabUpdated__WEBPACK_IMPORTED_MODULE_10__["onTabUpdated"]; });

/* harmony import */ var _onTabRemoved__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./onTabRemoved */ "./App/utilities/onTabRemoved.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "onTabRemoved", function() { return _onTabRemoved__WEBPACK_IMPORTED_MODULE_11__["onTabRemoved"]; });

/* harmony import */ var _experimental__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./experimental */ "./App/utilities/experimental.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "experimentalFlag", function() { return _experimental__WEBPACK_IMPORTED_MODULE_12__["experimentalFlag"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "setExperimentalStatus", function() { return _experimental__WEBPACK_IMPORTED_MODULE_12__["setExperimentalStatus"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getExperimentalStatus", function() { return _experimental__WEBPACK_IMPORTED_MODULE_12__["getExperimentalStatus"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "experimentalStatusChanged", function() { return _experimental__WEBPACK_IMPORTED_MODULE_12__["experimentalStatusChanged"]; });

/* harmony import */ var _remtopx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./remtopx */ "./App/utilities/remtopx.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "remtopx", function() { return _remtopx__WEBPACK_IMPORTED_MODULE_13__["remtopx"]; });
















/***/ }),

/***/ "./App/utilities/insertCSS.js":
/*!************************************!*\
  !*** ./App/utilities/insertCSS.js ***!
  \************************************/
/*! exports provided: insertCSS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "insertCSS", function() { return insertCSS; });
function insertCSS(tabId, details, callback) {
  chrome.tabs.insertCSS(tabId, details, callback);
}



/***/ }),

/***/ "./App/utilities/insertScript.js":
/*!***************************************!*\
  !*** ./App/utilities/insertScript.js ***!
  \***************************************/
/*! exports provided: insertScript */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "insertScript", function() { return insertScript; });
function insertScript(tabId, details, callback) {
  chrome.tabs.executeScript(tabId, details, callback);
}



/***/ }),

/***/ "./App/utilities/onCommand.js":
/*!************************************!*\
  !*** ./App/utilities/onCommand.js ***!
  \************************************/
/*! exports provided: onCommand */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onCommand", function() { return onCommand; });
function onCommand(callback) {
  chrome.commands.onCommand.addListener(callback);
}



/***/ }),

/***/ "./App/utilities/onTabRemoved.js":
/*!***************************************!*\
  !*** ./App/utilities/onTabRemoved.js ***!
  \***************************************/
/*! exports provided: onTabRemoved */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onTabRemoved", function() { return onTabRemoved; });
function onTabRemoved(callback) {
  chrome.tabs.onRemoved.addListener(callback);
}



/***/ }),

/***/ "./App/utilities/onTabUpdated.js":
/*!***************************************!*\
  !*** ./App/utilities/onTabUpdated.js ***!
  \***************************************/
/*! exports provided: onTabUpdated */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onTabUpdated", function() { return onTabUpdated; });
function onTabUpdated(callback) {
  chrome.tabs.onUpdated.addListener(callback);
}



/***/ }),

/***/ "./App/utilities/remtopx.js":
/*!**********************************!*\
  !*** ./App/utilities/remtopx.js ***!
  \**********************************/
/*! exports provided: remtopx */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "remtopx", function() { return remtopx; });
/* harmony import */ var _carbon_layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @carbon/layout */ "./node_modules/@carbon/layout/es/index.js");


function remtopx(rem) {
  return _carbon_layout__WEBPACK_IMPORTED_MODULE_0__["baseFontSize"] * parseFloat(rem);
}



/***/ }),

/***/ "./App/utilities/sendMessage.js":
/*!**************************************!*\
  !*** ./App/utilities/sendMessage.js ***!
  \**************************************/
/*! exports provided: sendMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendMessage", function() { return sendMessage; });
function sendMessage(msg, callback) {
  chrome.runtime.sendMessage(msg, callback);
}



/***/ }),

/***/ "./App/utilities/setStorage.js":
/*!*************************************!*\
  !*** ./App/utilities/setStorage.js ***!
  \*************************************/
/*! exports provided: setStorage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setStorage", function() { return setStorage; });
function setStorage(data) {
  if (chrome && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set(data);
  }
}



/***/ }),

/***/ "./App/utilities/storageChanged.js":
/*!*****************************************!*\
  !*** ./App/utilities/storageChanged.js ***!
  \*****************************************/
/*! exports provided: storageChanged */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "storageChanged", function() { return storageChanged; });
function storageChanged(key, callback) {
  chrome.storage.onChanged.addListener(function (data) {
    if (data && data[key]) {
      callback(data[key].newValue);
    }
  });
}



/***/ }),

/***/ "./App/utilities/storageTrueFalse.js":
/*!*******************************************!*\
  !*** ./App/utilities/storageTrueFalse.js ***!
  \*******************************************/
/*! exports provided: storageTrueFalse */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "storageTrueFalse", function() { return storageTrueFalse; });
function storageTrueFalse(data, ifTrue, ifFalse) {
  if (data && (data === true || data.newValue === true)) {
    ifTrue();
  } else if (data && (data === false || data.newValue === false)) {
    ifFalse();
  }
}



/***/ }),

/***/ "./node_modules/@carbon/colors/es/index.js":
/*!*************************************************!*\
  !*** ./node_modules/@carbon/colors/es/index.js ***!
  \*************************************************/
/*! exports provided: black, black100, white, white0, yellow, yellow30, orange, orange40, red10, red20, red30, red40, red50, red60, red70, red80, red90, red100, red, magenta10, magenta20, magenta30, magenta40, magenta50, magenta60, magenta70, magenta80, magenta90, magenta100, magenta, purple10, purple20, purple30, purple40, purple50, purple60, purple70, purple80, purple90, purple100, purple, blue10, blue20, blue30, blue40, blue50, blue60, blue70, blue80, blue90, blue100, blue, cyan10, cyan20, cyan30, cyan40, cyan50, cyan60, cyan70, cyan80, cyan90, cyan100, cyan, teal10, teal20, teal30, teal40, teal50, teal60, teal70, teal80, teal90, teal100, teal, green10, green20, green30, green40, green50, green60, green70, green80, green90, green100, green, coolGray10, coolGray20, coolGray30, coolGray40, coolGray50, coolGray60, coolGray70, coolGray80, coolGray90, coolGray100, coolGray, gray10, gray20, gray30, gray40, gray50, gray60, gray70, gray80, gray90, gray100, gray, warmGray10, warmGray20, warmGray30, warmGray40, warmGray50, warmGray60, warmGray70, warmGray80, warmGray90, warmGray100, warmGray, yellow20, colors, rgba */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "black", function() { return black; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "black100", function() { return black100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "white", function() { return white; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "white0", function() { return white0; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "yellow", function() { return yellow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "yellow30", function() { return yellow30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orange", function() { return orange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orange40", function() { return orange40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red10", function() { return red10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red20", function() { return red20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red30", function() { return red30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red40", function() { return red40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red50", function() { return red50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red60", function() { return red60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red70", function() { return red70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red80", function() { return red80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red90", function() { return red90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red100", function() { return red100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red", function() { return red; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta10", function() { return magenta10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta20", function() { return magenta20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta30", function() { return magenta30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta40", function() { return magenta40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta50", function() { return magenta50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta60", function() { return magenta60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta70", function() { return magenta70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta80", function() { return magenta80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta90", function() { return magenta90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta100", function() { return magenta100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta", function() { return magenta; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple10", function() { return purple10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple20", function() { return purple20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple30", function() { return purple30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple40", function() { return purple40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple50", function() { return purple50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple60", function() { return purple60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple70", function() { return purple70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple80", function() { return purple80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple90", function() { return purple90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple100", function() { return purple100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple", function() { return purple; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue10", function() { return blue10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue20", function() { return blue20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue30", function() { return blue30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue40", function() { return blue40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue50", function() { return blue50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue60", function() { return blue60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue70", function() { return blue70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue80", function() { return blue80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue90", function() { return blue90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue100", function() { return blue100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue", function() { return blue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan10", function() { return cyan10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan20", function() { return cyan20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan30", function() { return cyan30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan40", function() { return cyan40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan50", function() { return cyan50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan60", function() { return cyan60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan70", function() { return cyan70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan80", function() { return cyan80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan90", function() { return cyan90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan100", function() { return cyan100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan", function() { return cyan; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal10", function() { return teal10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal20", function() { return teal20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal30", function() { return teal30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal40", function() { return teal40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal50", function() { return teal50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal60", function() { return teal60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal70", function() { return teal70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal80", function() { return teal80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal90", function() { return teal90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal100", function() { return teal100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal", function() { return teal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green10", function() { return green10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green20", function() { return green20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green30", function() { return green30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green40", function() { return green40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green50", function() { return green50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green60", function() { return green60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green70", function() { return green70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green80", function() { return green80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green90", function() { return green90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green100", function() { return green100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green", function() { return green; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray10", function() { return coolGray10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray20", function() { return coolGray20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray30", function() { return coolGray30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray40", function() { return coolGray40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray50", function() { return coolGray50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray60", function() { return coolGray60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray70", function() { return coolGray70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray80", function() { return coolGray80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray90", function() { return coolGray90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray100", function() { return coolGray100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray", function() { return coolGray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray10", function() { return gray10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray20", function() { return gray20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray30", function() { return gray30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray40", function() { return gray40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray50", function() { return gray50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray60", function() { return gray60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray70", function() { return gray70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray80", function() { return gray80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray90", function() { return gray90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray100", function() { return gray100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray", function() { return gray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray10", function() { return warmGray10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray20", function() { return warmGray20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray30", function() { return warmGray30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray40", function() { return warmGray40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray50", function() { return warmGray50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray60", function() { return warmGray60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray70", function() { return warmGray70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray80", function() { return warmGray80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray90", function() { return warmGray90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray100", function() { return warmGray100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray", function() { return warmGray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "yellow20", function() { return yellow20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colors", function() { return colors; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rgba", function() { return rgba; });
/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
var black = '#000000';
var black100 = black;
var white = '#ffffff';
var white0 = white;
var yellow = '#f1c21b';
var yellow30 = yellow;
var orange = '#ff832b';
var orange40 = orange;
var red10 = '#fff1f1';
var red20 = '#ffd7d9';
var red30 = '#ffb3b8';
var red40 = '#ff8389';
var red50 = '#fa4d56';
var red60 = '#da1e28';
var red70 = '#a2191f';
var red80 = '#750e13';
var red90 = '#520408';
var red100 = '#2d0709';
var red = {
  10: red10,
  20: red20,
  30: red30,
  40: red40,
  50: red50,
  60: red60,
  70: red70,
  80: red80,
  90: red90,
  100: red100
};
var magenta10 = '#fff0f7';
var magenta20 = '#ffd6e8';
var magenta30 = '#ffafd2';
var magenta40 = '#ff7eb6';
var magenta50 = '#ee5396';
var magenta60 = '#d12771';
var magenta70 = '#9f1853';
var magenta80 = '#740937';
var magenta90 = '#510224';
var magenta100 = '#2a0a18';
var magenta = {
  10: magenta10,
  20: magenta20,
  30: magenta30,
  40: magenta40,
  50: magenta50,
  60: magenta60,
  70: magenta70,
  80: magenta80,
  90: magenta90,
  100: magenta100
};
var purple10 = '#f6f2ff';
var purple20 = '#e8daff';
var purple30 = '#d4bbff';
var purple40 = '#be95ff';
var purple50 = '#a56eff';
var purple60 = '#8a3ffc';
var purple70 = '#6929c4';
var purple80 = '#491d8b';
var purple90 = '#31135e';
var purple100 = '#1c0f30';
var purple = {
  10: purple10,
  20: purple20,
  30: purple30,
  40: purple40,
  50: purple50,
  60: purple60,
  70: purple70,
  80: purple80,
  90: purple90,
  100: purple100
};
var blue10 = '#edf5ff';
var blue20 = '#d0e2ff';
var blue30 = '#a6c8ff';
var blue40 = '#78a9ff';
var blue50 = '#4589ff';
var blue60 = '#0f62fe';
var blue70 = '#0043ce';
var blue80 = '#002d9c';
var blue90 = '#001d6c';
var blue100 = '#001141';
var blue = {
  10: blue10,
  20: blue20,
  30: blue30,
  40: blue40,
  50: blue50,
  60: blue60,
  70: blue70,
  80: blue80,
  90: blue90,
  100: blue100
};
var cyan10 = '#e5f6ff';
var cyan20 = '#bae6ff';
var cyan30 = '#82cfff';
var cyan40 = '#33b1ff';
var cyan50 = '#1192e8';
var cyan60 = '#0072c3';
var cyan70 = '#00539a';
var cyan80 = '#003a6d';
var cyan90 = '#012749';
var cyan100 = '#061727';
var cyan = {
  10: cyan10,
  20: cyan20,
  30: cyan30,
  40: cyan40,
  50: cyan50,
  60: cyan60,
  70: cyan70,
  80: cyan80,
  90: cyan90,
  100: cyan100
};
var teal10 = '#d9fbfb';
var teal20 = '#9ef0f0';
var teal30 = '#3ddbd9';
var teal40 = '#08bdba';
var teal50 = '#009d9a';
var teal60 = '#007d79';
var teal70 = '#005d5d';
var teal80 = '#004144';
var teal90 = '#022b30';
var teal100 = '#081a1c';
var teal = {
  10: teal10,
  20: teal20,
  30: teal30,
  40: teal40,
  50: teal50,
  60: teal60,
  70: teal70,
  80: teal80,
  90: teal90,
  100: teal100
};
var green10 = '#defbe6';
var green20 = '#a7f0ba';
var green30 = '#6fdc8c';
var green40 = '#42be65';
var green50 = '#24a148';
var green60 = '#198038';
var green70 = '#0e6027';
var green80 = '#044317';
var green90 = '#022d0d';
var green100 = '#071908';
var green = {
  10: green10,
  20: green20,
  30: green30,
  40: green40,
  50: green50,
  60: green60,
  70: green70,
  80: green80,
  90: green90,
  100: green100
};
var coolGray10 = '#f2f4f8';
var coolGray20 = '#dde1e6';
var coolGray30 = '#c1c7cd';
var coolGray40 = '#a2a9b0';
var coolGray50 = '#878d96';
var coolGray60 = '#697077';
var coolGray70 = '#4d5358';
var coolGray80 = '#343a3f';
var coolGray90 = '#21272a';
var coolGray100 = '#121619';
var coolGray = {
  10: coolGray10,
  20: coolGray20,
  30: coolGray30,
  40: coolGray40,
  50: coolGray50,
  60: coolGray60,
  70: coolGray70,
  80: coolGray80,
  90: coolGray90,
  100: coolGray100
};
var gray10 = '#f4f4f4';
var gray20 = '#e0e0e0';
var gray30 = '#c6c6c6';
var gray40 = '#a8a8a8';
var gray50 = '#8d8d8d';
var gray60 = '#6f6f6f';
var gray70 = '#525252';
var gray80 = '#393939';
var gray90 = '#262626';
var gray100 = '#161616';
var gray = {
  10: gray10,
  20: gray20,
  30: gray30,
  40: gray40,
  50: gray50,
  60: gray60,
  70: gray70,
  80: gray80,
  90: gray90,
  100: gray100
};
var warmGray10 = '#f7f3f2';
var warmGray20 = '#e5e0df';
var warmGray30 = '#cac5c4';
var warmGray40 = '#ada8a8';
var warmGray50 = '#8f8b8b';
var warmGray60 = '#736f6f';
var warmGray70 = '#565151';
var warmGray80 = '#3c3838';
var warmGray90 = '#272525';
var warmGray100 = '#171414';
var warmGray = {
  10: warmGray10,
  20: warmGray20,
  30: warmGray30,
  40: warmGray40,
  50: warmGray50,
  60: warmGray60,
  70: warmGray70,
  80: warmGray80,
  90: warmGray90,
  100: warmGray100
}; // Deprecated ☠️

var yellow20 = '#fdd13a';
var colors = {
  black: {
    100: black
  },
  blue: blue,
  coolGray: coolGray,
  cyan: cyan,
  gray: gray,
  green: green,
  magenta: magenta,
  orange: {
    40: orange40
  },
  purple: purple,
  red: red,
  teal: teal,
  warmGray: warmGray,
  white: {
    0: white
  },
  yellow: {
    20: yellow20,
    30: yellow30
  }
};

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

/**
 * Parse a given hexcode string into an rgba statement with the given opacity
 * @param {string} hexcode
 * @param {number} opacity
 * @returns {string}
 */
function rgba(hexcode, opacity) {
  var values = [hexcode.substring(1, 3), hexcode.substring(3, 5), hexcode.substring(5, 7)].map(function (string) {
    return parseInt(string, 16);
  });
  return "rgba(".concat(values[0], ", ").concat(values[1], ", ").concat(values[2], ", ").concat(opacity, ")");
}

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */




/***/ }),

/***/ "./node_modules/@carbon/layout/es/index.js":
/*!*************************************************!*\
  !*** ./node_modules/@carbon/layout/es/index.js ***!
  \*************************************************/
/*! exports provided: unstable_tokens, baseFontSize, rem, em, px, breakpoints, breakpointUp, breakpointDown, breakpoint, miniUnit, miniUnits, spacing01, spacing02, spacing03, spacing04, spacing05, spacing06, spacing07, spacing08, spacing09, spacing10, spacing11, spacing12, spacing, fluidSpacing01, fluidSpacing02, fluidSpacing03, fluidSpacing04, fluidSpacing, layout01, layout02, layout03, layout04, layout05, layout06, layout07, layout, container01, container02, container03, container04, container05, container, iconSize01, iconSize02, iconSize */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unstable_tokens", function() { return unstable_tokens; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "baseFontSize", function() { return baseFontSize; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rem", function() { return rem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "em", function() { return em; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "px", function() { return px; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "breakpoints", function() { return breakpoints; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "breakpointUp", function() { return breakpointUp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "breakpointDown", function() { return breakpointDown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "breakpoint", function() { return breakpoint; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "miniUnit", function() { return miniUnit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "miniUnits", function() { return miniUnits; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing01", function() { return spacing01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing02", function() { return spacing02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing03", function() { return spacing03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing04", function() { return spacing04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing05", function() { return spacing05; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing06", function() { return spacing06; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing07", function() { return spacing07; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing08", function() { return spacing08; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing09", function() { return spacing09; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing10", function() { return spacing10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing11", function() { return spacing11; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing12", function() { return spacing12; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing", function() { return spacing; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fluidSpacing01", function() { return fluidSpacing01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fluidSpacing02", function() { return fluidSpacing02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fluidSpacing03", function() { return fluidSpacing03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fluidSpacing04", function() { return fluidSpacing04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fluidSpacing", function() { return fluidSpacing; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout01", function() { return layout01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout02", function() { return layout02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout03", function() { return layout03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout04", function() { return layout04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout05", function() { return layout05; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout06", function() { return layout06; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout07", function() { return layout07; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout", function() { return layout; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "container01", function() { return container01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "container02", function() { return container02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "container03", function() { return container03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "container04", function() { return container04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "container05", function() { return container05; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "container", function() { return container; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "iconSize01", function() { return iconSize01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "iconSize02", function() { return iconSize02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "iconSize", function() { return iconSize; });
/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
var unstable_tokens = [// Spacing
'spacing01', 'spacing02', 'spacing03', 'spacing04', 'spacing05', 'spacing06', 'spacing07', 'spacing08', 'spacing09', 'spacing10', 'spacing11', 'spacing12', // Fluid spacing
'fluidSpacing01', 'fluidSpacing02', 'fluidSpacing03', 'fluidSpacing04', // Layout
'layout01', 'layout02', 'layout03', 'layout04', 'layout05', 'layout06', 'layout07', // Containers
'container01', 'container02', 'container03', 'container04', 'container05', // Icon sizes
'iconSize01', 'iconSize02'];

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
// Default, Use with em() and rem() functions

var baseFontSize = 16;
/**
 * Convert a given px unit to a rem unit
 * @param {number} px
 * @returns {string}
 */

function rem(px) {
  return "".concat(px / baseFontSize, "rem");
}
/**
 * Convert a given px unit to a em unit
 * @param {number} px
 * @returns {string}
 */

function em(px) {
  return "".concat(px / baseFontSize, "em");
}
/**
 * Convert a given px unit to its string representation
 * @param {number} value - number of pixels
 * @returns {string}
 */

function px(value) {
  return "".concat(value, "px");
} // Breakpoint
// Initial map of our breakpoints and their values

var breakpoints = {
  sm: {
    width: rem(320),
    columns: 4,
    margin: '0'
  },
  md: {
    width: rem(672),
    columns: 8,
    margin: rem(16)
  },
  lg: {
    width: rem(1056),
    columns: 16,
    margin: rem(16)
  },
  xlg: {
    width: rem(1312),
    columns: 16,
    margin: rem(16)
  },
  max: {
    width: rem(1584),
    columns: 16,
    margin: rem(24)
  }
};
function breakpointUp(name) {
  return "@media (min-width: ".concat(breakpoints[name].width, ")");
}
function breakpointDown(name) {
  return "@media (max-width: ".concat(breakpoints[name].width, ")");
}
function breakpoint() {
  return breakpointUp.apply(void 0, arguments);
} // Mini-unit

var miniUnit = 8;
function miniUnits(count) {
  return rem(miniUnit * count);
} // Spacing

var spacing01 = miniUnits(0.25);
var spacing02 = miniUnits(0.5);
var spacing03 = miniUnits(1);
var spacing04 = miniUnits(1.5);
var spacing05 = miniUnits(2);
var spacing06 = miniUnits(3);
var spacing07 = miniUnits(4);
var spacing08 = miniUnits(5);
var spacing09 = miniUnits(6);
var spacing10 = miniUnits(8);
var spacing11 = miniUnits(10);
var spacing12 = miniUnits(12);
var spacing = [spacing01, spacing02, spacing03, spacing04, spacing05, spacing06, spacing07, spacing08, spacing09, spacing10, spacing11, spacing12]; // Fluid spacing

var fluidSpacing01 = 0;
var fluidSpacing02 = '2vw';
var fluidSpacing03 = '5vw';
var fluidSpacing04 = '10vw';
var fluidSpacing = [fluidSpacing01, fluidSpacing02, fluidSpacing03, fluidSpacing04]; // Layout

var layout01 = miniUnits(2);
var layout02 = miniUnits(3);
var layout03 = miniUnits(4);
var layout04 = miniUnits(6);
var layout05 = miniUnits(8);
var layout06 = miniUnits(12);
var layout07 = miniUnits(20);
var layout = [layout01, layout02, layout03, layout04, layout05, layout06, layout07]; // Container

var container01 = miniUnits(3);
var container02 = miniUnits(4);
var container03 = miniUnits(5);
var container04 = miniUnits(6);
var container05 = miniUnits(8);
var container = [container01, container02, container03, container04, container05]; // Icon

var iconSize01 = '1rem';
var iconSize02 = '1.25rem';
var iconSize = [iconSize01, iconSize02];




/***/ }),

/***/ "./node_modules/preact/compat/dist/compat.module.js":
/*!**********************************************************!*\
  !*** ./node_modules/preact/compat/dist/compat.module.js ***!
  \**********************************************************/
/*! exports provided: useState, useReducer, useEffect, useLayoutEffect, useRef, useImperativeHandle, useMemo, useCallback, useContext, useDebugValue, useErrorBoundary, createElement, createContext, createRef, Fragment, Component, default, version, Children, render, hydrate, unmountComponentAtNode, createPortal, createFactory, cloneElement, isValidElement, findDOMNode, PureComponent, memo, forwardRef, unstable_batchedUpdates, StrictMode, Suspense, SuspenseList, lazy */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "version", function() { return G; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Children", function() { return F; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return V; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hydrate", function() { return Z; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unmountComponentAtNode", function() { return X; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createPortal", function() { return D; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createFactory", function() { return J; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cloneElement", function() { return Q; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isValidElement", function() { return K; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findDOMNode", function() { return Y; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PureComponent", function() { return E; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "memo", function() { return C; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forwardRef", function() { return k; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unstable_batchedUpdates", function() { return nn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrictMode", function() { return tn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Suspense", function() { return M; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuspenseList", function() { return O; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "lazy", function() { return L; });
/* harmony import */ var preact_hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! preact/hooks */ "./node_modules/preact/hooks/dist/hooks.module.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useState", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useState"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useReducer", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useReducer"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useEffect", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useEffect"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useLayoutEffect", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useLayoutEffect"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useRef", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useRef"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useImperativeHandle", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useImperativeHandle"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useMemo", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useMemo"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useCallback", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useCallback"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useContext", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useContext"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useDebugValue", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useDebugValue"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useErrorBoundary", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useErrorBoundary"]; });

/* harmony import */ var preact__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! preact */ "./node_modules/preact/dist/preact.module.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createElement", function() { return preact__WEBPACK_IMPORTED_MODULE_1__["createElement"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createContext", function() { return preact__WEBPACK_IMPORTED_MODULE_1__["createContext"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createRef", function() { return preact__WEBPACK_IMPORTED_MODULE_1__["createRef"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Fragment", function() { return preact__WEBPACK_IMPORTED_MODULE_1__["Fragment"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Component", function() { return preact__WEBPACK_IMPORTED_MODULE_1__["Component"]; });

function g(n,t){for(var e in t)n[e]=t[e];return n}function w(n,t){for(var e in n)if("__source"!==e&&!(e in t))return!0;for(var r in t)if("__source"!==r&&n[r]!==t[r])return!0;return!1}var E=function(n){var t,e;function r(t){var e;return(e=n.call(this,t)||this).isPureReactComponent=!0,e}return e=n,(t=r).prototype=Object.create(e.prototype),t.prototype.constructor=t,t.__proto__=e,r.prototype.shouldComponentUpdate=function(n,t){return w(this.props,n)||w(this.state,t)},r}(preact__WEBPACK_IMPORTED_MODULE_1__["Component"]);function C(n,t){function e(n){var e=this.props.ref,r=e==n.ref;return!r&&e&&(e.call?e(null):e.current=null),t?!t(this.props,n)||!r:w(this.props,n)}function r(t){return this.shouldComponentUpdate=e,Object(preact__WEBPACK_IMPORTED_MODULE_1__["createElement"])(n,t)}return r.prototype.isReactComponent=!0,r.displayName="Memo("+(n.displayName||n.name)+")",r.t=!0,r}var _=preact__WEBPACK_IMPORTED_MODULE_1__["options"].__b;preact__WEBPACK_IMPORTED_MODULE_1__["options"].__b=function(n){n.type&&n.type.t&&n.ref&&(n.props.ref=n.ref,n.ref=null),_&&_(n)};var A="undefined"!=typeof Symbol&&Symbol.for&&Symbol.for("react.forward_ref")||3911;function k(n){function t(t,e){var r=g({},t);return delete r.ref,n(r,"object"!=typeof(e=t.ref||e)||"current"in e?e:null)}return t.$$typeof=A,t.render=t,t.prototype.isReactComponent=t.t=!0,t.displayName="ForwardRef("+(n.displayName||n.name)+")",t}var R=function(n,t){return n?Object(preact__WEBPACK_IMPORTED_MODULE_1__["toChildArray"])(n).reduce(function(n,e,r){return n.concat(t(e,r))},[]):null},F={map:R,forEach:R,count:function(n){return n?Object(preact__WEBPACK_IMPORTED_MODULE_1__["toChildArray"])(n).length:0},only:function(n){if(1!==(n=Object(preact__WEBPACK_IMPORTED_MODULE_1__["toChildArray"])(n)).length)throw new Error("Children.only() expects only one child.");return n[0]},toArray:preact__WEBPACK_IMPORTED_MODULE_1__["toChildArray"]},N=preact__WEBPACK_IMPORTED_MODULE_1__["options"].__e;function U(n){return n&&((n=g({},n)).__c=null,n.__k=n.__k&&n.__k.map(U)),n}function M(){this.__u=0,this.o=null,this.__b=null}function j(n){var t=n.__.__c;return t&&t.u&&t.u(n)}function L(n){var t,e,r;function o(o){if(t||(t=n()).then(function(n){e=n.default||n},function(n){r=n}),r)throw r;if(!e)throw t;return Object(preact__WEBPACK_IMPORTED_MODULE_1__["createElement"])(e,o)}return o.displayName="Lazy",o.t=!0,o}function O(){this.i=null,this.l=null}preact__WEBPACK_IMPORTED_MODULE_1__["options"].__e=function(n,t,e){if(n.then)for(var r,o=t;o=o.__;)if((r=o.__c)&&r.__c)return r.__c(n,t.__c);N(n,t,e)},(M.prototype=new preact__WEBPACK_IMPORTED_MODULE_1__["Component"]).__c=function(n,t){var e=this;null==e.o&&(e.o=[]),e.o.push(t);var r=j(e.__v),o=!1,u=function(){o||(o=!0,r?r(i):i())};t.__c=t.componentWillUnmount,t.componentWillUnmount=function(){u(),t.__c&&t.__c()};var i=function(){var n;if(!--e.__u)for(e.__v.__k[0]=e.state.u,e.setState({u:e.__b=null});n=e.o.pop();)n.forceUpdate()};e.__u++||e.setState({u:e.__b=e.__v.__k[0]}),n.then(u,u)},M.prototype.render=function(n,t){return this.__b&&(this.__v.__k[0]=U(this.__b),this.__b=null),[Object(preact__WEBPACK_IMPORTED_MODULE_1__["createElement"])(preact__WEBPACK_IMPORTED_MODULE_1__["Fragment"],null,t.u?null:n.children),t.u&&n.fallback]};var P=function(n,t,e){if(++e[1]===e[0]&&n.l.delete(t),n.props.revealOrder&&("t"!==n.props.revealOrder[0]||!n.l.size))for(e=n.i;e;){for(;e.length>3;)e.pop()();if(e[1]<e[0])break;n.i=e=e[2]}};(O.prototype=new preact__WEBPACK_IMPORTED_MODULE_1__["Component"]).u=function(n){var t=this,e=j(t.__v),r=t.l.get(n);return r[0]++,function(o){var u=function(){t.props.revealOrder?(r.push(o),P(t,n,r)):o()};e?e(u):u()}},O.prototype.render=function(n){this.i=null,this.l=new Map;var t=Object(preact__WEBPACK_IMPORTED_MODULE_1__["toChildArray"])(n.children);n.revealOrder&&"b"===n.revealOrder[0]&&t.reverse();for(var e=t.length;e--;)this.l.set(t[e],this.i=[1,0,this.i]);return n.children},O.prototype.componentDidUpdate=O.prototype.componentDidMount=function(){var n=this;n.l.forEach(function(t,e){P(n,e,t)})};var W=function(){function n(){}var t=n.prototype;return t.getChildContext=function(){return this.props.context},t.render=function(n){return n.children},n}();function z(n){var t=this,e=n.container,r=Object(preact__WEBPACK_IMPORTED_MODULE_1__["createElement"])(W,{context:t.context},n.vnode);return t.s&&t.s!==e&&(t.v.parentNode&&t.s.removeChild(t.v),Object(preact__WEBPACK_IMPORTED_MODULE_1__["__u"])(t.h),t.p=!1),n.vnode?t.p?(e.__k=t.__k,Object(preact__WEBPACK_IMPORTED_MODULE_1__["render"])(r,e),t.__k=e.__k):(t.v=document.createTextNode(""),Object(preact__WEBPACK_IMPORTED_MODULE_1__["hydrate"])("",e),e.appendChild(t.v),t.p=!0,t.s=e,Object(preact__WEBPACK_IMPORTED_MODULE_1__["render"])(r,e,t.v),t.__k=t.v.__k):t.p&&(t.v.parentNode&&t.s.removeChild(t.v),Object(preact__WEBPACK_IMPORTED_MODULE_1__["__u"])(t.h)),t.h=r,t.componentWillUnmount=function(){t.v.parentNode&&t.s.removeChild(t.v),Object(preact__WEBPACK_IMPORTED_MODULE_1__["__u"])(t.h)},null}function D(n,t){return Object(preact__WEBPACK_IMPORTED_MODULE_1__["createElement"])(z,{vnode:n,container:t})}var H=/^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|fill|flood|font|glyph(?!R)|horiz|marker(?!H|W|U)|overline|paint|stop|strikethrough|stroke|text(?!L)|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/;preact__WEBPACK_IMPORTED_MODULE_1__["Component"].prototype.isReactComponent={};var T="undefined"!=typeof Symbol&&Symbol.for&&Symbol.for("react.element")||60103;function V(n,t,e){if(null==t.__k)for(;t.firstChild;)t.removeChild(t.firstChild);return Object(preact__WEBPACK_IMPORTED_MODULE_1__["render"])(n,t),"function"==typeof e&&e(),n?n.__c:null}function Z(n,t,e){return Object(preact__WEBPACK_IMPORTED_MODULE_1__["hydrate"])(n,t),"function"==typeof e&&e(),n?n.__c:null}var I=preact__WEBPACK_IMPORTED_MODULE_1__["options"].event;function $(n,t){n["UNSAFE_"+t]&&!n[t]&&Object.defineProperty(n,t,{configurable:!1,get:function(){return this["UNSAFE_"+t]},set:function(n){this["UNSAFE_"+t]=n}})}preact__WEBPACK_IMPORTED_MODULE_1__["options"].event=function(n){I&&(n=I(n)),n.persist=function(){};var t=!1,e=!1,r=n.stopPropagation;n.stopPropagation=function(){r.call(n),t=!0};var o=n.preventDefault;return n.preventDefault=function(){o.call(n),e=!0},n.isPropagationStopped=function(){return t},n.isDefaultPrevented=function(){return e},n.nativeEvent=n};var q={configurable:!0,get:function(){return this.class}},B=preact__WEBPACK_IMPORTED_MODULE_1__["options"].vnode;preact__WEBPACK_IMPORTED_MODULE_1__["options"].vnode=function(n){n.$$typeof=T;var t=n.type,e=n.props;if(t){if(e.class!=e.className&&(q.enumerable="className"in e,null!=e.className&&(e.class=e.className),Object.defineProperty(e,"className",q)),"function"!=typeof t){var r,o,u;for(u in e.defaultValue&&void 0!==e.value&&(e.value||0===e.value||(e.value=e.defaultValue),delete e.defaultValue),Array.isArray(e.value)&&e.multiple&&"select"===t&&(Object(preact__WEBPACK_IMPORTED_MODULE_1__["toChildArray"])(e.children).forEach(function(n){-1!=e.value.indexOf(n.props.value)&&(n.props.selected=!0)}),delete e.value),null!=e.value&&"textarea"===t&&(e.children=e.value,delete e.value),e)if(r=H.test(u))break;if(r)for(u in o=n.props={},e)o[H.test(u)?u.replace(/[A-Z0-9]/,"-$&").toLowerCase():u]=e[u]}!function(t){var e=n.type,r=n.props;if(r&&"string"==typeof e){var o={};for(var u in r)/^on(Ani|Tra|Tou)/.test(u)&&(r[u.toLowerCase()]=r[u],delete r[u]),o[u.toLowerCase()]=u;if(o.ondoubleclick&&(r.ondblclick=r[o.ondoubleclick],delete r[o.ondoubleclick]),o.onbeforeinput&&(r.onbeforeinput=r[o.onbeforeinput],delete r[o.onbeforeinput]),o.onchange&&("textarea"===e||"input"===e.toLowerCase()&&!/^fil|che|ra/i.test(r.type))){var i=o.oninput||"oninput";r[i]||(r[i]=r[o.onchange],delete r[o.onchange])}}}(),"function"==typeof t&&!t.m&&t.prototype&&($(t.prototype,"componentWillMount"),$(t.prototype,"componentWillReceiveProps"),$(t.prototype,"componentWillUpdate"),t.m=!0)}B&&B(n)};var G="16.8.0";function J(n){return preact__WEBPACK_IMPORTED_MODULE_1__["createElement"].bind(null,n)}function K(n){return!!n&&n.$$typeof===T}function Q(n){return K(n)?preact__WEBPACK_IMPORTED_MODULE_1__["cloneElement"].apply(null,arguments):n}function X(n){return!!n.__k&&(Object(preact__WEBPACK_IMPORTED_MODULE_1__["render"])(null,n),!0)}function Y(n){return n&&(n.base||1===n.nodeType&&n)||null}var nn=function(n,t){return n(t)},tn=preact__WEBPACK_IMPORTED_MODULE_1__["Fragment"];/* harmony default export */ __webpack_exports__["default"] = ({useState:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useState"],useReducer:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useReducer"],useEffect:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useEffect"],useLayoutEffect:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useLayoutEffect"],useRef:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useRef"],useImperativeHandle:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useImperativeHandle"],useMemo:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useMemo"],useCallback:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useCallback"],useContext:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useContext"],useDebugValue:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useDebugValue"],version:"16.8.0",Children:F,render:V,hydrate:Z,unmountComponentAtNode:X,createPortal:D,createElement:preact__WEBPACK_IMPORTED_MODULE_1__["createElement"],createContext:preact__WEBPACK_IMPORTED_MODULE_1__["createContext"],createFactory:J,cloneElement:Q,createRef:preact__WEBPACK_IMPORTED_MODULE_1__["createRef"],Fragment:preact__WEBPACK_IMPORTED_MODULE_1__["Fragment"],isValidElement:K,findDOMNode:Y,Component:preact__WEBPACK_IMPORTED_MODULE_1__["Component"],PureComponent:E,memo:C,forwardRef:k,unstable_batchedUpdates:nn,StrictMode:preact__WEBPACK_IMPORTED_MODULE_1__["Fragment"],Suspense:M,SuspenseList:O,lazy:L});
//# sourceMappingURL=compat.module.js.map


/***/ }),

/***/ "./node_modules/preact/dist/preact.module.js":
/*!***************************************************!*\
  !*** ./node_modules/preact/dist/preact.module.js ***!
  \***************************************************/
/*! exports provided: render, hydrate, createElement, h, Fragment, createRef, isValidElement, Component, cloneElement, createContext, toChildArray, __u, options */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return M; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hydrate", function() { return O; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createElement", function() { return v; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return v; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Fragment", function() { return p; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createRef", function() { return y; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isValidElement", function() { return l; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Component", function() { return d; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cloneElement", function() { return S; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createContext", function() { return q; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toChildArray", function() { return b; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__u", function() { return I; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "options", function() { return n; });
var n,l,u,i,t,r,o,f={},e=[],c=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;function s(n,l){for(var u in l)n[u]=l[u];return n}function a(n){var l=n.parentNode;l&&l.removeChild(n)}function v(n,l,u){var i,t=arguments,r={};for(i in l)"key"!==i&&"ref"!==i&&(r[i]=l[i]);if(arguments.length>3)for(u=[u],i=3;i<arguments.length;i++)u.push(t[i]);if(null!=u&&(r.children=u),"function"==typeof n&&null!=n.defaultProps)for(i in n.defaultProps)void 0===r[i]&&(r[i]=n.defaultProps[i]);return h(n,r,l&&l.key,l&&l.ref,null)}function h(l,u,i,t,r){var o={type:l,props:u,key:i,ref:t,__k:null,__:null,__b:0,__e:null,__d:void 0,__c:null,constructor:void 0,__v:r};return null==r&&(o.__v=o),n.vnode&&n.vnode(o),o}function y(){return{current:null}}function p(n){return n.children}function d(n,l){this.props=n,this.context=l}function _(n,l){if(null==l)return n.__?_(n.__,n.__.__k.indexOf(n)+1):null;for(var u;l<n.__k.length;l++)if(null!=(u=n.__k[l])&&null!=u.__e)return u.__e;return"function"==typeof n.type?_(n):null}function k(n){var l,u;if(null!=(n=n.__)&&null!=n.__c){for(n.__e=n.__c.base=null,l=0;l<n.__k.length;l++)if(null!=(u=n.__k[l])&&null!=u.__e){n.__e=n.__c.base=u.__e;break}return k(n)}}function w(l){(!l.__d&&(l.__d=!0)&&u.push(l)&&!m.__r++||t!==n.debounceRendering)&&((t=n.debounceRendering)||i)(m)}function m(){for(var n;m.__r=u.length;)n=u.sort(function(n,l){return n.__v.__b-l.__v.__b}),u=[],n.some(function(n){var l,u,i,t,r,o,f;n.__d&&(o=(r=(l=n).__v).__e,(f=l.__P)&&(u=[],(i=s({},r)).__v=i,t=T(f,r,i,l.__n,void 0!==f.ownerSVGElement,null,u,null==o?_(r):o),$(u,r),t!=o&&k(r)))})}function g(n,l,u,i,t,r,o,c,s,v){var y,d,k,w,m,g,b,A=i&&i.__k||e,P=A.length;for(s==f&&(s=null!=o?o[0]:P?_(i,0):null),u.__k=[],y=0;y<l.length;y++)if(null!=(w=u.__k[y]=null==(w=l[y])||"boolean"==typeof w?null:"string"==typeof w||"number"==typeof w?h(null,w,null,null,w):Array.isArray(w)?h(p,{children:w},null,null,null):null!=w.__e||null!=w.__c?h(w.type,w.props,w.key,null,w.__v):w)){if(w.__=u,w.__b=u.__b+1,null===(k=A[y])||k&&w.key==k.key&&w.type===k.type)A[y]=void 0;else for(d=0;d<P;d++){if((k=A[d])&&w.key==k.key&&w.type===k.type){A[d]=void 0;break}k=null}m=T(n,w,k=k||f,t,r,o,c,s,v),(d=w.ref)&&k.ref!=d&&(b||(b=[]),k.ref&&b.push(k.ref,null,w),b.push(d,w.__c||m,w)),null!=m?(null==g&&(g=m),s=x(n,w,k,A,o,m,s),"option"==u.type?n.value="":"function"==typeof u.type&&(u.__d=s)):s&&k.__e==s&&s.parentNode!=n&&(s=_(k))}if(u.__e=g,null!=o&&"function"!=typeof u.type)for(y=o.length;y--;)null!=o[y]&&a(o[y]);for(y=P;y--;)null!=A[y]&&I(A[y],A[y]);if(b)for(y=0;y<b.length;y++)H(b[y],b[++y],b[++y])}function b(n){return null==n||"boolean"==typeof n?[]:Array.isArray(n)?e.concat.apply([],n.map(b)):[n]}function x(n,l,u,i,t,r,o){var f,e,c;if(void 0!==l.__d)f=l.__d,l.__d=void 0;else if(t==u||r!=o||null==r.parentNode)n:if(null==o||o.parentNode!==n)n.appendChild(r),f=null;else{for(e=o,c=0;(e=e.nextSibling)&&c<i.length;c+=2)if(e==r)break n;n.insertBefore(r,o),f=o}return void 0!==f?f:r.nextSibling}function A(n,l,u,i,t){var r;for(r in u)"children"===r||"key"===r||r in l||C(n,r,null,u[r],i);for(r in l)t&&"function"!=typeof l[r]||"children"===r||"key"===r||"value"===r||"checked"===r||u[r]===l[r]||C(n,r,l[r],u[r],i)}function P(n,l,u){"-"===l[0]?n.setProperty(l,u):n[l]="number"==typeof u&&!1===c.test(l)?u+"px":null==u?"":u}function C(n,l,u,i,t){var r,o,f,e,c;if(t?"className"===l&&(l="class"):"class"===l&&(l="className"),"style"===l)if(r=n.style,"string"==typeof u)r.cssText=u;else{if("string"==typeof i&&(r.cssText="",i=null),i)for(e in i)u&&e in u||P(r,e,"");if(u)for(c in u)i&&u[c]===i[c]||P(r,c,u[c])}else"o"===l[0]&&"n"===l[1]?(o=l!==(l=l.replace(/Capture$/,"")),f=l.toLowerCase(),l=(f in n?f:l).slice(2),u?(i||n.addEventListener(l,N,o),(n.l||(n.l={}))[l]=u):n.removeEventListener(l,N,o)):"list"!==l&&"tagName"!==l&&"form"!==l&&"type"!==l&&"size"!==l&&!t&&l in n?n[l]=null==u?"":u:"function"!=typeof u&&"dangerouslySetInnerHTML"!==l&&(l!==(l=l.replace(/^xlink:?/,""))?null==u||!1===u?n.removeAttributeNS("http://www.w3.org/1999/xlink",l.toLowerCase()):n.setAttributeNS("http://www.w3.org/1999/xlink",l.toLowerCase(),u):null==u||!1===u&&!/^ar/.test(l)?n.removeAttribute(l):n.setAttribute(l,u))}function N(l){this.l[l.type](n.event?n.event(l):l)}function z(n,l,u){var i,t;for(i=0;i<n.__k.length;i++)(t=n.__k[i])&&(t.__=n,t.__e&&("function"==typeof t.type&&t.__k.length>1&&z(t,l,u),l=x(u,t,t,n.__k,null,t.__e,l),"function"==typeof n.type&&(n.__d=l)))}function T(l,u,i,t,r,o,f,e,c){var a,v,h,y,_,k,w,m,b,x,A,P=u.type;if(void 0!==u.constructor)return null;(a=n.__b)&&a(u);try{n:if("function"==typeof P){if(m=u.props,b=(a=P.contextType)&&t[a.__c],x=a?b?b.props.value:a.__:t,i.__c?w=(v=u.__c=i.__c).__=v.__E:("prototype"in P&&P.prototype.render?u.__c=v=new P(m,x):(u.__c=v=new d(m,x),v.constructor=P,v.render=L),b&&b.sub(v),v.props=m,v.state||(v.state={}),v.context=x,v.__n=t,h=v.__d=!0,v.__h=[]),null==v.__s&&(v.__s=v.state),null!=P.getDerivedStateFromProps&&(v.__s==v.state&&(v.__s=s({},v.__s)),s(v.__s,P.getDerivedStateFromProps(m,v.__s))),y=v.props,_=v.state,h)null==P.getDerivedStateFromProps&&null!=v.componentWillMount&&v.componentWillMount(),null!=v.componentDidMount&&v.__h.push(v.componentDidMount);else{if(null==P.getDerivedStateFromProps&&m!==y&&null!=v.componentWillReceiveProps&&v.componentWillReceiveProps(m,x),!v.__e&&null!=v.shouldComponentUpdate&&!1===v.shouldComponentUpdate(m,v.__s,x)||u.__v===i.__v){v.props=m,v.state=v.__s,u.__v!==i.__v&&(v.__d=!1),v.__v=u,u.__e=i.__e,u.__k=i.__k,v.__h.length&&f.push(v),z(u,e,l);break n}null!=v.componentWillUpdate&&v.componentWillUpdate(m,v.__s,x),null!=v.componentDidUpdate&&v.__h.push(function(){v.componentDidUpdate(y,_,k)})}v.context=x,v.props=m,v.state=v.__s,(a=n.__r)&&a(u),v.__d=!1,v.__v=u,v.__P=l,a=v.render(v.props,v.state,v.context),v.state=v.__s,null!=v.getChildContext&&(t=s(s({},t),v.getChildContext())),h||null==v.getSnapshotBeforeUpdate||(k=v.getSnapshotBeforeUpdate(y,_)),A=null!=a&&a.type==p&&null==a.key?a.props.children:a,g(l,Array.isArray(A)?A:[A],u,i,t,r,o,f,e,c),v.base=u.__e,v.__h.length&&f.push(v),w&&(v.__E=v.__=null),v.__e=!1}else null==o&&u.__v===i.__v?(u.__k=i.__k,u.__e=i.__e):u.__e=j(i.__e,u,i,t,r,o,f,c);(a=n.diffed)&&a(u)}catch(l){u.__v=null,n.__e(l,u,i)}return u.__e}function $(l,u){n.__c&&n.__c(u,l),l.some(function(u){try{l=u.__h,u.__h=[],l.some(function(n){n.call(u)})}catch(l){n.__e(l,u.__v)}})}function j(n,l,u,i,t,r,o,c){var s,a,v,h,y,p=u.props,d=l.props;if(t="svg"===l.type||t,null!=r)for(s=0;s<r.length;s++)if(null!=(a=r[s])&&((null===l.type?3===a.nodeType:a.localName===l.type)||n==a)){n=a,r[s]=null;break}if(null==n){if(null===l.type)return document.createTextNode(d);n=t?document.createElementNS("http://www.w3.org/2000/svg",l.type):document.createElement(l.type,d.is&&{is:d.is}),r=null,c=!1}if(null===l.type)p!==d&&n.data!=d&&(n.data=d);else{if(null!=r&&(r=e.slice.call(n.childNodes)),v=(p=u.props||f).dangerouslySetInnerHTML,h=d.dangerouslySetInnerHTML,!c){if(null!=r)for(p={},y=0;y<n.attributes.length;y++)p[n.attributes[y].name]=n.attributes[y].value;(h||v)&&(h&&v&&h.__html==v.__html||(n.innerHTML=h&&h.__html||""))}A(n,d,p,t,c),h?l.__k=[]:(s=l.props.children,g(n,Array.isArray(s)?s:[s],l,u,i,"foreignObject"!==l.type&&t,r,o,f,c)),c||("value"in d&&void 0!==(s=d.value)&&s!==n.value&&C(n,"value",s,p.value,!1),"checked"in d&&void 0!==(s=d.checked)&&s!==n.checked&&C(n,"checked",s,p.checked,!1))}return n}function H(l,u,i){try{"function"==typeof l?l(u):l.current=u}catch(l){n.__e(l,i)}}function I(l,u,i){var t,r,o;if(n.unmount&&n.unmount(l),(t=l.ref)&&(t.current&&t.current!==l.__e||H(t,null,u)),i||"function"==typeof l.type||(i=null!=(r=l.__e)),l.__e=l.__d=void 0,null!=(t=l.__c)){if(t.componentWillUnmount)try{t.componentWillUnmount()}catch(l){n.__e(l,u)}t.base=t.__P=null}if(t=l.__k)for(o=0;o<t.length;o++)t[o]&&I(t[o],u,i);null!=r&&a(r)}function L(n,l,u){return this.constructor(n,u)}function M(l,u,i){var t,o,c;n.__&&n.__(l,u),o=(t=i===r)?null:i&&i.__k||u.__k,l=v(p,null,[l]),c=[],T(u,(t?u:i||u).__k=l,o||f,f,void 0!==u.ownerSVGElement,i&&!t?[i]:o?null:u.childNodes.length?e.slice.call(u.childNodes):null,c,i||f,t),$(c,l)}function O(n,l){M(n,l,r)}function S(n,l){var u,i;for(i in l=s(s({},n.props),l),arguments.length>2&&(l.children=e.slice.call(arguments,2)),u={},l)"key"!==i&&"ref"!==i&&(u[i]=l[i]);return h(n.type,u,l.key||n.key,l.ref||n.ref,null)}function q(n){var l={},u={__c:"__cC"+o++,__:n,Consumer:function(n,l){return n.children(l)},Provider:function(n){var i,t=this;return this.getChildContext||(i=[],this.getChildContext=function(){return l[u.__c]=t,l},this.shouldComponentUpdate=function(n){t.props.value!==n.value&&i.some(function(l){l.context=n.value,w(l)})},this.sub=function(n){i.push(n);var l=n.componentWillUnmount;n.componentWillUnmount=function(){i.splice(i.indexOf(n),1),l&&l.call(n)}}),n.children}};return u.Consumer.contextType=u,u.Provider.__=u,u}n={__e:function(n,l){for(var u,i;l=l.__;)if((u=l.__c)&&!u.__)try{if(u.constructor&&null!=u.constructor.getDerivedStateFromError&&(i=!0,u.setState(u.constructor.getDerivedStateFromError(n))),null!=u.componentDidCatch&&(i=!0,u.componentDidCatch(n)),i)return w(u.__E=u)}catch(l){n=l}throw n}},l=function(n){return null!=n&&void 0===n.constructor},d.prototype.setState=function(n,l){var u;u=this.__s!==this.state?this.__s:this.__s=s({},this.state),"function"==typeof n&&(n=n(u,this.props)),n&&s(u,n),null!=n&&this.__v&&(l&&this.__h.push(l),w(this))},d.prototype.forceUpdate=function(n){this.__v&&(this.__e=!0,n&&this.__h.push(n),w(this))},d.prototype.render=p,u=[],i="function"==typeof Promise?Promise.prototype.then.bind(Promise.resolve()):setTimeout,m.__r=0,r=f,o=0;
//# sourceMappingURL=preact.module.js.map


/***/ }),

/***/ "./node_modules/preact/hooks/dist/hooks.module.js":
/*!********************************************************!*\
  !*** ./node_modules/preact/hooks/dist/hooks.module.js ***!
  \********************************************************/
/*! exports provided: useState, useReducer, useEffect, useLayoutEffect, useRef, useImperativeHandle, useMemo, useCallback, useContext, useDebugValue, useErrorBoundary */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useState", function() { return m; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useReducer", function() { return p; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useEffect", function() { return y; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useLayoutEffect", function() { return l; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useRef", function() { return h; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useImperativeHandle", function() { return s; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useMemo", function() { return _; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useCallback", function() { return A; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useContext", function() { return F; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useDebugValue", function() { return T; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useErrorBoundary", function() { return d; });
/* harmony import */ var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! preact */ "./node_modules/preact/dist/preact.module.js");
var t,u,r,o=0,i=[],c=preact__WEBPACK_IMPORTED_MODULE_0__["options"].__r,f=preact__WEBPACK_IMPORTED_MODULE_0__["options"].diffed,e=preact__WEBPACK_IMPORTED_MODULE_0__["options"].__c,a=preact__WEBPACK_IMPORTED_MODULE_0__["options"].unmount;function v(t,r){preact__WEBPACK_IMPORTED_MODULE_0__["options"].__h&&preact__WEBPACK_IMPORTED_MODULE_0__["options"].__h(u,t,o||r),o=0;var i=u.__H||(u.__H={__:[],__h:[]});return t>=i.__.length&&i.__.push({}),i.__[t]}function m(n){return o=1,p(k,n)}function p(n,r,o){var i=v(t++,2);return i.t=n,i.__c||(i.__c=u,i.__=[o?o(r):k(void 0,r),function(n){var t=i.t(i.__[0],n);i.__[0]!==t&&(i.__=[t,i.__[1]],i.__c.setState({}))}]),i.__}function y(r,o){var i=v(t++,3);!preact__WEBPACK_IMPORTED_MODULE_0__["options"].__s&&j(i.__H,o)&&(i.__=r,i.__H=o,u.__H.__h.push(i))}function l(r,o){var i=v(t++,4);!preact__WEBPACK_IMPORTED_MODULE_0__["options"].__s&&j(i.__H,o)&&(i.__=r,i.__H=o,u.__h.push(i))}function h(n){return o=5,_(function(){return{current:n}},[])}function s(n,t,u){o=6,l(function(){"function"==typeof n?n(t()):n&&(n.current=t())},null==u?u:u.concat(n))}function _(n,u){var r=v(t++,7);return j(r.__H,u)?(r.__H=u,r.__h=n,r.__=n()):r.__}function A(n,t){return o=8,_(function(){return n},t)}function F(n){var r=u.context[n.__c],o=v(t++,9);return o.__c=n,r?(null==o.__&&(o.__=!0,r.sub(u)),r.props.value):n.__}function T(t,u){preact__WEBPACK_IMPORTED_MODULE_0__["options"].useDebugValue&&preact__WEBPACK_IMPORTED_MODULE_0__["options"].useDebugValue(u?u(t):t)}function d(n){var r=v(t++,10),o=m();return r.__=n,u.componentDidCatch||(u.componentDidCatch=function(n){r.__&&r.__(n),o[1](n)}),[o[0],function(){o[1](void 0)}]}function q(){i.some(function(t){if(t.__P)try{t.__H.__h.forEach(b),t.__H.__h.forEach(g),t.__H.__h=[]}catch(u){return t.__H.__h=[],preact__WEBPACK_IMPORTED_MODULE_0__["options"].__e(u,t.__v),!0}}),i=[]}preact__WEBPACK_IMPORTED_MODULE_0__["options"].__r=function(n){c&&c(n),t=0;var r=(u=n.__c).__H;r&&(r.__h.forEach(b),r.__h.forEach(g),r.__h=[])},preact__WEBPACK_IMPORTED_MODULE_0__["options"].diffed=function(t){f&&f(t);var u=t.__c;u&&u.__H&&u.__H.__h.length&&(1!==i.push(u)&&r===preact__WEBPACK_IMPORTED_MODULE_0__["options"].requestAnimationFrame||((r=preact__WEBPACK_IMPORTED_MODULE_0__["options"].requestAnimationFrame)||function(n){var t,u=function(){clearTimeout(r),x&&cancelAnimationFrame(t),setTimeout(n)},r=setTimeout(u,100);x&&(t=requestAnimationFrame(u))})(q))},preact__WEBPACK_IMPORTED_MODULE_0__["options"].__c=function(t,u){u.some(function(t){try{t.__h.forEach(b),t.__h=t.__h.filter(function(n){return!n.__||g(n)})}catch(r){u.some(function(n){n.__h&&(n.__h=[])}),u=[],preact__WEBPACK_IMPORTED_MODULE_0__["options"].__e(r,t.__v)}}),e&&e(t,u)},preact__WEBPACK_IMPORTED_MODULE_0__["options"].unmount=function(t){a&&a(t);var u=t.__c;if(u&&u.__H)try{u.__H.__.forEach(b)}catch(t){preact__WEBPACK_IMPORTED_MODULE_0__["options"].__e(t,u.__v)}};var x="function"==typeof requestAnimationFrame;function b(n){"function"==typeof n.u&&n.u()}function g(n){n.u=n.__()}function j(n,t){return!n||t.some(function(t,u){return t!==n[u]})}function k(n,t){return"function"==typeof t?t(n):t}
//# sourceMappingURL=hooks.module.js.map


/***/ }),

/***/ 2:
/*!***************************************!*\
  !*** multi ./App/background/index.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./App/background/index.js */"./App/background/index.js");


/***/ })

/******/ });
//# sourceMappingURL=index.js.map