/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 4);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./App/globals/carbonPrefix.js":
/*!*************************************!*\
  !*** ./App/globals/carbonPrefix.js ***!
  \*************************************/
/*! exports provided: carbonPrefix */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "carbonPrefix", function() { return carbonPrefix; });
var carbonPrefix = 'bx';


/***/ }),

/***/ "./App/globals/gridVersions.js":
/*!*************************************!*\
  !*** ./App/globals/gridVersions.js ***!
  \*************************************/
/*! exports provided: gridVersions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gridVersions", function() { return gridVersions; });
var gridVersions = {
  "carbon-v10": 'Carbon v10',
  "carbon-v9": 'Carbon v9' // "northstar-fluid": 'Northstar fluid',
  // "northstar-v19a": 'Northstar fluid v19a',
  // "northstar-adaptive": 'Northstar adaptive'

};


/***/ }),

/***/ "./App/globals/index.js":
/*!******************************!*\
  !*** ./App/globals/index.js ***!
  \******************************/
/*! exports provided: carbonPrefix, gridVersions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _carbonPrefix__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./carbonPrefix */ "./App/globals/carbonPrefix.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "carbonPrefix", function() { return _carbonPrefix__WEBPACK_IMPORTED_MODULE_0__["carbonPrefix"]; });

/* harmony import */ var _gridVersions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./gridVersions */ "./App/globals/gridVersions.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "gridVersions", function() { return _gridVersions__WEBPACK_IMPORTED_MODULE_1__["gridVersions"]; });




/***/ }),

/***/ "./App/inject/components/Grid/2x/index.js":
/*!************************************************!*\
  !*** ./App/inject/components/Grid/2x/index.js ***!
  \************************************************/
/*! exports provided: manage2xGrid */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "manage2xGrid", function() { return manage2xGrid; });
/* harmony import */ var carbon_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! carbon-components */ "./node_modules/carbon-components/es/index.js");
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../utilities */ "./App/utilities/index.js");


var prefix = carbon_components__WEBPACK_IMPORTED_MODULE_0__["settings"].prefix;

function manage2xGrid() {
  Object(_utilities__WEBPACK_IMPORTED_MODULE_1__["getStorage"])('toggle2xGridOptions', function (_ref) {
    var toggle2xGridOptions = _ref.toggle2xGridOptions;
    return manage2xGridOptions(toggle2xGridOptions);
  }); // set based on defaults

  Object(_utilities__WEBPACK_IMPORTED_MODULE_1__["storageChanged"])('toggle2xGridOptions', manage2xGridOptions); // update ui if options change
}

function manage2xGridOptions(_ref2) {
  var toggle2xColumns = _ref2.toggle2xColumns,
      toggle2xGutters = _ref2.toggle2xGutters,
      toggle2xBorders = _ref2.toggle2xBorders,
      toggle2xFullWidth = _ref2.toggle2xFullWidth,
      toggle2xBreakpoints = _ref2.toggle2xBreakpoints,
      toggle2xColumnLabel = _ref2.toggle2xColumnLabel,
      toggle2xLeftInfluencer = _ref2.toggle2xLeftInfluencer,
      toggle2xRightInfluencer = _ref2.toggle2xRightInfluencer;
  var html = document.querySelector('html');
  var grid2x = html.querySelector(".".concat(prefix, "--grid-2x")); // set grid influencers

  grid2x.style.paddingLeft = "".concat(toggle2xLeftInfluencer || 0, "px");
  grid2x.style.paddingRight = "".concat(toggle2xRightInfluencer || 0, "px"); // hide or show columns

  if (toggle2xColumns) {
    grid2x.classList.add("".concat(prefix, "--grid-2x--inner"));
  } else {
    grid2x.classList.remove("".concat(prefix, "--grid-2x--inner"));
  } // hide or show gutters


  if (toggle2xGutters) {
    grid2x.classList.add("".concat(prefix, "--grid-2x--outer"));
  } else {
    grid2x.classList.remove("".concat(prefix, "--grid-2x--outer"));
  } // hide or show borders/dividers


  if (toggle2xBorders) {
    grid2x.classList.add("".concat(prefix, "--grid-2x--inner-border"), "".concat(prefix, "--grid-2x--outer-border"));
  } else {
    grid2x.classList.remove("".concat(prefix, "--grid-2x--inner-border"), "".concat(prefix, "--grid-2x--outer-border"));
  } // toggle between full width and max-width modifier


  if (toggle2xFullWidth) {
    grid2x.querySelector(".".concat(prefix, "--grid")).classList.add("".concat(prefix, "--grid--full-width"));
  } else {
    grid2x.querySelector(".".concat(prefix, "--grid")).classList.remove("".concat(prefix, "--grid--full-width"));
  } // hide or show breakpoint label


  if (toggle2xBreakpoints) {
    html.classList.add("".concat(prefix, "--grid-2x--breakpoint-label"));
  } else {
    html.classList.remove("".concat(prefix, "--grid-2x--breakpoint-label"));
  } // this shouldn't be here?
  // toggle on or off column identifier by hover


  if (toggle2xColumnLabel) {
    html.classList.add("".concat(prefix, "--grid--hover"));
  } else {
    html.classList.remove("".concat(prefix, "--grid--hover"));
  }
}



/***/ }),

/***/ "./App/inject/components/Grid/column-label/index.js":
/*!**********************************************************!*\
  !*** ./App/inject/components/Grid/column-label/index.js ***!
  \**********************************************************/
/*! exports provided: manageColumnLabel, labelInjector, injectLabels */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "manageColumnLabel", function() { return manageColumnLabel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "labelInjector", function() { return labelInjector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "injectLabels", function() { return injectLabels; });
/* harmony import */ var carbon_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! carbon-components */ "./node_modules/carbon-components/es/index.js");
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../utilities */ "./App/utilities/index.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../globals */ "./App/globals/index.js");
/* harmony import */ var _isHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./isHeader */ "./App/inject/components/Grid/column-label/isHeader.js");




var prefix = carbon_components__WEBPACK_IMPORTED_MODULE_0__["settings"].prefix;

function manageColumnLabel(result) {
  var html = document.querySelector('html'); // toggle on or off column identifier by hover

  Object(_utilities__WEBPACK_IMPORTED_MODULE_1__["storageTrueFalse"])(result.toggle2xHoverState, function () {
    html.classList.add("".concat(prefix, "--grid--hover"));
  }, function () {
    html.classList.remove("".concat(prefix, "--grid--hover"));
  });
}

function labelInjector() {
  var body = document.querySelector('body');
  var columns = document.querySelectorAll("[class*=\"".concat(_globals__WEBPACK_IMPORTED_MODULE_2__["carbonPrefix"], "--col\"]"));
  injectLabels(columns, true); // initial injection

  var DOMwatch = new MutationObserver(function (mutationList) {
    mutationList.forEach(function (mutation) {
      if (mutation.type === 'childList') {
        injectLabels(mutation.addedNodes); // inject if anymore are added

        Object(_isHeader__WEBPACK_IMPORTED_MODULE_3__["isHeader"])();
      }
    });
  });
  DOMwatch.observe(body, {
    childList: true,
    attributes: false,
    subtree: true
  });
}

function injectLabels(nodes, pure) {
  nodes.forEach(function (node) {
    if (node.nodeType === 1) {
      var classes = node.getAttribute("class");
      var labelClassName = "".concat(prefix, "--label-column"); // don't keep looking if we know we have everything

      if (!pure) {
        var columns = node.querySelectorAll("[class*=\"".concat(_globals__WEBPACK_IMPORTED_MODULE_2__["carbonPrefix"], "--col\"]"));

        if (columns.length === 0) {
          return null; // kill function and do nothing
        }

        injectLabels(columns, true); // restart looking at found children
      }

      if (classes && classes.indexOf("".concat(_globals__WEBPACK_IMPORTED_MODULE_2__["carbonPrefix"], "--col")) > -1) {
        var label = node.querySelector(".".concat(labelClassName));

        if (!label) {
          // add label if it doesn't already exist
          label = document.createElement('div');
          label.classList.add(labelClassName);
          node.append(label);
        }
      }
    }
  });
}



/***/ }),

/***/ "./App/inject/components/Grid/column-label/isHeader.js":
/*!*************************************************************!*\
  !*** ./App/inject/components/Grid/column-label/isHeader.js ***!
  \*************************************************************/
/*! exports provided: isHeader */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isHeader", function() { return isHeader; });
/* harmony import */ var carbon_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! carbon-components */ "./node_modules/carbon-components/es/index.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../globals */ "./App/globals/index.js");


var prefix = carbon_components__WEBPACK_IMPORTED_MODULE_0__["settings"].prefix;

function isHeader() {
  var html = document.querySelector("html");
  var header = html.querySelector(".".concat(_globals__WEBPACK_IMPORTED_MODULE_1__["carbonPrefix"], "--header"));

  if (header) {
    html.classList.add("".concat(prefix, "--header"));
  } else {
    html.classList.remove("".concat(prefix, "--header"));
  }
}



/***/ }),

/***/ "./App/inject/components/Grid/index.js":
/*!*********************************************!*\
  !*** ./App/inject/components/Grid/index.js ***!
  \*********************************************/
/*! exports provided: initGrid */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initGrid", function() { return initGrid; });
/* harmony import */ var carbon_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! carbon-components */ "./node_modules/carbon-components/es/index.js");
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../utilities */ "./App/utilities/index.js");
/* harmony import */ var _globals__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../globals */ "./App/globals/index.js");
/* harmony import */ var _2x__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./2x */ "./App/inject/components/Grid/2x/index.js");
/* harmony import */ var _mini_unit__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./mini-unit */ "./App/inject/components/Grid/mini-unit/index.js");
/* harmony import */ var _column_label__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./column-label */ "./App/inject/components/Grid/column-label/index.js");
/* harmony import */ var _carbon_themes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @carbon/themes */ "./node_modules/@carbon/themes/es/index.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }








var prefix = carbon_components__WEBPACK_IMPORTED_MODULE_0__["settings"].prefix;
var html = document.querySelector('html');
var gridVersionsList = Object.keys(_globals__WEBPACK_IMPORTED_MODULE_2__["gridVersions"]);
var themeList = Object.keys(_carbon_themes__WEBPACK_IMPORTED_MODULE_6__["themes"]);
var lastTheme = '';
var lastGridVersion = '';

function initGrid() {
  var body = html.querySelector('body');
  var gridContainerClassName = "".concat(prefix, "--grid-container");
  var numOfColumns = 16;
  var columns = [];
  var gridContainer = body.querySelector(".".concat(gridContainerClassName));
  html.classList.add("".concat(prefix, "--grid--hide"));

  for (var i = 0; i < numOfColumns; i++) {
    columns.push("<div class=\"".concat(prefix, "--col-sm-1 ").concat(prefix, "--col-md-1 ").concat(prefix, "--col-lg-1\"></div>"));
  }

  var GRID_HTML = "\n        <div class=\"".concat(prefix, "--grid-2x\">\n            <div class=\"").concat(prefix, "--grid\">\n                <div class=\"").concat(prefix, "--row\">\n                    ").concat(columns.join(''), "\n                </div>\n            </div>\n        </div>\n        <div class=\"").concat(prefix, "--grid-mini-unit ").concat(prefix, "--grid-mini-unit--hide\"></div>");

  if (!gridContainer) {
    gridContainer = document.createElement('div');
    gridContainer.classList.add(gridContainerClassName);
    gridContainer.innerHTML = GRID_HTML;
    body.appendChild(gridContainer);
  } // updates based sets defaults


  Object(_column_label__WEBPACK_IMPORTED_MODULE_5__["labelInjector"])(); // updates if storage changes

  manageGlobals();
  Object(_2x__WEBPACK_IMPORTED_MODULE_3__["manage2xGrid"])();
  Object(_mini_unit__WEBPACK_IMPORTED_MODULE_4__["manageMiniUnitGrid"])();
}

function manageGlobals() {
  var grid2x = html.querySelector(".".concat(prefix, "--grid-2x"));
  var miniUnitGrid = document.querySelector(".".concat(prefix, "--grid-mini-unit"));
  Object(_utilities__WEBPACK_IMPORTED_MODULE_1__["getStorage"])('globalToggleStates', function (_ref) {
    var globalToggleStates = _ref.globalToggleStates;
    return manageGlobalToggle(globalToggleStates);
  });
  Object(_utilities__WEBPACK_IMPORTED_MODULE_1__["storageChanged"])('globalToggleStates', manageGlobalToggle);
  Object(_utilities__WEBPACK_IMPORTED_MODULE_1__["getStorage"])('toggleGrids', function (_ref2) {
    var toggleGrids = _ref2.toggleGrids;
    return manageGrids(toggleGrids);
  });
  Object(_utilities__WEBPACK_IMPORTED_MODULE_1__["storageChanged"])('toggleGrids', manageGrids);
  Object(_utilities__WEBPACK_IMPORTED_MODULE_1__["getStorage"])('generalTheme', function (_ref3) {
    var generalTheme = _ref3.generalTheme;
    return manageGeneralTheme(generalTheme);
  });
  Object(_utilities__WEBPACK_IMPORTED_MODULE_1__["storageChanged"])('generalTheme', manageGeneralTheme);
  Object(_utilities__WEBPACK_IMPORTED_MODULE_1__["getStorage"])('gridVersion', function (_ref4) {
    var gridVersion = _ref4.gridVersion;
    return manageGridVersion(gridVersion);
  });
  Object(_utilities__WEBPACK_IMPORTED_MODULE_1__["storageChanged"])('gridVersion', manageGridVersion);

  function manageGlobalToggle(_ref5) {
    var gridoverlay = _ref5.gridoverlay;

    // this may not belong here?
    if (gridoverlay) {
      html.classList.remove("".concat(prefix, "--grid--hide"));
    } else {
      html.classList.add("".concat(prefix, "--grid--hide"));
    }
  }

  function manageGrids(_ref6) {
    var toggle2xGrid = _ref6.toggle2xGrid,
        toggleMiniUnitGrid = _ref6.toggleMiniUnitGrid;

    // hide and show 2x grid
    if (toggle2xGrid) {
      html.classList.remove("".concat(prefix, "--grid--hide-label-column"));
      grid2x.classList.remove("".concat(prefix, "--grid-2x--hide"));
    } else {
      html.classList.add("".concat(prefix, "--grid--hide-label-column"));
      grid2x.classList.add("".concat(prefix, "--grid-2x--hide"));
    } // show or hide mini unit grid


    if (toggleMiniUnitGrid) {
      miniUnitGrid.classList.remove("".concat(prefix, "--grid-mini-unit--hide"));
    } else {
      miniUnitGrid.classList.add("".concat(prefix, "--grid-mini-unit--hide"));
    }
  }

  function manageGeneralTheme() {
    var generalTheme = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'g90';

    if (generalTheme !== lastTheme) {
      var _grid2x$classList;

      (_grid2x$classList = grid2x.classList).remove.apply(_grid2x$classList, _toConsumableArray(themeList.map(function (theme) {
        return "".concat(prefix, "--grid-2x--").concat(theme);
      }))); // remove any first


      grid2x.classList.add("".concat(prefix, "--grid-2x--").concat(generalTheme)); // set updated theme

      lastTheme = generalTheme;
    }
  }

  function manageGridVersion() {
    var gridVersion = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'carbon-v10';

    if (gridVersion !== lastGridVersion) {
      var _html$classList;

      (_html$classList = html.classList).remove.apply(_html$classList, _toConsumableArray(gridVersionsList.map(function (version) {
        return "".concat(prefix, "--grid--").concat(version);
      }))); // remove any first


      html.classList.add("".concat(prefix, "--grid--").concat(gridVersion)); // set updated theme

      lastTheme = gridVersion;
    }
  }
}



/***/ }),

/***/ "./App/inject/components/Grid/mini-unit/index.js":
/*!*******************************************************!*\
  !*** ./App/inject/components/Grid/mini-unit/index.js ***!
  \*******************************************************/
/*! exports provided: manageMiniUnitGrid */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "manageMiniUnitGrid", function() { return manageMiniUnitGrid; });
/* harmony import */ var carbon_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! carbon-components */ "./node_modules/carbon-components/es/index.js");
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../utilities */ "./App/utilities/index.js");


var prefix = carbon_components__WEBPACK_IMPORTED_MODULE_0__["settings"].prefix;

function manageMiniUnitGrid() {
  Object(_utilities__WEBPACK_IMPORTED_MODULE_1__["getStorage"])('toggleMiniUnitGridOptions', function (_ref) {
    var toggleMiniUnitGridOptions = _ref.toggleMiniUnitGridOptions;
    return manageMiniUnitGridOptions(toggleMiniUnitGridOptions);
  }); // set based on defaults

  Object(_utilities__WEBPACK_IMPORTED_MODULE_1__["storageChanged"])('toggleMiniUnitGridOptions', manageMiniUnitGridOptions); // update ui if options change
}

function manageMiniUnitGridOptions(_ref2) {
  var miniUnitCells = _ref2.miniUnitCells,
      miniUnitFix = _ref2.miniUnitFix,
      miniUnitVerticalBorders = _ref2.miniUnitVerticalBorders,
      miniUnitHorizontalBorders = _ref2.miniUnitHorizontalBorders;
  var miniUnitGrid = document.querySelector(".".concat(prefix, "--grid-mini-unit")); // ** show or hide mini unit cells

  if (miniUnitCells) {
    miniUnitGrid.classList.add("".concat(prefix, "--grid-mini-unit--cell"));
  } else {
    miniUnitGrid.classList.remove("".concat(prefix, "--grid-mini-unit--cell"));
  } // Toggle between fixing or scrolling mini unit grid


  if (miniUnitFix) {
    miniUnitGrid.classList.add("".concat(prefix, "--grid-mini-unit--fixed"));
  } else {
    miniUnitGrid.classList.remove("".concat(prefix, "--grid-mini-unit--fixed"));
  } // show or hide mini unit vertical borders


  if (miniUnitVerticalBorders) {
    miniUnitGrid.classList.add("".concat(prefix, "--grid-mini-unit--vertical"));
  } else {
    miniUnitGrid.classList.remove("".concat(prefix, "--grid-mini-unit--vertical"));
  } // show or hide mini unit horizontal borders


  if (miniUnitHorizontalBorders) {
    miniUnitGrid.classList.add("".concat(prefix, "--grid-mini-unit--horizontal"));
  } else {
    miniUnitGrid.classList.remove("".concat(prefix, "--grid-mini-unit--horizontal"));
  }
}



/***/ }),

/***/ "./App/inject/index.js":
/*!*****************************!*\
  !*** ./App/inject/index.js ***!
  \*****************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _index_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index.scss */ "./App/inject/index.scss");
/* harmony import */ var _index_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_index_scss__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Grid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/Grid */ "./App/inject/components/Grid/index.js");


Object(_components_Grid__WEBPACK_IMPORTED_MODULE_1__["initGrid"])();

/***/ }),

/***/ "./App/inject/index.scss":
/*!*******************************!*\
  !*** ./App/inject/index.scss ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./App/setPrefix.js":
/*!**************************!*\
  !*** ./App/setPrefix.js ***!
  \**************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var carbon_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! carbon-components */ "./node_modules/carbon-components/es/index.js");

carbon_components__WEBPACK_IMPORTED_MODULE_0__["settings"].prefix = 'bx-dev';

/***/ }),

/***/ "./App/utilities/activeTab.js":
/*!************************************!*\
  !*** ./App/utilities/activeTab.js ***!
  \************************************/
/*! exports provided: activeTab */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "activeTab", function() { return activeTab; });
function activeTab(callback) {
  chrome.tabs.query({
    currentWindow: true,
    active: true
  }, function (tabs) {
    return callback(tabs[0]);
  });
}



/***/ }),

/***/ "./App/utilities/experimental.js":
/*!***************************************!*\
  !*** ./App/utilities/experimental.js ***!
  \***************************************/
/*! exports provided: experimentalFlag, setExperimentalStatus, getExperimentalStatus, experimentalStatusChanged */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "experimentalFlag", function() { return experimentalFlag; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setExperimentalStatus", function() { return setExperimentalStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getExperimentalStatus", function() { return getExperimentalStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "experimentalStatusChanged", function() { return experimentalStatusChanged; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/preact/compat/dist/compat.module.js");
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index */ "./App/utilities/index.js");


experimentalStatusChanged(setExperimentalStatus);
getExperimentalStatus(setExperimentalStatus);

function experimentalFlag(inverse, callback) {
  var experimental = window.generalExperimental;

  if (typeof inverse === 'function') {
    callback = inverse;
  } else if (inverse === true) {
    experimental = !window.generalExperimental;
  }

  return experimental ? callback() : null;
}

function setExperimentalStatus(newStatus) {
  window.generalExperimental = newStatus;
}

function getExperimentalStatus(callback) {
  Object(_index__WEBPACK_IMPORTED_MODULE_1__["getStorage"])(['generalExperimental'], function (_ref) {
    var generalExperimental = _ref.generalExperimental;
    callback(generalExperimental);
  });
}

function experimentalStatusChanged(callback) {
  Object(_index__WEBPACK_IMPORTED_MODULE_1__["storageChanged"])('generalExperimental', function (generalExperimental) {
    callback(generalExperimental);
  });
}



/***/ }),

/***/ "./App/utilities/getMessage.js":
/*!*************************************!*\
  !*** ./App/utilities/getMessage.js ***!
  \*************************************/
/*! exports provided: getMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMessage", function() { return getMessage; });
function getMessage(callback) {
  chrome.runtime.onMessage.addListener(callback);
}



/***/ }),

/***/ "./App/utilities/getStorage.js":
/*!*************************************!*\
  !*** ./App/utilities/getStorage.js ***!
  \*************************************/
/*! exports provided: getStorage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getStorage", function() { return getStorage; });
function getStorage(key, callback) {
  chrome.storage.local.get(key, callback);
}



/***/ }),

/***/ "./App/utilities/index.js":
/*!********************************!*\
  !*** ./App/utilities/index.js ***!
  \********************************/
/*! exports provided: getMessage, sendMessage, insertScript, insertCSS, setStorage, getStorage, storageChanged, storageTrueFalse, onCommand, activeTab, onTabUpdated, onTabRemoved, experimentalFlag, setExperimentalStatus, getExperimentalStatus, experimentalStatusChanged, remtopx */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _getMessage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./getMessage */ "./App/utilities/getMessage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getMessage", function() { return _getMessage__WEBPACK_IMPORTED_MODULE_0__["getMessage"]; });

/* harmony import */ var _sendMessage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sendMessage */ "./App/utilities/sendMessage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "sendMessage", function() { return _sendMessage__WEBPACK_IMPORTED_MODULE_1__["sendMessage"]; });

/* harmony import */ var _insertScript__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./insertScript */ "./App/utilities/insertScript.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "insertScript", function() { return _insertScript__WEBPACK_IMPORTED_MODULE_2__["insertScript"]; });

/* harmony import */ var _insertCSS__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./insertCSS */ "./App/utilities/insertCSS.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "insertCSS", function() { return _insertCSS__WEBPACK_IMPORTED_MODULE_3__["insertCSS"]; });

/* harmony import */ var _setStorage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./setStorage */ "./App/utilities/setStorage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "setStorage", function() { return _setStorage__WEBPACK_IMPORTED_MODULE_4__["setStorage"]; });

/* harmony import */ var _getStorage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./getStorage */ "./App/utilities/getStorage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getStorage", function() { return _getStorage__WEBPACK_IMPORTED_MODULE_5__["getStorage"]; });

/* harmony import */ var _storageChanged__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./storageChanged */ "./App/utilities/storageChanged.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "storageChanged", function() { return _storageChanged__WEBPACK_IMPORTED_MODULE_6__["storageChanged"]; });

/* harmony import */ var _storageTrueFalse__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./storageTrueFalse */ "./App/utilities/storageTrueFalse.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "storageTrueFalse", function() { return _storageTrueFalse__WEBPACK_IMPORTED_MODULE_7__["storageTrueFalse"]; });

/* harmony import */ var _onCommand__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./onCommand */ "./App/utilities/onCommand.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "onCommand", function() { return _onCommand__WEBPACK_IMPORTED_MODULE_8__["onCommand"]; });

/* harmony import */ var _activeTab__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./activeTab */ "./App/utilities/activeTab.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "activeTab", function() { return _activeTab__WEBPACK_IMPORTED_MODULE_9__["activeTab"]; });

/* harmony import */ var _onTabUpdated__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./onTabUpdated */ "./App/utilities/onTabUpdated.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "onTabUpdated", function() { return _onTabUpdated__WEBPACK_IMPORTED_MODULE_10__["onTabUpdated"]; });

/* harmony import */ var _onTabRemoved__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./onTabRemoved */ "./App/utilities/onTabRemoved.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "onTabRemoved", function() { return _onTabRemoved__WEBPACK_IMPORTED_MODULE_11__["onTabRemoved"]; });

/* harmony import */ var _experimental__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./experimental */ "./App/utilities/experimental.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "experimentalFlag", function() { return _experimental__WEBPACK_IMPORTED_MODULE_12__["experimentalFlag"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "setExperimentalStatus", function() { return _experimental__WEBPACK_IMPORTED_MODULE_12__["setExperimentalStatus"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getExperimentalStatus", function() { return _experimental__WEBPACK_IMPORTED_MODULE_12__["getExperimentalStatus"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "experimentalStatusChanged", function() { return _experimental__WEBPACK_IMPORTED_MODULE_12__["experimentalStatusChanged"]; });

/* harmony import */ var _remtopx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./remtopx */ "./App/utilities/remtopx.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "remtopx", function() { return _remtopx__WEBPACK_IMPORTED_MODULE_13__["remtopx"]; });
















/***/ }),

/***/ "./App/utilities/insertCSS.js":
/*!************************************!*\
  !*** ./App/utilities/insertCSS.js ***!
  \************************************/
/*! exports provided: insertCSS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "insertCSS", function() { return insertCSS; });
function insertCSS(tabId, details, callback) {
  chrome.tabs.insertCSS(tabId, details, callback);
}



/***/ }),

/***/ "./App/utilities/insertScript.js":
/*!***************************************!*\
  !*** ./App/utilities/insertScript.js ***!
  \***************************************/
/*! exports provided: insertScript */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "insertScript", function() { return insertScript; });
function insertScript(tabId, details, callback) {
  chrome.tabs.executeScript(tabId, details, callback);
}



/***/ }),

/***/ "./App/utilities/onCommand.js":
/*!************************************!*\
  !*** ./App/utilities/onCommand.js ***!
  \************************************/
/*! exports provided: onCommand */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onCommand", function() { return onCommand; });
function onCommand(callback) {
  chrome.commands.onCommand.addListener(callback);
}



/***/ }),

/***/ "./App/utilities/onTabRemoved.js":
/*!***************************************!*\
  !*** ./App/utilities/onTabRemoved.js ***!
  \***************************************/
/*! exports provided: onTabRemoved */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onTabRemoved", function() { return onTabRemoved; });
function onTabRemoved(callback) {
  chrome.tabs.onRemoved.addListener(callback);
}



/***/ }),

/***/ "./App/utilities/onTabUpdated.js":
/*!***************************************!*\
  !*** ./App/utilities/onTabUpdated.js ***!
  \***************************************/
/*! exports provided: onTabUpdated */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onTabUpdated", function() { return onTabUpdated; });
function onTabUpdated(callback) {
  chrome.tabs.onUpdated.addListener(callback);
}



/***/ }),

/***/ "./App/utilities/remtopx.js":
/*!**********************************!*\
  !*** ./App/utilities/remtopx.js ***!
  \**********************************/
/*! exports provided: remtopx */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "remtopx", function() { return remtopx; });
/* harmony import */ var _carbon_layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @carbon/layout */ "./node_modules/@carbon/layout/es/index.js");


function remtopx(rem) {
  return _carbon_layout__WEBPACK_IMPORTED_MODULE_0__["baseFontSize"] * parseFloat(rem);
}



/***/ }),

/***/ "./App/utilities/sendMessage.js":
/*!**************************************!*\
  !*** ./App/utilities/sendMessage.js ***!
  \**************************************/
/*! exports provided: sendMessage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendMessage", function() { return sendMessage; });
function sendMessage(msg, callback) {
  chrome.runtime.sendMessage(msg, callback);
}



/***/ }),

/***/ "./App/utilities/setStorage.js":
/*!*************************************!*\
  !*** ./App/utilities/setStorage.js ***!
  \*************************************/
/*! exports provided: setStorage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setStorage", function() { return setStorage; });
function setStorage(data) {
  if (chrome && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set(data);
  }
}



/***/ }),

/***/ "./App/utilities/storageChanged.js":
/*!*****************************************!*\
  !*** ./App/utilities/storageChanged.js ***!
  \*****************************************/
/*! exports provided: storageChanged */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "storageChanged", function() { return storageChanged; });
function storageChanged(key, callback) {
  chrome.storage.onChanged.addListener(function (data) {
    if (data && data[key]) {
      callback(data[key].newValue);
    }
  });
}



/***/ }),

/***/ "./App/utilities/storageTrueFalse.js":
/*!*******************************************!*\
  !*** ./App/utilities/storageTrueFalse.js ***!
  \*******************************************/
/*! exports provided: storageTrueFalse */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "storageTrueFalse", function() { return storageTrueFalse; });
function storageTrueFalse(data, ifTrue, ifFalse) {
  if (data && (data === true || data.newValue === true)) {
    ifTrue();
  } else if (data && (data === false || data.newValue === false)) {
    ifFalse();
  }
}



/***/ }),

/***/ "./node_modules/@carbon/colors/es/index.js":
/*!*************************************************!*\
  !*** ./node_modules/@carbon/colors/es/index.js ***!
  \*************************************************/
/*! exports provided: black, black100, white, white0, yellow, yellow30, orange, orange40, red10, red20, red30, red40, red50, red60, red70, red80, red90, red100, red, magenta10, magenta20, magenta30, magenta40, magenta50, magenta60, magenta70, magenta80, magenta90, magenta100, magenta, purple10, purple20, purple30, purple40, purple50, purple60, purple70, purple80, purple90, purple100, purple, blue10, blue20, blue30, blue40, blue50, blue60, blue70, blue80, blue90, blue100, blue, cyan10, cyan20, cyan30, cyan40, cyan50, cyan60, cyan70, cyan80, cyan90, cyan100, cyan, teal10, teal20, teal30, teal40, teal50, teal60, teal70, teal80, teal90, teal100, teal, green10, green20, green30, green40, green50, green60, green70, green80, green90, green100, green, coolGray10, coolGray20, coolGray30, coolGray40, coolGray50, coolGray60, coolGray70, coolGray80, coolGray90, coolGray100, coolGray, gray10, gray20, gray30, gray40, gray50, gray60, gray70, gray80, gray90, gray100, gray, warmGray10, warmGray20, warmGray30, warmGray40, warmGray50, warmGray60, warmGray70, warmGray80, warmGray90, warmGray100, warmGray, yellow20, colors, rgba */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "black", function() { return black; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "black100", function() { return black100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "white", function() { return white; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "white0", function() { return white0; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "yellow", function() { return yellow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "yellow30", function() { return yellow30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orange", function() { return orange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "orange40", function() { return orange40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red10", function() { return red10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red20", function() { return red20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red30", function() { return red30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red40", function() { return red40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red50", function() { return red50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red60", function() { return red60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red70", function() { return red70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red80", function() { return red80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red90", function() { return red90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red100", function() { return red100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "red", function() { return red; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta10", function() { return magenta10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta20", function() { return magenta20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta30", function() { return magenta30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta40", function() { return magenta40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta50", function() { return magenta50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta60", function() { return magenta60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta70", function() { return magenta70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta80", function() { return magenta80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta90", function() { return magenta90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta100", function() { return magenta100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "magenta", function() { return magenta; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple10", function() { return purple10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple20", function() { return purple20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple30", function() { return purple30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple40", function() { return purple40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple50", function() { return purple50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple60", function() { return purple60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple70", function() { return purple70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple80", function() { return purple80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple90", function() { return purple90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple100", function() { return purple100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "purple", function() { return purple; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue10", function() { return blue10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue20", function() { return blue20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue30", function() { return blue30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue40", function() { return blue40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue50", function() { return blue50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue60", function() { return blue60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue70", function() { return blue70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue80", function() { return blue80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue90", function() { return blue90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue100", function() { return blue100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blue", function() { return blue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan10", function() { return cyan10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan20", function() { return cyan20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan30", function() { return cyan30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan40", function() { return cyan40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan50", function() { return cyan50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan60", function() { return cyan60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan70", function() { return cyan70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan80", function() { return cyan80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan90", function() { return cyan90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan100", function() { return cyan100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cyan", function() { return cyan; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal10", function() { return teal10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal20", function() { return teal20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal30", function() { return teal30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal40", function() { return teal40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal50", function() { return teal50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal60", function() { return teal60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal70", function() { return teal70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal80", function() { return teal80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal90", function() { return teal90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal100", function() { return teal100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "teal", function() { return teal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green10", function() { return green10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green20", function() { return green20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green30", function() { return green30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green40", function() { return green40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green50", function() { return green50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green60", function() { return green60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green70", function() { return green70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green80", function() { return green80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green90", function() { return green90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green100", function() { return green100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "green", function() { return green; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray10", function() { return coolGray10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray20", function() { return coolGray20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray30", function() { return coolGray30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray40", function() { return coolGray40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray50", function() { return coolGray50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray60", function() { return coolGray60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray70", function() { return coolGray70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray80", function() { return coolGray80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray90", function() { return coolGray90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray100", function() { return coolGray100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coolGray", function() { return coolGray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray10", function() { return gray10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray20", function() { return gray20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray30", function() { return gray30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray40", function() { return gray40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray50", function() { return gray50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray60", function() { return gray60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray70", function() { return gray70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray80", function() { return gray80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray90", function() { return gray90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray100", function() { return gray100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "gray", function() { return gray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray10", function() { return warmGray10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray20", function() { return warmGray20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray30", function() { return warmGray30; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray40", function() { return warmGray40; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray50", function() { return warmGray50; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray60", function() { return warmGray60; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray70", function() { return warmGray70; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray80", function() { return warmGray80; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray90", function() { return warmGray90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray100", function() { return warmGray100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "warmGray", function() { return warmGray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "yellow20", function() { return yellow20; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colors", function() { return colors; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rgba", function() { return rgba; });
/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
var black = '#000000';
var black100 = black;
var white = '#ffffff';
var white0 = white;
var yellow = '#f1c21b';
var yellow30 = yellow;
var orange = '#ff832b';
var orange40 = orange;
var red10 = '#fff1f1';
var red20 = '#ffd7d9';
var red30 = '#ffb3b8';
var red40 = '#ff8389';
var red50 = '#fa4d56';
var red60 = '#da1e28';
var red70 = '#a2191f';
var red80 = '#750e13';
var red90 = '#520408';
var red100 = '#2d0709';
var red = {
  10: red10,
  20: red20,
  30: red30,
  40: red40,
  50: red50,
  60: red60,
  70: red70,
  80: red80,
  90: red90,
  100: red100
};
var magenta10 = '#fff0f7';
var magenta20 = '#ffd6e8';
var magenta30 = '#ffafd2';
var magenta40 = '#ff7eb6';
var magenta50 = '#ee5396';
var magenta60 = '#d12771';
var magenta70 = '#9f1853';
var magenta80 = '#740937';
var magenta90 = '#510224';
var magenta100 = '#2a0a18';
var magenta = {
  10: magenta10,
  20: magenta20,
  30: magenta30,
  40: magenta40,
  50: magenta50,
  60: magenta60,
  70: magenta70,
  80: magenta80,
  90: magenta90,
  100: magenta100
};
var purple10 = '#f6f2ff';
var purple20 = '#e8daff';
var purple30 = '#d4bbff';
var purple40 = '#be95ff';
var purple50 = '#a56eff';
var purple60 = '#8a3ffc';
var purple70 = '#6929c4';
var purple80 = '#491d8b';
var purple90 = '#31135e';
var purple100 = '#1c0f30';
var purple = {
  10: purple10,
  20: purple20,
  30: purple30,
  40: purple40,
  50: purple50,
  60: purple60,
  70: purple70,
  80: purple80,
  90: purple90,
  100: purple100
};
var blue10 = '#edf5ff';
var blue20 = '#d0e2ff';
var blue30 = '#a6c8ff';
var blue40 = '#78a9ff';
var blue50 = '#4589ff';
var blue60 = '#0f62fe';
var blue70 = '#0043ce';
var blue80 = '#002d9c';
var blue90 = '#001d6c';
var blue100 = '#001141';
var blue = {
  10: blue10,
  20: blue20,
  30: blue30,
  40: blue40,
  50: blue50,
  60: blue60,
  70: blue70,
  80: blue80,
  90: blue90,
  100: blue100
};
var cyan10 = '#e5f6ff';
var cyan20 = '#bae6ff';
var cyan30 = '#82cfff';
var cyan40 = '#33b1ff';
var cyan50 = '#1192e8';
var cyan60 = '#0072c3';
var cyan70 = '#00539a';
var cyan80 = '#003a6d';
var cyan90 = '#012749';
var cyan100 = '#061727';
var cyan = {
  10: cyan10,
  20: cyan20,
  30: cyan30,
  40: cyan40,
  50: cyan50,
  60: cyan60,
  70: cyan70,
  80: cyan80,
  90: cyan90,
  100: cyan100
};
var teal10 = '#d9fbfb';
var teal20 = '#9ef0f0';
var teal30 = '#3ddbd9';
var teal40 = '#08bdba';
var teal50 = '#009d9a';
var teal60 = '#007d79';
var teal70 = '#005d5d';
var teal80 = '#004144';
var teal90 = '#022b30';
var teal100 = '#081a1c';
var teal = {
  10: teal10,
  20: teal20,
  30: teal30,
  40: teal40,
  50: teal50,
  60: teal60,
  70: teal70,
  80: teal80,
  90: teal90,
  100: teal100
};
var green10 = '#defbe6';
var green20 = '#a7f0ba';
var green30 = '#6fdc8c';
var green40 = '#42be65';
var green50 = '#24a148';
var green60 = '#198038';
var green70 = '#0e6027';
var green80 = '#044317';
var green90 = '#022d0d';
var green100 = '#071908';
var green = {
  10: green10,
  20: green20,
  30: green30,
  40: green40,
  50: green50,
  60: green60,
  70: green70,
  80: green80,
  90: green90,
  100: green100
};
var coolGray10 = '#f2f4f8';
var coolGray20 = '#dde1e6';
var coolGray30 = '#c1c7cd';
var coolGray40 = '#a2a9b0';
var coolGray50 = '#878d96';
var coolGray60 = '#697077';
var coolGray70 = '#4d5358';
var coolGray80 = '#343a3f';
var coolGray90 = '#21272a';
var coolGray100 = '#121619';
var coolGray = {
  10: coolGray10,
  20: coolGray20,
  30: coolGray30,
  40: coolGray40,
  50: coolGray50,
  60: coolGray60,
  70: coolGray70,
  80: coolGray80,
  90: coolGray90,
  100: coolGray100
};
var gray10 = '#f4f4f4';
var gray20 = '#e0e0e0';
var gray30 = '#c6c6c6';
var gray40 = '#a8a8a8';
var gray50 = '#8d8d8d';
var gray60 = '#6f6f6f';
var gray70 = '#525252';
var gray80 = '#393939';
var gray90 = '#262626';
var gray100 = '#161616';
var gray = {
  10: gray10,
  20: gray20,
  30: gray30,
  40: gray40,
  50: gray50,
  60: gray60,
  70: gray70,
  80: gray80,
  90: gray90,
  100: gray100
};
var warmGray10 = '#f7f3f2';
var warmGray20 = '#e5e0df';
var warmGray30 = '#cac5c4';
var warmGray40 = '#ada8a8';
var warmGray50 = '#8f8b8b';
var warmGray60 = '#736f6f';
var warmGray70 = '#565151';
var warmGray80 = '#3c3838';
var warmGray90 = '#272525';
var warmGray100 = '#171414';
var warmGray = {
  10: warmGray10,
  20: warmGray20,
  30: warmGray30,
  40: warmGray40,
  50: warmGray50,
  60: warmGray60,
  70: warmGray70,
  80: warmGray80,
  90: warmGray90,
  100: warmGray100
}; // Deprecated ☠️

var yellow20 = '#fdd13a';
var colors = {
  black: {
    100: black
  },
  blue: blue,
  coolGray: coolGray,
  cyan: cyan,
  gray: gray,
  green: green,
  magenta: magenta,
  orange: {
    40: orange40
  },
  purple: purple,
  red: red,
  teal: teal,
  warmGray: warmGray,
  white: {
    0: white
  },
  yellow: {
    20: yellow20,
    30: yellow30
  }
};

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

/**
 * Parse a given hexcode string into an rgba statement with the given opacity
 * @param {string} hexcode
 * @param {number} opacity
 * @returns {string}
 */
function rgba(hexcode, opacity) {
  var values = [hexcode.substring(1, 3), hexcode.substring(3, 5), hexcode.substring(5, 7)].map(function (string) {
    return parseInt(string, 16);
  });
  return "rgba(".concat(values[0], ", ").concat(values[1], ", ").concat(values[2], ", ").concat(opacity, ")");
}

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */




/***/ }),

/***/ "./node_modules/@carbon/layout/es/index.js":
/*!*************************************************!*\
  !*** ./node_modules/@carbon/layout/es/index.js ***!
  \*************************************************/
/*! exports provided: unstable_tokens, baseFontSize, rem, em, px, breakpoints, breakpointUp, breakpointDown, breakpoint, miniUnit, miniUnits, spacing01, spacing02, spacing03, spacing04, spacing05, spacing06, spacing07, spacing08, spacing09, spacing10, spacing11, spacing12, spacing, fluidSpacing01, fluidSpacing02, fluidSpacing03, fluidSpacing04, fluidSpacing, layout01, layout02, layout03, layout04, layout05, layout06, layout07, layout, container01, container02, container03, container04, container05, container, iconSize01, iconSize02, iconSize */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unstable_tokens", function() { return unstable_tokens; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "baseFontSize", function() { return baseFontSize; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rem", function() { return rem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "em", function() { return em; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "px", function() { return px; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "breakpoints", function() { return breakpoints; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "breakpointUp", function() { return breakpointUp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "breakpointDown", function() { return breakpointDown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "breakpoint", function() { return breakpoint; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "miniUnit", function() { return miniUnit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "miniUnits", function() { return miniUnits; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing01", function() { return spacing01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing02", function() { return spacing02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing03", function() { return spacing03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing04", function() { return spacing04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing05", function() { return spacing05; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing06", function() { return spacing06; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing07", function() { return spacing07; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing08", function() { return spacing08; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing09", function() { return spacing09; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing10", function() { return spacing10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing11", function() { return spacing11; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing12", function() { return spacing12; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spacing", function() { return spacing; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fluidSpacing01", function() { return fluidSpacing01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fluidSpacing02", function() { return fluidSpacing02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fluidSpacing03", function() { return fluidSpacing03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fluidSpacing04", function() { return fluidSpacing04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fluidSpacing", function() { return fluidSpacing; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout01", function() { return layout01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout02", function() { return layout02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout03", function() { return layout03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout04", function() { return layout04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout05", function() { return layout05; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout06", function() { return layout06; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout07", function() { return layout07; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "layout", function() { return layout; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "container01", function() { return container01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "container02", function() { return container02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "container03", function() { return container03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "container04", function() { return container04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "container05", function() { return container05; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "container", function() { return container; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "iconSize01", function() { return iconSize01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "iconSize02", function() { return iconSize02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "iconSize", function() { return iconSize; });
/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
var unstable_tokens = [// Spacing
'spacing01', 'spacing02', 'spacing03', 'spacing04', 'spacing05', 'spacing06', 'spacing07', 'spacing08', 'spacing09', 'spacing10', 'spacing11', 'spacing12', // Fluid spacing
'fluidSpacing01', 'fluidSpacing02', 'fluidSpacing03', 'fluidSpacing04', // Layout
'layout01', 'layout02', 'layout03', 'layout04', 'layout05', 'layout06', 'layout07', // Containers
'container01', 'container02', 'container03', 'container04', 'container05', // Icon sizes
'iconSize01', 'iconSize02'];

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
// Default, Use with em() and rem() functions

var baseFontSize = 16;
/**
 * Convert a given px unit to a rem unit
 * @param {number} px
 * @returns {string}
 */

function rem(px) {
  return "".concat(px / baseFontSize, "rem");
}
/**
 * Convert a given px unit to a em unit
 * @param {number} px
 * @returns {string}
 */

function em(px) {
  return "".concat(px / baseFontSize, "em");
}
/**
 * Convert a given px unit to its string representation
 * @param {number} value - number of pixels
 * @returns {string}
 */

function px(value) {
  return "".concat(value, "px");
} // Breakpoint
// Initial map of our breakpoints and their values

var breakpoints = {
  sm: {
    width: rem(320),
    columns: 4,
    margin: '0'
  },
  md: {
    width: rem(672),
    columns: 8,
    margin: rem(16)
  },
  lg: {
    width: rem(1056),
    columns: 16,
    margin: rem(16)
  },
  xlg: {
    width: rem(1312),
    columns: 16,
    margin: rem(16)
  },
  max: {
    width: rem(1584),
    columns: 16,
    margin: rem(24)
  }
};
function breakpointUp(name) {
  return "@media (min-width: ".concat(breakpoints[name].width, ")");
}
function breakpointDown(name) {
  return "@media (max-width: ".concat(breakpoints[name].width, ")");
}
function breakpoint() {
  return breakpointUp.apply(void 0, arguments);
} // Mini-unit

var miniUnit = 8;
function miniUnits(count) {
  return rem(miniUnit * count);
} // Spacing

var spacing01 = miniUnits(0.25);
var spacing02 = miniUnits(0.5);
var spacing03 = miniUnits(1);
var spacing04 = miniUnits(1.5);
var spacing05 = miniUnits(2);
var spacing06 = miniUnits(3);
var spacing07 = miniUnits(4);
var spacing08 = miniUnits(5);
var spacing09 = miniUnits(6);
var spacing10 = miniUnits(8);
var spacing11 = miniUnits(10);
var spacing12 = miniUnits(12);
var spacing = [spacing01, spacing02, spacing03, spacing04, spacing05, spacing06, spacing07, spacing08, spacing09, spacing10, spacing11, spacing12]; // Fluid spacing

var fluidSpacing01 = 0;
var fluidSpacing02 = '2vw';
var fluidSpacing03 = '5vw';
var fluidSpacing04 = '10vw';
var fluidSpacing = [fluidSpacing01, fluidSpacing02, fluidSpacing03, fluidSpacing04]; // Layout

var layout01 = miniUnits(2);
var layout02 = miniUnits(3);
var layout03 = miniUnits(4);
var layout04 = miniUnits(6);
var layout05 = miniUnits(8);
var layout06 = miniUnits(12);
var layout07 = miniUnits(20);
var layout = [layout01, layout02, layout03, layout04, layout05, layout06, layout07]; // Container

var container01 = miniUnits(3);
var container02 = miniUnits(4);
var container03 = miniUnits(5);
var container04 = miniUnits(6);
var container05 = miniUnits(8);
var container = [container01, container02, container03, container04, container05]; // Icon

var iconSize01 = '1rem';
var iconSize02 = '1.25rem';
var iconSize = [iconSize01, iconSize02];




/***/ }),

/***/ "./node_modules/@carbon/themes/es/index.js":
/*!*************************************************!*\
  !*** ./node_modules/@carbon/themes/es/index.js ***!
  \*************************************************/
/*! exports provided: caption01, label01, helperText01, bodyShort01, bodyLong01, bodyShort02, bodyLong02, code01, code02, heading01, productiveHeading01, heading02, productiveHeading02, productiveHeading03, productiveHeading04, productiveHeading05, productiveHeading06, productiveHeading07, expressiveHeading01, expressiveHeading02, expressiveHeading03, expressiveHeading04, expressiveHeading05, expressiveHeading06, expressiveParagraph01, quotation01, quotation02, display01, display02, display03, display04, spacing01, spacing02, spacing03, spacing04, spacing05, spacing06, spacing07, spacing08, spacing09, spacing10, spacing11, spacing12, fluidSpacing01, fluidSpacing02, fluidSpacing03, fluidSpacing04, layout01, layout02, layout03, layout04, layout05, layout06, layout07, container01, container02, container03, container04, container05, iconSize01, iconSize02, g10, g90, g100, white, v9, tokens, formatTokenName, unstable__meta, themes, interactive01, interactive02, interactive03, interactive04, uiBackground, ui01, ui02, ui03, ui04, ui05, text01, text02, text03, text04, text05, textError, icon01, icon02, icon03, link01, inverseLink, field01, field02, inverse01, inverse02, support01, support02, support03, support04, inverseSupport01, inverseSupport02, inverseSupport03, inverseSupport04, overlay01, danger, focus, inverseFocusUi, hoverPrimary, activePrimary, hoverPrimaryText, hoverSecondary, activeSecondary, hoverTertiary, activeTertiary, hoverUI, activeUI, selectedUI, selectedLightUI, inverseHoverUI, hoverSelectedUI, hoverDanger, activeDanger, hoverRow, visitedLink, disabled01, disabled02, disabled03, highlight, decorative01, skeleton01, skeleton02, brand01, brand02, brand03, active01, hoverField */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g10", function() { return g10; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g90", function() { return g90; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g100", function() { return g100; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "white", function() { return white$1; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "v9", function() { return v9; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tokens", function() { return tokens; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formatTokenName", function() { return formatTokenName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unstable__meta", function() { return unstable__meta; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "themes", function() { return themes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "interactive01", function() { return interactive01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "interactive02", function() { return interactive02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "interactive03", function() { return interactive03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "interactive04", function() { return interactive04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "uiBackground", function() { return uiBackground; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ui01", function() { return ui01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ui02", function() { return ui02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ui03", function() { return ui03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ui04", function() { return ui04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ui05", function() { return ui05; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "text01", function() { return text01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "text02", function() { return text02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "text03", function() { return text03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "text04", function() { return text04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "text05", function() { return text05; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "textError", function() { return textError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "icon01", function() { return icon01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "icon02", function() { return icon02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "icon03", function() { return icon03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "link01", function() { return link01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "inverseLink", function() { return inverseLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "field01", function() { return field01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "field02", function() { return field02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "inverse01", function() { return inverse01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "inverse02", function() { return inverse02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "support01", function() { return support01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "support02", function() { return support02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "support03", function() { return support03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "support04", function() { return support04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "inverseSupport01", function() { return inverseSupport01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "inverseSupport02", function() { return inverseSupport02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "inverseSupport03", function() { return inverseSupport03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "inverseSupport04", function() { return inverseSupport04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "overlay01", function() { return overlay01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "danger", function() { return danger; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "focus", function() { return focus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "inverseFocusUi", function() { return inverseFocusUi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hoverPrimary", function() { return hoverPrimary; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "activePrimary", function() { return activePrimary; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hoverPrimaryText", function() { return hoverPrimaryText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hoverSecondary", function() { return hoverSecondary; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "activeSecondary", function() { return activeSecondary; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hoverTertiary", function() { return hoverTertiary; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "activeTertiary", function() { return activeTertiary; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hoverUI", function() { return hoverUI; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "activeUI", function() { return activeUI; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectedUI", function() { return selectedUI; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectedLightUI", function() { return selectedLightUI; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "inverseHoverUI", function() { return inverseHoverUI; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hoverSelectedUI", function() { return hoverSelectedUI; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hoverDanger", function() { return hoverDanger; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "activeDanger", function() { return activeDanger; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hoverRow", function() { return hoverRow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "visitedLink", function() { return visitedLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "disabled01", function() { return disabled01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "disabled02", function() { return disabled02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "disabled03", function() { return disabled03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "highlight", function() { return highlight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "decorative01", function() { return decorative01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "skeleton01", function() { return skeleton01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "skeleton02", function() { return skeleton02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "brand01", function() { return brand01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "brand02", function() { return brand02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "brand03", function() { return brand03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "active01", function() { return active01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hoverField", function() { return hoverField; });
/* harmony import */ var color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! color */ "./node_modules/color/index.js");
/* harmony import */ var color__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(color__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _carbon_colors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @carbon/colors */ "./node_modules/@carbon/colors/es/index.js");
/* harmony import */ var _carbon_type__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @carbon/type */ "./node_modules/@carbon/type/es/index.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "caption01", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["caption01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "label01", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["label01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "helperText01", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["helperText01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "bodyShort01", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyShort01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "bodyLong01", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyLong01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "bodyShort02", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyShort02"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "bodyLong02", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyLong02"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "code01", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["code01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "code02", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["code02"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "heading01", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["heading01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "productiveHeading01", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "heading02", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["heading02"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "productiveHeading02", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading02"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "productiveHeading03", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading03"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "productiveHeading04", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading04"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "productiveHeading05", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading05"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "productiveHeading06", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading06"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "productiveHeading07", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading07"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "expressiveHeading01", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "expressiveHeading02", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading02"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "expressiveHeading03", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading03"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "expressiveHeading04", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading04"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "expressiveHeading05", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading05"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "expressiveHeading06", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading06"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "expressiveParagraph01", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveParagraph01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "quotation01", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["quotation01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "quotation02", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["quotation02"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "display01", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "display02", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display02"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "display03", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display03"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "display04", function() { return _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display04"]; });

/* harmony import */ var _carbon_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @carbon/layout */ "./node_modules/@carbon/layout/es/index.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "spacing01", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "spacing02", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing02"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "spacing03", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing03"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "spacing04", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing04"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "spacing05", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing05"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "spacing06", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing06"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "spacing07", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing07"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "spacing08", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing08"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "spacing09", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing09"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "spacing10", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing10"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "spacing11", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing11"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "spacing12", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing12"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "fluidSpacing01", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "fluidSpacing02", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing02"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "fluidSpacing03", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing03"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "fluidSpacing04", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing04"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "layout01", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "layout02", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout02"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "layout03", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout03"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "layout04", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout04"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "layout05", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout05"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "layout06", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout06"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "layout07", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout07"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "container01", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "container02", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container02"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "container03", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container03"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "container04", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container04"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "container05", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container05"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "iconSize01", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["iconSize01"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "iconSize02", function() { return _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["iconSize02"]; });








function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    if (enumerableOnly) symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    });
    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

/**
 * Adjust a given token's lightness by a specified percentage
 * Example: token = hsl(10, 10, 10);
 * adjustLightness(token, 5) === hsl(10, 10, 15);
 * adjustLightness(token, -5) === hsl(10, 10, 5);
 * @param {string} token
 * @param {integer} shift The number of percentage points (positive or negative) by which to shift the lightness of a token.
 * @returns {string}
 */

function adjustLightness(token, shift) {
  var original = color__WEBPACK_IMPORTED_MODULE_0___default()(token).hsl().object();
  return color__WEBPACK_IMPORTED_MODULE_0___default()(_objectSpread2(_objectSpread2({}, original), {}, {
    l: original.l += shift
  })).round().hex().toLowerCase();
}

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
var interactive01 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var interactive02 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray80"];
var interactive03 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var interactive04 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var uiBackground = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var ui01 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var ui02 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var ui03 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray20"];
var ui04 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray50"];
var ui05 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray100"];
var text01 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray100"];
var text02 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray70"];
var text03 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray40"];
var text04 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var text05 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray60"];
var textError = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red60"];
var icon01 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray100"];
var icon02 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray70"];
var icon03 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var link01 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var inverseLink = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue40"];
var field01 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var field02 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var inverse01 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var inverse02 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray80"];
var support01 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red60"];
var support02 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["green50"];
var support03 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["yellow"];
var support04 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue70"];
var inverseSupport01 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red50"];
var inverseSupport02 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["green40"];
var inverseSupport03 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["yellow"];
var inverseSupport04 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue50"];
var overlay01 = Object(_carbon_colors__WEBPACK_IMPORTED_MODULE_1__["rgba"])(_carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray100"], 0.5);
var danger = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red60"]; // Interaction states

var focus = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var inverseFocusUi = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var hoverPrimary = '#0353e9';
var activePrimary = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue80"];
var hoverPrimaryText = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue70"];
var hoverSecondary = '#4c4c4c';
var activeSecondary = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray60"];
var hoverTertiary = '#0353e9';
var activeTertiary = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue80"];
var hoverUI = '#e5e5e5';
var activeUI = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray30"];
var selectedUI = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray20"];
var selectedLightUI = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray20"];
var inverseHoverUI = '#4c4c4c';
var hoverSelectedUI = '#cacaca';
var hoverDanger = adjustLightness(danger, -8);
var activeDanger = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red80"];
var hoverRow = '#e5e5e5';
var visitedLink = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["purple60"];
var disabled01 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var disabled02 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray30"];
var disabled03 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray50"];
var highlight = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue20"];
var decorative01 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray20"];
var skeleton01 = '#e5e5e5';
var skeleton02 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray30"]; // Type

var brand01 = interactive01;
var brand02 = interactive02;
var brand03 = interactive03;
var active01 = activeUI;
var hoverField = hoverUI;

var white$1 = /*#__PURE__*/Object.freeze({
  interactive01: interactive01,
  interactive02: interactive02,
  interactive03: interactive03,
  interactive04: interactive04,
  uiBackground: uiBackground,
  ui01: ui01,
  ui02: ui02,
  ui03: ui03,
  ui04: ui04,
  ui05: ui05,
  text01: text01,
  text02: text02,
  text03: text03,
  text04: text04,
  text05: text05,
  textError: textError,
  icon01: icon01,
  icon02: icon02,
  icon03: icon03,
  link01: link01,
  inverseLink: inverseLink,
  field01: field01,
  field02: field02,
  inverse01: inverse01,
  inverse02: inverse02,
  support01: support01,
  support02: support02,
  support03: support03,
  support04: support04,
  inverseSupport01: inverseSupport01,
  inverseSupport02: inverseSupport02,
  inverseSupport03: inverseSupport03,
  inverseSupport04: inverseSupport04,
  overlay01: overlay01,
  danger: danger,
  focus: focus,
  inverseFocusUi: inverseFocusUi,
  hoverPrimary: hoverPrimary,
  activePrimary: activePrimary,
  hoverPrimaryText: hoverPrimaryText,
  hoverSecondary: hoverSecondary,
  activeSecondary: activeSecondary,
  hoverTertiary: hoverTertiary,
  activeTertiary: activeTertiary,
  hoverUI: hoverUI,
  activeUI: activeUI,
  selectedUI: selectedUI,
  selectedLightUI: selectedLightUI,
  inverseHoverUI: inverseHoverUI,
  hoverSelectedUI: hoverSelectedUI,
  hoverDanger: hoverDanger,
  activeDanger: activeDanger,
  hoverRow: hoverRow,
  visitedLink: visitedLink,
  disabled01: disabled01,
  disabled02: disabled02,
  disabled03: disabled03,
  highlight: highlight,
  decorative01: decorative01,
  skeleton01: skeleton01,
  skeleton02: skeleton02,
  brand01: brand01,
  brand02: brand02,
  brand03: brand03,
  active01: active01,
  hoverField: hoverField,
  caption01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["caption01"],
  label01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["label01"],
  helperText01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["helperText01"],
  bodyShort01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyShort01"],
  bodyLong01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyLong01"],
  bodyShort02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyShort02"],
  bodyLong02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyLong02"],
  code01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["code01"],
  code02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["code02"],
  heading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["heading01"],
  productiveHeading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading01"],
  heading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["heading02"],
  productiveHeading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading02"],
  productiveHeading03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading03"],
  productiveHeading04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading04"],
  productiveHeading05: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading05"],
  productiveHeading06: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading06"],
  productiveHeading07: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading07"],
  expressiveHeading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading01"],
  expressiveHeading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading02"],
  expressiveHeading03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading03"],
  expressiveHeading04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading04"],
  expressiveHeading05: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading05"],
  expressiveHeading06: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading06"],
  expressiveParagraph01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveParagraph01"],
  quotation01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["quotation01"],
  quotation02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["quotation02"],
  display01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display01"],
  display02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display02"],
  display03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display03"],
  display04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display04"],
  spacing01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing01"],
  spacing02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing02"],
  spacing03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing03"],
  spacing04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing04"],
  spacing05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing05"],
  spacing06: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing06"],
  spacing07: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing07"],
  spacing08: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing08"],
  spacing09: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing09"],
  spacing10: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing10"],
  spacing11: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing11"],
  spacing12: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing12"],
  fluidSpacing01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing01"],
  fluidSpacing02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing02"],
  fluidSpacing03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing03"],
  fluidSpacing04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing04"],
  layout01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout01"],
  layout02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout02"],
  layout03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout03"],
  layout04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout04"],
  layout05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout05"],
  layout06: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout06"],
  layout07: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout07"],
  container01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container01"],
  container02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container02"],
  container03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container03"],
  container04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container04"],
  container05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container05"],
  iconSize01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["iconSize01"],
  iconSize02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["iconSize02"]
});

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
var interactive01$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var interactive02$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray80"];
var interactive03$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var interactive04$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var uiBackground$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var ui01$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var ui02$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var ui03$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray20"];
var ui04$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray50"];
var ui05$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray100"];
var text01$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray100"];
var text02$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray70"];
var text03$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray40"];
var text04$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var text05$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray60"];
var textError$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red60"];
var icon01$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray100"];
var icon02$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray70"];
var icon03$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var link01$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var inverseLink$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue40"];
var field01$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var field02$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var inverse01$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var inverse02$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray80"];
var support01$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red60"];
var support02$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["green50"];
var support03$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["yellow"];
var support04$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue70"];
var inverseSupport01$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red50"];
var inverseSupport02$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["green40"];
var inverseSupport03$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["yellow"];
var inverseSupport04$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue50"];
var overlay01$1 = Object(_carbon_colors__WEBPACK_IMPORTED_MODULE_1__["rgba"])(_carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray100"], 0.5);
var danger$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red60"]; // Interaction states

var focus$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var inverseFocusUi$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var hoverPrimary$1 = '#0353e9';
var activePrimary$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue80"];
var hoverPrimaryText$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue70"];
var hoverSecondary$1 = '#4c4c4c';
var activeSecondary$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray60"];
var hoverTertiary$1 = '#0353e9';
var activeTertiary$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue80"];
var hoverUI$1 = '#e5e5e5';
var activeUI$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray30"];
var selectedUI$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray20"];
var selectedLightUI$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray20"];
var inverseHoverUI$1 = '#4c4c4c';
var hoverSelectedUI$1 = '#cacaca';
var hoverDanger$1 = adjustLightness(danger$1, -8);
var activeDanger$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red80"];
var hoverRow$1 = '#e5e5e5';
var visitedLink$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["purple60"];
var disabled01$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var disabled02$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray30"];
var disabled03$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray50"];
var highlight$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue20"];
var decorative01$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray20"];
var skeleton01$1 = '#e5e5e5';
var skeleton02$1 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray30"];

var brand01$1 = interactive01$1;
var brand02$1 = interactive02$1;
var brand03$1 = interactive03$1;
var active01$1 = activeUI$1;
var hoverField$1 = hoverUI$1;

var g10 = /*#__PURE__*/Object.freeze({
  interactive01: interactive01$1,
  interactive02: interactive02$1,
  interactive03: interactive03$1,
  interactive04: interactive04$1,
  uiBackground: uiBackground$1,
  ui01: ui01$1,
  ui02: ui02$1,
  ui03: ui03$1,
  ui04: ui04$1,
  ui05: ui05$1,
  text01: text01$1,
  text02: text02$1,
  text03: text03$1,
  text04: text04$1,
  text05: text05$1,
  textError: textError$1,
  icon01: icon01$1,
  icon02: icon02$1,
  icon03: icon03$1,
  link01: link01$1,
  inverseLink: inverseLink$1,
  field01: field01$1,
  field02: field02$1,
  inverse01: inverse01$1,
  inverse02: inverse02$1,
  support01: support01$1,
  support02: support02$1,
  support03: support03$1,
  support04: support04$1,
  inverseSupport01: inverseSupport01$1,
  inverseSupport02: inverseSupport02$1,
  inverseSupport03: inverseSupport03$1,
  inverseSupport04: inverseSupport04$1,
  overlay01: overlay01$1,
  danger: danger$1,
  focus: focus$1,
  inverseFocusUi: inverseFocusUi$1,
  hoverPrimary: hoverPrimary$1,
  activePrimary: activePrimary$1,
  hoverPrimaryText: hoverPrimaryText$1,
  hoverSecondary: hoverSecondary$1,
  activeSecondary: activeSecondary$1,
  hoverTertiary: hoverTertiary$1,
  activeTertiary: activeTertiary$1,
  hoverUI: hoverUI$1,
  activeUI: activeUI$1,
  selectedUI: selectedUI$1,
  selectedLightUI: selectedLightUI$1,
  inverseHoverUI: inverseHoverUI$1,
  hoverSelectedUI: hoverSelectedUI$1,
  hoverDanger: hoverDanger$1,
  activeDanger: activeDanger$1,
  hoverRow: hoverRow$1,
  visitedLink: visitedLink$1,
  disabled01: disabled01$1,
  disabled02: disabled02$1,
  disabled03: disabled03$1,
  highlight: highlight$1,
  decorative01: decorative01$1,
  skeleton01: skeleton01$1,
  skeleton02: skeleton02$1,
  brand01: brand01$1,
  brand02: brand02$1,
  brand03: brand03$1,
  active01: active01$1,
  hoverField: hoverField$1,
  caption01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["caption01"],
  label01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["label01"],
  helperText01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["helperText01"],
  bodyShort01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyShort01"],
  bodyLong01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyLong01"],
  bodyShort02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyShort02"],
  bodyLong02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyLong02"],
  code01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["code01"],
  code02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["code02"],
  heading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["heading01"],
  productiveHeading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading01"],
  heading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["heading02"],
  productiveHeading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading02"],
  productiveHeading03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading03"],
  productiveHeading04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading04"],
  productiveHeading05: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading05"],
  productiveHeading06: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading06"],
  productiveHeading07: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading07"],
  expressiveHeading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading01"],
  expressiveHeading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading02"],
  expressiveHeading03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading03"],
  expressiveHeading04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading04"],
  expressiveHeading05: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading05"],
  expressiveHeading06: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading06"],
  expressiveParagraph01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveParagraph01"],
  quotation01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["quotation01"],
  quotation02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["quotation02"],
  display01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display01"],
  display02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display02"],
  display03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display03"],
  display04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display04"],
  spacing01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing01"],
  spacing02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing02"],
  spacing03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing03"],
  spacing04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing04"],
  spacing05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing05"],
  spacing06: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing06"],
  spacing07: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing07"],
  spacing08: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing08"],
  spacing09: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing09"],
  spacing10: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing10"],
  spacing11: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing11"],
  spacing12: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing12"],
  fluidSpacing01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing01"],
  fluidSpacing02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing02"],
  fluidSpacing03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing03"],
  fluidSpacing04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing04"],
  layout01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout01"],
  layout02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout02"],
  layout03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout03"],
  layout04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout04"],
  layout05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout05"],
  layout06: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout06"],
  layout07: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout07"],
  container01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container01"],
  container02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container02"],
  container03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container03"],
  container04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container04"],
  container05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container05"],
  iconSize01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["iconSize01"],
  iconSize02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["iconSize02"]
});

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
var interactive01$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var interactive02$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray60"];
var interactive03$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var interactive04$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue50"];
var uiBackground$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray100"];
var ui01$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray90"];
var ui02$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray80"];
var ui03$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray80"];
var ui04$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray60"];
var ui05$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var text01$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var text02$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray30"];
var text03$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray60"];
var text04$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var text05$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray50"];
var textError$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red40"];
var icon01$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var icon02$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray30"];
var icon03$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var link01$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue40"];
var inverseLink$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var field01$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray90"];
var field02$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray80"];
var inverse01$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray100"];
var inverse02$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var support01$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red50"];
var support02$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["green40"];
var support03$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["yellow"];
var support04$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue50"];
var inverseSupport01$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red60"];
var inverseSupport02$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["green50"];
var inverseSupport03$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["yellow"];
var inverseSupport04$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var overlay01$2 = Object(_carbon_colors__WEBPACK_IMPORTED_MODULE_1__["rgba"])(_carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray100"], 0.7);
var danger$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red60"]; // Interaction states

var focus$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var inverseFocusUi$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var hoverPrimary$2 = '#0353e9';
var activePrimary$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue80"];
var hoverPrimaryText$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue30"];
var hoverSecondary$2 = '#606060';
var activeSecondary$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray80"];
var hoverTertiary$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var activeTertiary$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray30"];
var hoverUI$2 = '#353535';
var activeUI$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray70"];
var selectedUI$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray80"];
var selectedLightUI$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray70"];
var inverseHoverUI$2 = '#e5e5e5';
var hoverSelectedUI$2 = '#4c4c4c';
var hoverDanger$2 = adjustLightness(danger$2, -8);
var activeDanger$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red80"];
var hoverRow$2 = '#353535';
var visitedLink$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["purple40"];
var disabled01$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray90"];
var disabled02$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray70"];
var disabled03$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray50"];
var highlight$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue80"];
var decorative01$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray70"];
var skeleton01$2 = '#353535';
var skeleton02$2 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray80"];

var brand01$2 = interactive01$2;
var brand02$2 = interactive02$2;
var brand03$2 = interactive03$2;
var active01$2 = activeUI$2;
var hoverField$2 = hoverUI$2;

var g100 = /*#__PURE__*/Object.freeze({
  interactive01: interactive01$2,
  interactive02: interactive02$2,
  interactive03: interactive03$2,
  interactive04: interactive04$2,
  uiBackground: uiBackground$2,
  ui01: ui01$2,
  ui02: ui02$2,
  ui03: ui03$2,
  ui04: ui04$2,
  ui05: ui05$2,
  text01: text01$2,
  text02: text02$2,
  text03: text03$2,
  text04: text04$2,
  text05: text05$2,
  textError: textError$2,
  icon01: icon01$2,
  icon02: icon02$2,
  icon03: icon03$2,
  link01: link01$2,
  inverseLink: inverseLink$2,
  field01: field01$2,
  field02: field02$2,
  inverse01: inverse01$2,
  inverse02: inverse02$2,
  support01: support01$2,
  support02: support02$2,
  support03: support03$2,
  support04: support04$2,
  inverseSupport01: inverseSupport01$2,
  inverseSupport02: inverseSupport02$2,
  inverseSupport03: inverseSupport03$2,
  inverseSupport04: inverseSupport04$2,
  overlay01: overlay01$2,
  danger: danger$2,
  focus: focus$2,
  inverseFocusUi: inverseFocusUi$2,
  hoverPrimary: hoverPrimary$2,
  activePrimary: activePrimary$2,
  hoverPrimaryText: hoverPrimaryText$2,
  hoverSecondary: hoverSecondary$2,
  activeSecondary: activeSecondary$2,
  hoverTertiary: hoverTertiary$2,
  activeTertiary: activeTertiary$2,
  hoverUI: hoverUI$2,
  activeUI: activeUI$2,
  selectedUI: selectedUI$2,
  selectedLightUI: selectedLightUI$2,
  inverseHoverUI: inverseHoverUI$2,
  hoverSelectedUI: hoverSelectedUI$2,
  hoverDanger: hoverDanger$2,
  activeDanger: activeDanger$2,
  hoverRow: hoverRow$2,
  visitedLink: visitedLink$2,
  disabled01: disabled01$2,
  disabled02: disabled02$2,
  disabled03: disabled03$2,
  highlight: highlight$2,
  decorative01: decorative01$2,
  skeleton01: skeleton01$2,
  skeleton02: skeleton02$2,
  brand01: brand01$2,
  brand02: brand02$2,
  brand03: brand03$2,
  active01: active01$2,
  hoverField: hoverField$2,
  caption01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["caption01"],
  label01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["label01"],
  helperText01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["helperText01"],
  bodyShort01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyShort01"],
  bodyLong01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyLong01"],
  bodyShort02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyShort02"],
  bodyLong02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyLong02"],
  code01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["code01"],
  code02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["code02"],
  heading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["heading01"],
  productiveHeading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading01"],
  heading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["heading02"],
  productiveHeading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading02"],
  productiveHeading03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading03"],
  productiveHeading04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading04"],
  productiveHeading05: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading05"],
  productiveHeading06: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading06"],
  productiveHeading07: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading07"],
  expressiveHeading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading01"],
  expressiveHeading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading02"],
  expressiveHeading03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading03"],
  expressiveHeading04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading04"],
  expressiveHeading05: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading05"],
  expressiveHeading06: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading06"],
  expressiveParagraph01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveParagraph01"],
  quotation01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["quotation01"],
  quotation02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["quotation02"],
  display01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display01"],
  display02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display02"],
  display03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display03"],
  display04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display04"],
  spacing01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing01"],
  spacing02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing02"],
  spacing03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing03"],
  spacing04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing04"],
  spacing05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing05"],
  spacing06: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing06"],
  spacing07: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing07"],
  spacing08: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing08"],
  spacing09: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing09"],
  spacing10: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing10"],
  spacing11: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing11"],
  spacing12: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing12"],
  fluidSpacing01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing01"],
  fluidSpacing02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing02"],
  fluidSpacing03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing03"],
  fluidSpacing04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing04"],
  layout01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout01"],
  layout02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout02"],
  layout03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout03"],
  layout04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout04"],
  layout05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout05"],
  layout06: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout06"],
  layout07: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout07"],
  container01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container01"],
  container02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container02"],
  container03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container03"],
  container04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container04"],
  container05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container05"],
  iconSize01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["iconSize01"],
  iconSize02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["iconSize02"]
});

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
var interactive01$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var interactive02$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray60"];
var interactive03$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var interactive04$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue50"];
var uiBackground$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray90"];
var ui01$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray80"];
var ui02$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray70"];
var ui03$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray70"];
var ui04$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray50"];
var ui05$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var text01$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var text02$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray30"];
var text03$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray60"];
var text04$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var text05$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray50"];
var textError$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red30"];
var icon01$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var icon02$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray30"];
var icon03$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var link01$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue40"];
var inverseLink$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var field01$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray80"];
var field02$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray70"];
var inverse01$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray100"];
var inverse02$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var support01$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red40"];
var support02$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["green40"];
var support03$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["yellow"];
var support04$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue50"];
var inverseSupport01$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red60"];
var inverseSupport02$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["green50"];
var inverseSupport03$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["yellow"];
var inverseSupport04$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var overlay01$3 = Object(_carbon_colors__WEBPACK_IMPORTED_MODULE_1__["rgba"])(_carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray100"], 0.7);
var danger$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red60"]; // Interaction states

var focus$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var inverseFocusUi$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue60"];
var hoverPrimary$3 = '#0353e9';
var activePrimary$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue80"];
var hoverPrimaryText$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue30"];
var hoverSecondary$3 = '#606060';
var activeSecondary$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray80"];
var hoverTertiary$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray10"];
var activeTertiary$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray30"];
var hoverUI$3 = '#4c4c4c';
var activeUI$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray60"];
var selectedUI$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray70"];
var selectedLightUI$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray60"];
var inverseHoverUI$3 = '#e5e5e5';
var hoverSelectedUI$3 = '#656565';
var hoverDanger$3 = adjustLightness(danger$3, -8);
var activeDanger$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red80"];
var hoverRow$3 = '#4c4c4c';
var visitedLink$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["purple40"];
var disabled01$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray80"];
var disabled02$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray60"];
var disabled03$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray40"];
var highlight$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["blue70"];
var decorative01$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray60"];
var skeleton01$3 = '#353535';
var skeleton02$3 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["gray70"];

var brand01$3 = interactive01$3;
var brand02$3 = interactive02$3;
var brand03$3 = interactive03$3;
var active01$3 = activeUI$3;
var hoverField$3 = hoverUI$3;

var g90 = /*#__PURE__*/Object.freeze({
  interactive01: interactive01$3,
  interactive02: interactive02$3,
  interactive03: interactive03$3,
  interactive04: interactive04$3,
  uiBackground: uiBackground$3,
  ui01: ui01$3,
  ui02: ui02$3,
  ui03: ui03$3,
  ui04: ui04$3,
  ui05: ui05$3,
  text01: text01$3,
  text02: text02$3,
  text03: text03$3,
  text04: text04$3,
  text05: text05$3,
  textError: textError$3,
  icon01: icon01$3,
  icon02: icon02$3,
  icon03: icon03$3,
  link01: link01$3,
  inverseLink: inverseLink$3,
  field01: field01$3,
  field02: field02$3,
  inverse01: inverse01$3,
  inverse02: inverse02$3,
  support01: support01$3,
  support02: support02$3,
  support03: support03$3,
  support04: support04$3,
  inverseSupport01: inverseSupport01$3,
  inverseSupport02: inverseSupport02$3,
  inverseSupport03: inverseSupport03$3,
  inverseSupport04: inverseSupport04$3,
  overlay01: overlay01$3,
  danger: danger$3,
  focus: focus$3,
  inverseFocusUi: inverseFocusUi$3,
  hoverPrimary: hoverPrimary$3,
  activePrimary: activePrimary$3,
  hoverPrimaryText: hoverPrimaryText$3,
  hoverSecondary: hoverSecondary$3,
  activeSecondary: activeSecondary$3,
  hoverTertiary: hoverTertiary$3,
  activeTertiary: activeTertiary$3,
  hoverUI: hoverUI$3,
  activeUI: activeUI$3,
  selectedUI: selectedUI$3,
  selectedLightUI: selectedLightUI$3,
  inverseHoverUI: inverseHoverUI$3,
  hoverSelectedUI: hoverSelectedUI$3,
  hoverDanger: hoverDanger$3,
  activeDanger: activeDanger$3,
  hoverRow: hoverRow$3,
  visitedLink: visitedLink$3,
  disabled01: disabled01$3,
  disabled02: disabled02$3,
  disabled03: disabled03$3,
  highlight: highlight$3,
  decorative01: decorative01$3,
  skeleton01: skeleton01$3,
  skeleton02: skeleton02$3,
  brand01: brand01$3,
  brand02: brand02$3,
  brand03: brand03$3,
  active01: active01$3,
  hoverField: hoverField$3,
  caption01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["caption01"],
  label01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["label01"],
  helperText01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["helperText01"],
  bodyShort01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyShort01"],
  bodyLong01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyLong01"],
  bodyShort02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyShort02"],
  bodyLong02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyLong02"],
  code01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["code01"],
  code02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["code02"],
  heading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["heading01"],
  productiveHeading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading01"],
  heading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["heading02"],
  productiveHeading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading02"],
  productiveHeading03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading03"],
  productiveHeading04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading04"],
  productiveHeading05: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading05"],
  productiveHeading06: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading06"],
  productiveHeading07: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading07"],
  expressiveHeading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading01"],
  expressiveHeading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading02"],
  expressiveHeading03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading03"],
  expressiveHeading04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading04"],
  expressiveHeading05: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading05"],
  expressiveHeading06: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading06"],
  expressiveParagraph01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveParagraph01"],
  quotation01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["quotation01"],
  quotation02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["quotation02"],
  display01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display01"],
  display02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display02"],
  display03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display03"],
  display04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display04"],
  spacing01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing01"],
  spacing02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing02"],
  spacing03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing03"],
  spacing04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing04"],
  spacing05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing05"],
  spacing06: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing06"],
  spacing07: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing07"],
  spacing08: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing08"],
  spacing09: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing09"],
  spacing10: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing10"],
  spacing11: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing11"],
  spacing12: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing12"],
  fluidSpacing01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing01"],
  fluidSpacing02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing02"],
  fluidSpacing03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing03"],
  fluidSpacing04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing04"],
  layout01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout01"],
  layout02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout02"],
  layout03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout03"],
  layout04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout04"],
  layout05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout05"],
  layout06: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout06"],
  layout07: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout07"],
  container01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container01"],
  container02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container02"],
  container03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container03"],
  container04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container04"],
  container05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container05"],
  iconSize01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["iconSize01"],
  iconSize02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["iconSize02"]
});

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
var interactive01$4 = '#3d70b2';
var interactive02$4 = '#4d5358';
var interactive03$4 = '#3d70b2';
var interactive04$4 = '#3d70b2';
var uiBackground$4 = '#f4f7fb';
var ui01$4 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var ui02$4 = '#f4f7fb';
var ui03$4 = '#dfe3e6';
var ui04$4 = '#8897a2';
var ui05$4 = '#5a6872';
var text01$4 = '#152935';
var text02$4 = '#5a6872';
var text03$4 = '#cdd1d4';
var text04$4 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var text05$4 = '#5a6872';
var textError$4 = '#e0182d';
var icon01$4 = '#3d70b2';
var icon02$4 = '#5a6872';
var icon03$4 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var link01$4 = '#3d70b2';
var inverseLink$4 = '#5596e6';
var field01$4 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var field02$4 = '#f4f7fb';
var inverse01$4 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["white"];
var inverse02$4 = '#272d33';
var support01$4 = '#e0182d';
var support02$4 = '#5aa700';
var support03$4 = '#efc100';
var support04$4 = '#5aaafa';
var inverseSupport01$4 = '#ff5050';
var inverseSupport02$4 = '#8cd211';
var inverseSupport03$4 = '#FDD600';
var inverseSupport04$4 = '#5aaafa';
var overlay01$4 = 'rgba(223, 227, 230, 0.5)';
var danger$4 = _carbon_colors__WEBPACK_IMPORTED_MODULE_1__["red60"]; // Interaction states

var focus$4 = '#3d70b2';
var inverseFocusUi$4 = '#3d70b2';
var hoverPrimary$4 = '#30588c';
var activePrimary$4 = '#30588c';
var hoverPrimaryText$4 = '#294c86';
var hoverSecondary$4 = '#4d5b65';
var activeSecondary$4 = '#414f59';
var hoverTertiary$4 = '#5a6872';
var activeTertiary$4 = '#414f59';
var hoverUI$4 = '#EEF4FC';
var activeUI$4 = '#DFEAFA';
var selectedUI$4 = '#EEF4FC';
var selectedLightUI$4 = '#EEF4FC';
var inverseHoverUI$4 = '#4c4c4c';
var hoverSelectedUI$4 = '#DFEAFA';
var hoverDanger$4 = '#c70014';
var activeDanger$4 = '#AD1625';
var hoverRow$4 = '#eef4fc';
var visitedLink$4 = '#294c86';
var disabled01$4 = '#fafbfd';
var disabled02$4 = '#dfe3e6';
var disabled03$4 = '#cdd1d4';
var highlight$4 = '#f4f7fb';
var decorative01$4 = '#EEF4FC';
var skeleton01$4 = 'rgba(61, 112, 178, .1)';
var skeleton02$4 = 'rgba(61, 112, 178, .1)';

var brand01$4 = interactive01$4;
var brand02$4 = interactive02$4;
var brand03$4 = interactive03$4;
var active01$4 = activeUI$4;
var hoverField$4 = hoverUI$4;

var v9 = /*#__PURE__*/Object.freeze({
  interactive01: interactive01$4,
  interactive02: interactive02$4,
  interactive03: interactive03$4,
  interactive04: interactive04$4,
  uiBackground: uiBackground$4,
  ui01: ui01$4,
  ui02: ui02$4,
  ui03: ui03$4,
  ui04: ui04$4,
  ui05: ui05$4,
  text01: text01$4,
  text02: text02$4,
  text03: text03$4,
  text04: text04$4,
  text05: text05$4,
  textError: textError$4,
  icon01: icon01$4,
  icon02: icon02$4,
  icon03: icon03$4,
  link01: link01$4,
  inverseLink: inverseLink$4,
  field01: field01$4,
  field02: field02$4,
  inverse01: inverse01$4,
  inverse02: inverse02$4,
  support01: support01$4,
  support02: support02$4,
  support03: support03$4,
  support04: support04$4,
  inverseSupport01: inverseSupport01$4,
  inverseSupport02: inverseSupport02$4,
  inverseSupport03: inverseSupport03$4,
  inverseSupport04: inverseSupport04$4,
  overlay01: overlay01$4,
  danger: danger$4,
  focus: focus$4,
  inverseFocusUi: inverseFocusUi$4,
  hoverPrimary: hoverPrimary$4,
  activePrimary: activePrimary$4,
  hoverPrimaryText: hoverPrimaryText$4,
  hoverSecondary: hoverSecondary$4,
  activeSecondary: activeSecondary$4,
  hoverTertiary: hoverTertiary$4,
  activeTertiary: activeTertiary$4,
  hoverUI: hoverUI$4,
  activeUI: activeUI$4,
  selectedUI: selectedUI$4,
  selectedLightUI: selectedLightUI$4,
  inverseHoverUI: inverseHoverUI$4,
  hoverSelectedUI: hoverSelectedUI$4,
  hoverDanger: hoverDanger$4,
  activeDanger: activeDanger$4,
  hoverRow: hoverRow$4,
  visitedLink: visitedLink$4,
  disabled01: disabled01$4,
  disabled02: disabled02$4,
  disabled03: disabled03$4,
  highlight: highlight$4,
  decorative01: decorative01$4,
  skeleton01: skeleton01$4,
  skeleton02: skeleton02$4,
  brand01: brand01$4,
  brand02: brand02$4,
  brand03: brand03$4,
  active01: active01$4,
  hoverField: hoverField$4,
  caption01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["caption01"],
  label01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["label01"],
  helperText01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["helperText01"],
  bodyShort01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyShort01"],
  bodyLong01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyLong01"],
  bodyShort02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyShort02"],
  bodyLong02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["bodyLong02"],
  code01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["code01"],
  code02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["code02"],
  heading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["heading01"],
  productiveHeading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading01"],
  heading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["heading02"],
  productiveHeading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading02"],
  productiveHeading03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading03"],
  productiveHeading04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading04"],
  productiveHeading05: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading05"],
  productiveHeading06: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading06"],
  productiveHeading07: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["productiveHeading07"],
  expressiveHeading01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading01"],
  expressiveHeading02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading02"],
  expressiveHeading03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading03"],
  expressiveHeading04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading04"],
  expressiveHeading05: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading05"],
  expressiveHeading06: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveHeading06"],
  expressiveParagraph01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["expressiveParagraph01"],
  quotation01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["quotation01"],
  quotation02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["quotation02"],
  display01: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display01"],
  display02: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display02"],
  display03: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display03"],
  display04: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["display04"],
  spacing01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing01"],
  spacing02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing02"],
  spacing03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing03"],
  spacing04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing04"],
  spacing05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing05"],
  spacing06: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing06"],
  spacing07: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing07"],
  spacing08: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing08"],
  spacing09: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing09"],
  spacing10: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing10"],
  spacing11: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing11"],
  spacing12: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["spacing12"],
  fluidSpacing01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing01"],
  fluidSpacing02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing02"],
  fluidSpacing03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing03"],
  fluidSpacing04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["fluidSpacing04"],
  layout01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout01"],
  layout02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout02"],
  layout03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout03"],
  layout04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout04"],
  layout05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout05"],
  layout06: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout06"],
  layout07: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["layout07"],
  container01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container01"],
  container02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container02"],
  container03: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container03"],
  container04: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container04"],
  container05: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["container05"],
  iconSize01: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["iconSize01"],
  iconSize02: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["iconSize02"]
});

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
// exported as in JavaScript

var colors = [// Core
'interactive01', 'interactive02', 'interactive03', 'interactive04', 'uiBackground', 'ui01', 'ui02', 'ui03', 'ui04', 'ui05', 'text01', 'text02', 'text03', 'text04', 'text05', 'textError', 'icon01', 'icon02', 'icon03', 'link01', 'inverseLink', 'field01', 'field02', 'inverse01', 'inverse02', 'support01', 'support02', 'support03', 'support04', 'inverseSupport01', 'inverseSupport02', 'inverseSupport03', 'inverseSupport04', 'overlay01', 'danger', // Interactive states
'focus', 'inverseFocusUi', 'hoverPrimary', 'activePrimary', 'hoverPrimaryText', 'hoverSecondary', 'activeSecondary', 'hoverTertiary', 'activeTertiary', 'hoverUI', 'activeUI', 'selectedUI', 'selectedLightUI', 'hoverSelectedUI', 'inverseHoverUI', 'hoverDanger', 'activeDanger', 'hoverRow', 'visitedLink', 'disabled01', 'disabled02', 'disabled03', 'highlight', 'decorative01', 'skeleton01', 'skeleton02', // Deprecated
'brand01', 'brand02', 'brand03', 'active01', 'hoverField'];
var numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
/**
 * Format a given token into the format expected in CSS/SCSS-based projects.
 * @param {string} token
 * @returns {string}
 */

function formatTokenName(token) {
  var string = '';

  for (var i = 0; i < token.length; i++) {
    // If we run into a number, we hit the scale step at the end of a token name
    // and can safely truncate the rest of the token
    if (numbers.indexOf(token[i]) !== -1) {
      string += '-' + token.slice(i);
      break;
    } // When encountering an uppercase name, we will want to start adding `-`
    // between words


    if (token[i] === token[i].toUpperCase()) {
      // Check backwards to see if previous letter was also capitalized, if so
      // we are in a special case like UI where each piece should be connected
      if (token[i - 1] && token[i - 1] === token[i - 1].toUpperCase()) {
        string += token[i].toLowerCase();
        continue;
      } // Otherwise, just concatenate this new part on to the existing string


      string += '-' + token[i].toLowerCase();
      continue;
    } // By default, we add the current character to the output string


    string += token[i];
  }

  return string;
}
var tokens = {
  colors: colors,
  type: _carbon_type__WEBPACK_IMPORTED_MODULE_2__["unstable_tokens"],
  layout: _carbon_layout__WEBPACK_IMPORTED_MODULE_3__["unstable_tokens"]
};
var unstable__meta = {
  colors: [{
    type: 'core',
    tokens: ['uiBackground', 'interactive01', 'interactive02', 'interactive03', 'interactive04', 'brand01', 'brand02', 'brand03', 'danger', 'ui01', 'ui02', 'ui03', 'ui04', 'ui05', 'text01', 'text02', 'text03', 'text04', 'text05', 'textError', 'link01', 'icon01', 'icon02', 'icon03', 'field01', 'field02', 'inverse01', 'inverse02', 'inverseLink', 'support01', 'support02', 'support03', 'support04', 'inverseSupport01', 'inverseSupport02', 'inverseSupport03', 'inverseSupport04', 'overlay01']
  }, {
    type: 'interactive',
    tokens: ['focus', 'inverseFocusUi', 'hoverPrimary', 'hoverPrimaryText', 'hoverSecondary', 'hoverTertiary', 'hoverUI', 'hoverSelectedUI', 'hoverDanger', 'hoverRow', 'activePrimary', 'activeSecondary', 'activeTertiary', 'activeUI', 'activeDanger', 'selectedUI', 'selectedLightUI', 'highlight', 'skeleton01', 'skeleton02', 'visitedLink', 'disabled01', 'disabled02', 'disabled03', 'inverseHoverUI', 'active01', 'hoverField', 'decorative01']
  }],
  deprecated: ['brand01', 'brand02', 'brand03', 'active01']
};

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
var themes = {
  white: white$1,
  g10: g10,
  g90: g90,
  g100: g100,
  v9: v9
};




/***/ }),

/***/ "./node_modules/@carbon/type/es/index.js":
/*!***********************************************!*\
  !*** ./node_modules/@carbon/type/es/index.js ***!
  \***********************************************/
/*! exports provided: fontFamilies, fontFamily, fontWeights, fontWeight, print, reset, getTypeSize, scale, styles, fluid, caption01, label01, helperText01, bodyShort01, bodyLong01, bodyShort02, bodyLong02, code01, code02, heading01, productiveHeading01, heading02, productiveHeading02, productiveHeading03, productiveHeading04, productiveHeading05, productiveHeading06, productiveHeading07, expressiveHeading01, expressiveHeading02, expressiveHeading03, expressiveHeading04, expressiveHeading05, expressiveHeading06, expressiveParagraph01, quotation01, quotation02, display01, display02, display03, display04, unstable_tokens */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fontFamilies", function() { return fontFamilies; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fontFamily", function() { return fontFamily; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fontWeights", function() { return fontWeights; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fontWeight", function() { return fontWeight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "print", function() { return print; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reset", function() { return reset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTypeSize", function() { return getTypeSize; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "scale", function() { return scale; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "styles", function() { return styles; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fluid", function() { return fluid; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "caption01", function() { return caption01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "label01", function() { return label01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "helperText01", function() { return helperText01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bodyShort01", function() { return bodyShort01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bodyLong01", function() { return bodyLong01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bodyShort02", function() { return bodyShort02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bodyLong02", function() { return bodyLong02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "code01", function() { return code01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "code02", function() { return code02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "heading01", function() { return heading01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "productiveHeading01", function() { return productiveHeading01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "heading02", function() { return heading02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "productiveHeading02", function() { return productiveHeading02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "productiveHeading03", function() { return productiveHeading03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "productiveHeading04", function() { return productiveHeading04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "productiveHeading05", function() { return productiveHeading05; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "productiveHeading06", function() { return productiveHeading06; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "productiveHeading07", function() { return productiveHeading07; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "expressiveHeading01", function() { return expressiveHeading01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "expressiveHeading02", function() { return expressiveHeading02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "expressiveHeading03", function() { return expressiveHeading03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "expressiveHeading04", function() { return expressiveHeading04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "expressiveHeading05", function() { return expressiveHeading05; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "expressiveHeading06", function() { return expressiveHeading06; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "expressiveParagraph01", function() { return expressiveParagraph01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "quotation01", function() { return quotation01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "quotation02", function() { return quotation02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "display01", function() { return display01; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "display02", function() { return display02; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "display03", function() { return display03; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "display04", function() { return display04; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unstable_tokens", function() { return unstable_tokens; });
/* harmony import */ var _carbon_layout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @carbon/layout */ "./node_modules/@carbon/layout/es/index.js");


/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
// Font family fallbacks for: IBM Plex Mono, IBM Plex Sans, IBM Plex Sans
// Condensed, IBM Plex Sans Hebrew, and IBM Plex Serif
var fontFamilies = {
  mono: "'IBM Plex Mono', 'Menlo', 'DejaVu Sans Mono', 'Bitstream Vera Sans Mono', Courier, monospace",
  sans: "'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif",
  sansCondensed: "'IBM Plex Sans Condensed', 'Helvetica Neue', Arial, sans-serif",
  sansHebrew: "'IBM Plex Sans Hebrew', 'Helvetica Hebrew', 'Arial Hebrew', sans-serif",
  serif: "'IBM Plex Serif', 'Georgia', Times, serif"
};
function fontFamily(name) {
  if (!fontFamilies[name]) {
    throw new Error("Unable to find font family: `".concat(name, "`. Expected one of: ") + "[".concat(Object.keys(fontFamilies).join(', '), "]"));
  }

  return {
    fontFamily: fontFamilies[name]
  };
}

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
var fontWeights = {
  light: 300,
  regular: 400,
  semibold: 600
};
function fontWeight(weight) {
  if (!fontWeights[weight]) {
    throw new Error("Unable to find font weight: `".concat(weight, "`. Expected one of: ") + "[".concat(Object.keys(fontWeights).join(', '), "]"));
  }

  return {
    fontWeight: fontWeights[weight]
  };
}

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
function print(block) {
  return Object.keys(block).reduce(function (acc, key, index) {
    // Short-circuit on the foreign key 'breakpoints'. This is used in our
    // tokens for fluid type and should not be printed. In the future, we should
    // tie this to media query outputs.
    if (key === 'breakpoints') {
      return acc;
    }

    var property = "".concat(paramCase(key), ": ").concat(block[key], ";");

    if (index === 0) {
      return property;
    }

    return acc + '\n' + property;
  }, '');
}

function paramCase(string) {
  var result = '';

  for (var i = 0; i < string.length; i++) {
    var character = string[i];

    if (character === character.toUpperCase()) {
      result += '-' + character.toLowerCase();
      continue;
    }

    result += character;
  }

  return result;
}

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
var reset = {
  html: {
    fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["px"])(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["baseFontSize"])
  },
  body: {
    fontFamily: fontFamilies.sans,
    fontWeight: fontWeights.regular,
    textRendering: 'optimizeLegibility',
    '-webkit-font-smoothing': 'antialiased',
    '-moz-osx-font-smoothing': 'grayscale'
  },
  strong: {
    fontWeight: fontWeights.semibold
  },
  code: {
    fontFamily: fontFamilies.mono
  }
};

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

/**
 * Get the type size for the given step
 * @param {number} step
 * @returns {number}
 */
function getTypeSize(step) {
  if (step <= 1) {
    return 12;
  } // Yn = Yn-1 + {FLOOR[(n - 2) / 4] + 1} * 2


  return getTypeSize(step - 1) + Math.floor((step - 2) / 4 + 1) * 2;
}
/**
 * The default type scale for 23 steps. Inlined as an array here through running
 * the follow step:
 *
 * > Array.from({ length: 23 }, (_, i) => getTypeSize(i + 1))
 */

var scale = [12, 14, 16, 18, 20, 24, 28, 32, 36, 42, 48, 54, 60, 68, 76, 84, 92, 102, 112, 122, 132, 144, 156];

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function (obj) {
      return typeof obj;
    };
  } else {
    _typeof = function (obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    if (enumerableOnly) symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    });
    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};

  var target = _objectWithoutPropertiesLoose(source, excluded);

  var key, i;

  if (Object.getOwnPropertySymbols) {
    var sourceSymbolKeys = Object.getOwnPropertySymbols(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

var caption01 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[0]),
  fontWeight: fontWeights.regular,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(16),
  letterSpacing: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["px"])(0.32)
};
var label01 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[0]),
  fontWeight: fontWeights.regular,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(16),
  letterSpacing: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["px"])(0.32)
};
var helperText01 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[0]),
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(16),
  letterSpacing: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["px"])(0.32)
};
var bodyShort01 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[1]),
  fontWeight: fontWeights.regular,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(18),
  letterSpacing: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["px"])(0.16)
};
var bodyLong01 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[1]),
  fontWeight: fontWeights.regular,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(20),
  letterSpacing: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["px"])(0.16)
};
var bodyShort02 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[2]),
  fontWeight: fontWeights.regular,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(22),
  letterSpacing: 0
};
var bodyLong02 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[2]),
  fontWeight: fontWeights.regular,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(24),
  letterSpacing: 0
};
var code01 = {
  fontFamily: fontFamilies.mono,
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[0]),
  fontWeight: fontWeights.regular,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(16),
  letterSpacing: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["px"])(0.32)
};
var code02 = {
  fontFamily: fontFamilies.mono,
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[1]),
  fontWeight: fontWeights.regular,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(20),
  letterSpacing: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["px"])(0.32)
};
var heading01 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[1]),
  fontWeight: fontWeights.semibold,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(18),
  letterSpacing: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["px"])(0.16)
};
var productiveHeading01 = heading01;
var heading02 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[2]),
  fontWeight: fontWeights.semibold,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(22),
  letterSpacing: 0
};
var productiveHeading02 = heading02;
var productiveHeading03 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[4]),
  fontWeight: fontWeights.regular,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(28),
  letterSpacing: 0
};
var productiveHeading04 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[6]),
  fontWeight: fontWeights.regular,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(36),
  letterSpacing: 0
};
var productiveHeading05 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[7]),
  fontWeight: fontWeights.regular,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(40),
  letterSpacing: 0
};
var productiveHeading06 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[9]),
  fontWeight: fontWeights.light,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(50),
  letterSpacing: 0
};
var productiveHeading07 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[11]),
  fontWeight: fontWeights.light,
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(64),
  letterSpacing: 0
};
var expressiveHeading01 = _objectSpread2(_objectSpread2({}, heading01), {}, {
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(20)
});
var expressiveHeading02 = _objectSpread2(_objectSpread2({}, heading02), {}, {
  lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(24)
});
var expressiveHeading03 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[4]),
  fontWeight: fontWeights.regular,
  lineHeight: '140%',
  letterSpacing: 0,
  breakpoints: {
    xlg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[4]),
      lineHeight: '125%'
    },
    max: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[5])
    }
  }
};
var expressiveHeading04 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[6]),
  fontWeight: fontWeights.regular,
  lineHeight: '129%',
  letterSpacing: 0,
  breakpoints: {
    xlg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[6]),
      lineHeight: '125%'
    },
    max: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[7])
    }
  }
};
var expressiveHeading05 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[7]),
  fontWeight: fontWeights.regular,
  lineHeight: '125%',
  letterSpacing: 0,
  breakpoints: {
    md: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[8]),
      fontWeight: fontWeights.light,
      lineHeight: '122%',
      letterSpacing: 0
    },
    lg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[9]),
      fontWeight: fontWeights.light,
      lineHeight: '119%',
      letterSpacing: 0
    },
    xlg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[10]),
      fontWeight: fontWeights.light,
      lineHeight: '117%',
      letterSpacing: 0
    },
    max: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[12]),
      fontWeight: fontWeights.light,
      lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(70),
      letterSpacing: 0
    }
  }
};
var expressiveHeading06 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[7]),
  fontWeight: fontWeights.semibold,
  lineHeight: '125%',
  letterSpacing: 0,
  breakpoints: {
    md: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[8]),
      fontWeight: fontWeights.semibold,
      lineHeight: '122%',
      letterSpacing: 0
    },
    lg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[9]),
      fontWeight: fontWeights.semibold,
      lineHeight: '119%',
      letterSpacing: 0
    },
    xlg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[10]),
      fontWeight: fontWeights.semibold,
      lineHeight: '117%',
      letterSpacing: 0
    },
    max: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[12]),
      fontWeight: fontWeights.semibold,
      lineHeight: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(70),
      letterSpacing: 0
    }
  }
};
var expressiveParagraph01 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[5]),
  fontWeight: fontWeights.light,
  lineHeight: '125%',
  letterSpacing: 0,
  lg: {
    fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[6]),
    lineHeight: '129%'
  },
  max: {
    fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[7]),
    lineHeight: '125%'
  }
};
var quotation01 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[4]),
  fontWeight: fontWeights.regular,
  lineHeight: '130%',
  letterSpacing: 0,
  breakpoints: {
    md: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[4]),
      fontWeight: fontWeights.regular,
      letterSpacing: 0
    },
    lg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[5]),
      fontWeight: fontWeights.regular,
      lineHeight: '125%',
      letterSpacing: 0
    },
    xlg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[6]),
      fontWeight: fontWeights.regular,
      lineHeight: '129%',
      letterSpacing: 0
    },
    max: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[7]),
      fontWeight: fontWeights.regular,
      lineHeight: '125%',
      letterSpacing: 0
    }
  }
};
var quotation02 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[7]),
  fontWeight: fontWeights.light,
  lineHeight: '125%',
  letterSpacing: 0,
  breakpoints: {
    md: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[8]),
      lineHeight: '122%'
    },
    lg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[9]),
      lineHeight: '119%'
    },
    xlg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[10]),
      lineHeight: '117%'
    },
    max: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[12])
    }
  }
};
var display01 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[9]),
  fontWeight: fontWeights.light,
  lineHeight: '119%',
  letterSpacing: 0,
  breakpoints: {
    md: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[9])
    },
    lg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[11])
    },
    xlg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[12]),
      lineHeight: '117%'
    },
    max: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[14]),
      lineHeight: '113%'
    }
  }
};
var display02 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[9]),
  fontWeight: fontWeights.semibold,
  lineHeight: '119%',
  letterSpacing: 0,
  breakpoints: {
    md: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[9])
    },
    lg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[11])
    },
    xlg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[12]),
      lineHeight: '116%'
    },
    max: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[14]),
      lineHeight: '113%'
    }
  }
};
var display03 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[9]),
  fontWeight: fontWeights.light,
  lineHeight: '119%',
  letterSpacing: 0,
  breakpoints: {
    md: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[13]),
      lineHeight: '115%'
    },
    lg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[16]),
      lineHeight: '111%',
      letterSpacing: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["px"])(-0.64)
    },
    xlg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[19]),
      lineHeight: '107%'
    },
    max: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[22]),
      lineHeight: '105%',
      letterSpacing: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["px"])(-0.96)
    }
  }
};
var display04 = {
  fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[9]),
  fontWeight: fontWeights.semibold,
  lineHeight: '119%',
  letterSpacing: 0,
  breakpoints: {
    md: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[13]),
      lineHeight: '115%'
    },
    lg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[16]),
      lineHeight: '111%',
      letterSpacing: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["px"])(-0.64)
    },
    xlg: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[19]),
      lineHeight: '107%',
      letterSpacing: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["px"])(-0.64)
    },
    max: {
      fontSize: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["rem"])(scale[22]),
      lineHeight: '105%',
      letterSpacing: Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["px"])(-0.96)
    }
  }
};

var styles = /*#__PURE__*/Object.freeze({
  caption01: caption01,
  label01: label01,
  helperText01: helperText01,
  bodyShort01: bodyShort01,
  bodyLong01: bodyLong01,
  bodyShort02: bodyShort02,
  bodyLong02: bodyLong02,
  code01: code01,
  code02: code02,
  heading01: heading01,
  productiveHeading01: productiveHeading01,
  heading02: heading02,
  productiveHeading02: productiveHeading02,
  productiveHeading03: productiveHeading03,
  productiveHeading04: productiveHeading04,
  productiveHeading05: productiveHeading05,
  productiveHeading06: productiveHeading06,
  productiveHeading07: productiveHeading07,
  expressiveHeading01: expressiveHeading01,
  expressiveHeading02: expressiveHeading02,
  expressiveHeading03: expressiveHeading03,
  expressiveHeading04: expressiveHeading04,
  expressiveHeading05: expressiveHeading05,
  expressiveHeading06: expressiveHeading06,
  expressiveParagraph01: expressiveParagraph01,
  quotation01: quotation01,
  quotation02: quotation02,
  display01: display01,
  display02: display02,
  display03: display03,
  display04: display04
});

var breakpointNames = Object.keys(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["breakpoints"]);

function next(name) {
  return breakpointNames[breakpointNames.indexOf(name) + 1];
}

function fluid(selector) {
  var fluidBreakpoints = selector.breakpoints,
      styles = _objectWithoutProperties(selector, ["breakpoints"]);

  if (_typeof(fluidBreakpoints) !== 'object') {
    return styles;
  }

  var fluidBreakpointNames = Object.keys(fluidBreakpoints);

  if (fluidBreakpointNames.length === 0) {
    return styles;
  }

  styles.fontSize = fluidTypeSize(styles, 'sm', fluidBreakpoints);
  fluidBreakpointNames.forEach(function (name) {
    styles[Object(_carbon_layout__WEBPACK_IMPORTED_MODULE_0__["breakpoint"])(name)] = _objectSpread2(_objectSpread2({}, fluidBreakpoints[name]), {}, {
      fontSize: fluidTypeSize(styles, name, fluidBreakpoints)
    });
  });
  return styles;
}

function fluidTypeSize(defaultStyles, fluidBreakpointName, fluidBreakpoints) {
  var breakpoint$$1 = _carbon_layout__WEBPACK_IMPORTED_MODULE_0__["breakpoints"][fluidBreakpointName];
  var fluidBreakpoint = fluidBreakpointName === 'sm' ? defaultStyles : fluidBreakpoints[fluidBreakpointName];
  var maxFontSize = defaultStyles.fontSize;
  var minFontSize = defaultStyles.fontSize;

  if (fluidBreakpoint.fontSize) {
    minFontSize = fluidBreakpoint.fontSize;
  }

  var maxViewportWidth = breakpoint$$1.width;
  var minViewportWidth = breakpoint$$1.width;
  var nextBreakpointAvailable = next(fluidBreakpointName);
  var nextFluidBreakpointName = null;

  while (nextBreakpointAvailable) {
    if (fluidBreakpoints[nextBreakpointAvailable]) {
      nextFluidBreakpointName = nextBreakpointAvailable;
      break;
    }

    nextBreakpointAvailable = next(nextBreakpointAvailable);
  }

  if (nextFluidBreakpointName) {
    var nextFluidBreakpoint = _carbon_layout__WEBPACK_IMPORTED_MODULE_0__["breakpoints"][nextFluidBreakpointName];
    maxFontSize = fluidBreakpoints[nextFluidBreakpointName].fontSize;
    maxViewportWidth = nextFluidBreakpoint.width;
    return "calc(".concat(minFontSize, " + ").concat(subtract(maxFontSize, minFontSize), " * ((100vw - ").concat(minViewportWidth, ") / ").concat(subtract(maxViewportWidth, minViewportWidth), "))");
  }

  return minFontSize;
}

function subtract(a, b) {
  return parseFloat(a) - parseFloat(b);
}

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
var unstable_tokens = ['caption01', 'label01', 'helperText01', 'bodyShort01', 'bodyLong01', 'bodyShort02', 'bodyLong02', 'code01', 'code02', 'heading01', 'productiveHeading01', 'heading02', 'productiveHeading02', 'productiveHeading03', 'productiveHeading04', 'productiveHeading05', 'productiveHeading06', 'productiveHeading07', 'expressiveHeading01', 'expressiveHeading02', 'expressiveHeading03', 'expressiveHeading04', 'expressiveHeading05', 'expressiveHeading06', 'expressiveParagraph01', 'quotation01', 'quotation02', 'display01', 'display02', 'display03', 'display04'];

/**
 * Copyright IBM Corp. 2018, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */




/***/ }),

/***/ "./node_modules/carbon-components/es/components/accordion/accordion.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/accordion/accordion.js ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */










var Accordion = /*#__PURE__*/function (_mixin) {
  _inherits(Accordion, _mixin);

  var _super = _createSuper(Accordion);
  /**
   * Accordion.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as an accordion.
   */


  function Accordion(element, options) {
    var _this;

    _classCallCheck(this, Accordion);

    _this = _super.call(this, element, options);

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element, 'click', function (event) {
      var item = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__["default"])(event, _this.options.selectorAccordionItem);

      if (item && !Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__["default"])(event, _this.options.selectorAccordionContent)) {
        _this._toggle(item);
      }
    }));
    /**
     *
     *  DEPRECATE in v8
     *
     *  Swapping to a button elemenet instead of a div
     *  automatically maps click events to keypress as well
     *  This event listener now is only added if user is using
     *  the older markup
     */


    if (!_this._checkIfButton()) {
      _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element, 'keypress', function (event) {
        var item = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__["default"])(event, _this.options.selectorAccordionItem);

        if (item && !Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__["default"])(event, _this.options.selectorAccordionContent)) {
          _this._handleKeypress(event);
        }
      }));
    }

    return _this;
  }

  _createClass(Accordion, [{
    key: "_checkIfButton",
    value: function _checkIfButton() {
      return this.element.firstElementChild.firstElementChild.nodeName === 'BUTTON';
    }
    /**
     * Handles toggling of active state of accordion via keyboard
     * @param {Event} event The event triggering this method.
     */

  }, {
    key: "_handleKeypress",
    value: function _handleKeypress(event) {
      if (event.which === 13 || event.which === 32) {
        this._toggle(event.target);
      }
    }
  }, {
    key: "_toggle",
    value: function _toggle(element) {
      var heading = element.querySelector(this.options.selectorAccordionItemHeading);
      var expanded = heading.getAttribute('aria-expanded');

      if (expanded !== null) {
        heading.setAttribute('aria-expanded', expanded === 'true' ? 'false' : 'true');
      }

      element.classList.toggle(this.options.classActive);
    }
    /**
     * The component options.
     * If `options` is specified in the constructor,
     * {@linkcode NumberInput.create .create()}, or {@linkcode NumberInput.init .init()},
     * properties in this object are overriden for the instance being create and how {@linkcode NumberInput.init .init()} works.
     * @property {string} selectorInit The CSS selector to find accordion UIs.
     */

  }], [{
    key: "options",
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-accordion]',
        selectorAccordionItem: ".".concat(prefix, "--accordion__item"),
        selectorAccordionItemHeading: ".".concat(prefix, "--accordion__heading"),
        selectorAccordionContent: ".".concat(prefix, "--accordion__content"),
        classActive: "".concat(prefix, "--accordion__item--active")
      };
    }
    /**
     * The map associating DOM element and accordion UI instance.
     * @type {WeakMap}
     */

  }]);

  Accordion.components = new WeakMap();
  return Accordion;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (Accordion);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/checkbox/checkbox.js":
/*!***************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/checkbox/checkbox.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */








var stateChangeTypes = {
  true: 'true',
  false: 'false',
  mixed: 'mixed'
};

var Checkbox = /*#__PURE__*/function (_mixin) {
  _inherits(Checkbox, _mixin);

  var _super = _createSuper(Checkbox);
  /**
   * Checkbox UI.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as a checkbox UI.
   */


  function Checkbox(element, options) {
    var _this;

    _classCallCheck(this, Checkbox);

    _this = _super.call(this, element, options);

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__["default"])(_this.element, 'click', function (event) {
      _this._handleClick(event);
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__["default"])(_this.element, 'focus', function (event) {
      _this._handleFocus(event);
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__["default"])(_this.element, 'blur', function (event) {
      _this._handleBlur(event);
    }));

    _this._indeterminateCheckbox();

    _this._initCheckbox();

    return _this;
  }

  _createClass(Checkbox, [{
    key: "_handleClick",
    value: function _handleClick() {
      if (this.element.checked === true) {
        this.element.setAttribute('checked', '');
        this.element.setAttribute('aria-checked', 'true');
        this.element.checked = true; // nested checkboxes inside labels

        if (this.element.parentElement.classList.contains(this.options.classLabel)) {
          this.element.parentElement.setAttribute(this.options.attribContainedCheckboxState, 'true');
        }
      } else if (this.element.checked === false) {
        this.element.removeAttribute('checked');
        this.element.setAttribute('aria-checked', 'false');
        this.element.checked = false; // nested checkboxes inside labels

        if (this.element.parentElement.classList.contains(this.options.classLabel)) {
          this.element.parentElement.setAttribute(this.options.attribContainedCheckboxState, 'false');
        }
      }
    }
  }, {
    key: "_handleFocus",
    value: function _handleFocus() {
      if (this.element.parentElement.classList.contains(this.options.classLabel)) {
        this.element.parentElement.classList.add(this.options.classLabelFocused);
      }
    }
  }, {
    key: "_handleBlur",
    value: function _handleBlur() {
      if (this.element.parentElement.classList.contains(this.options.classLabel)) {
        this.element.parentElement.classList.remove(this.options.classLabelFocused);
      }
    }
    /**
     * Sets the new checkbox state.
     * @param {boolean|string} [state]
     *   The new checkbox state to set. `mixed` to put checkbox in indeterminate state.
     *   If omitted, this method simply makes the style reflect `aria-checked` attribute.
     */

  }, {
    key: "setState",
    value: function setState(state) {
      if (state === undefined || stateChangeTypes[state] === undefined) {
        throw new TypeError('setState expects a value of true, false or mixed.');
      }

      this.element.setAttribute('aria-checked', state);
      this.element.indeterminate = state === stateChangeTypes.mixed;
      this.element.checked = state === stateChangeTypes.true;
      var container = this.element.closest(this.options.selectorContainedCheckboxState);

      if (container) {
        container.setAttribute(this.options.attribContainedCheckboxState, state);
      }
    }
  }, {
    key: "setDisabled",
    value: function setDisabled(value) {
      if (value === undefined) {
        throw new TypeError('setDisabled expects a boolean value of true or false');
      }

      if (value === true) {
        this.element.setAttribute('disabled', true);
      } else if (value === false) {
        this.element.removeAttribute('disabled');
      }

      var container = this.element.closest(this.options.selectorContainedCheckboxDisabled);

      if (container) {
        container.setAttribute(this.options.attribContainedCheckboxDisabled, value);
      }
    }
  }, {
    key: "_indeterminateCheckbox",
    value: function _indeterminateCheckbox() {
      if (this.element.getAttribute('aria-checked') === 'mixed') {
        this.element.indeterminate = true;
      }

      if (this.element.indeterminate === true) {
        this.element.setAttribute('aria-checked', 'mixed');
      }

      if (this.element.parentElement.classList.contains(this.options.classLabel) && this.element.indeterminate === true) {
        this.element.parentElement.setAttribute(this.options.attribContainedCheckboxState, 'mixed');
      }
    }
  }, {
    key: "_initCheckbox",
    value: function _initCheckbox() {
      if (this.element.checked === true) {
        this.element.setAttribute('aria-checked', 'true');
      }

      if (this.element.parentElement.classList.contains(this.options.classLabel) && this.element.checked) {
        this.element.parentElement.setAttribute(this.options.attribContainedCheckboxState, 'true');
      }

      if (this.element.parentElement.classList.contains(this.options.classLabel)) {
        this.element.parentElement.setAttribute(this.options.attribContainedCheckboxDisabled, 'false');
      }

      if (this.element.parentElement.classList.contains(this.options.classLabel) && this.element.disabled) {
        this.element.parentElement.setAttribute(this.options.attribContainedCheckboxDisabled, 'true');
      }
    }
    /**
     * The map associating DOM element and copy button UI instance.
     * @member Checkbox.components
     * @type {WeakMap}
     */

  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor, {@linkcode Checkbox.create .create()}, or {@linkcode Checkbox.init .init()},
     * properties in this object are overriden for the instance being create and how {@linkcode Checkbox.init .init()} works.
     * @member Checkbox.options
     * @type {object}
     * @property {string} selectorInit The data attribute to find copy button UIs.
     * @property {string} selectorContainedCheckboxState The CSS selector to find a container of checkbox preserving checked state.
     * @property {string} selectorContainedCheckboxDisabled
     *   The CSS selector to find a container of checkbox preserving disabled state.
     * @property {string} classLabel The CSS class for the label.
     * @property {string} classLabelFocused The CSS class for the focused label.
     * @property {string} attribContainedCheckboxState The attribute name for the checked state of contained checkbox.
     * @property {string} attribContainedCheckboxDisabled The attribute name for the disabled state of contained checkbox.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: ".".concat(prefix, "--checkbox"),
        selectorContainedCheckboxState: '[data-contained-checkbox-state]',
        selectorContainedCheckboxDisabled: '[data-contained-checkbox-disabled]',
        classLabel: "".concat(prefix, "--checkbox-label"),
        classLabelFocused: "".concat(prefix, "--checkbox-label__focus"),
        attribContainedCheckboxState: 'data-contained-checkbox-state',
        attribContainedCheckboxDisabled: 'data-contained-checkbox-disabled'
      };
    }
  }]);

  Checkbox.components = new WeakMap();
  Checkbox.stateChangeTypes = stateChangeTypes;
  return Checkbox;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (Checkbox);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/code-snippet/code-snippet.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/code-snippet/code-snippet.js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */








var CodeSnippet = /*#__PURE__*/function (_mixin) {
  _inherits(CodeSnippet, _mixin);

  var _super = _createSuper(CodeSnippet);
  /**
   * CodeSnippet UI.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as a CodeSnippet UI.
   */


  function CodeSnippet(element, options) {
    var _this;

    _classCallCheck(this, CodeSnippet);

    _this = _super.call(this, element, options);

    _this._initCodeSnippet();

    _this.element.querySelector(_this.options.classExpandBtn).addEventListener('click', function (evt) {
      return _this._handleClick(evt);
    });

    return _this;
  }

  _createClass(CodeSnippet, [{
    key: "_handleClick",
    value: function _handleClick() {
      var expandBtn = this.element.querySelector(this.options.classExpandText);
      this.element.classList.toggle(this.options.classExpanded);

      if (this.element.classList.contains(this.options.classExpanded)) {
        expandBtn.textContent = expandBtn.getAttribute(this.options.attribShowLessText);
      } else {
        expandBtn.textContent = expandBtn.getAttribute(this.options.attribShowMoreText);
      }
    }
  }, {
    key: "_initCodeSnippet",
    value: function _initCodeSnippet() {
      var expandBtn = this.element.querySelector(this.options.classExpandText);

      if (!expandBtn) {
        throw new TypeError('Cannot find the expand button.');
      }

      expandBtn.textContent = expandBtn.getAttribute(this.options.attribShowMoreText);

      if (this.element.offsetHeight < this.options.minHeight) {
        this.element.classList.add(this.options.classHideExpand);
      }
    }
    /**
     * The map associating DOM element and code snippet UI instance.
     * @member CodeSnippet.components
     * @type {WeakMap}
     */

  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor, {@linkcode CodeSnippet.create .create()},
     * or {@linkcode CodeSnippet.init .init()},
     * properties in this object are overriden for the instance being create and how {@linkcode CodeSnippet.init .init()} works.
     * @member CodeSnippet.options
     * @type {object}
     * @property {string} selectorInit The data attribute to find code snippet UIs.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-code-snippet]',
        attribShowMoreText: 'data-show-more-text',
        attribShowLessText: 'data-show-less-text',
        minHeight: 288,
        classExpanded: "".concat(prefix, "--snippet--expand"),
        classExpandBtn: ".".concat(prefix, "--snippet-btn--expand"),
        classExpandText: ".".concat(prefix, "--snippet-btn--text"),
        classHideExpand: "".concat(prefix, "--snippet-btn--expand--hide")
      };
    }
  }]);

  CodeSnippet.components = new WeakMap();
  return CodeSnippet;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (CodeSnippet);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/content-switcher/content-switcher.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/content-switcher/content-switcher.js ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_evented_state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/evented-state */ "./node_modules/carbon-components/es/globals/js/mixins/evented-state.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */











var toArray = function toArray(arrayLike) {
  return Array.prototype.slice.call(arrayLike);
};

var ContentSwitcher = /*#__PURE__*/function (_mixin) {
  _inherits(ContentSwitcher, _mixin);

  var _super = _createSuper(ContentSwitcher);
  /**
   * Set of content switcher buttons.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends EventedState
   * @extends Handles
   * @param {HTMLElement} element The element working as a set of content switcher buttons.
   * @param {object} [options] The component options.
   * @param {string} [options.selectorButton] The CSS selector to find switcher buttons.
   * @param {string} [options.selectorButtonSelected] The CSS selector to find the selected switcher button.
   * @param {string} [options.classActive] The CSS class for switcher button's selected state.
   * @param {string} [options.eventBeforeSelected]
   *   The name of the custom event fired before a switcher button is selected.
   *   Cancellation of this event stops selection of content switcher button.
   * @param {string} [options.eventAfterSelected] The name of the custom event fired after a switcher button is selected.
   */


  function ContentSwitcher(element, options) {
    var _this;

    _classCallCheck(this, ContentSwitcher);

    _this = _super.call(this, element, options);

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.element, 'click', function (event) {
      _this._handleClick(event);
    }));

    return _this;
  }
  /**
   * Handles click on content switcher button set.
   * If the click is on a content switcher button, activates it.
   * @param {Event} event The event triggering this method.
   */


  _createClass(ContentSwitcher, [{
    key: "_handleClick",
    value: function _handleClick(event) {
      var button = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__["default"])(event, this.options.selectorButton);

      if (button) {
        this.changeState({
          group: 'selected',
          item: button,
          launchingEvent: event
        });
      }
    }
    /**
     * Internal method of {@linkcode ContentSwitcher#setActive .setActive()}, to select a content switcher button.
     * @private
     * @param {object} detail The detail of the event trigging this action.
     * @param {HTMLElement} detail.item The button to be selected.
     * @param {Function} callback Callback called when change in state completes.
     */

  }, {
    key: "_changeState",
    value: function _changeState(_ref, callback) {
      var _this2 = this;

      var item = _ref.item; // `options.selectorLink` is not defined in this class itself, code here primary is for inherited classes

      var itemLink = item.querySelector(this.options.selectorLink);

      if (itemLink) {
        toArray(this.element.querySelectorAll(this.options.selectorLink)).forEach(function (link) {
          if (link !== itemLink) {
            link.setAttribute('aria-selected', 'false');
          }
        });
        itemLink.setAttribute('aria-selected', 'true');
      }

      var selectorButtons = toArray(this.element.querySelectorAll(this.options.selectorButton));
      selectorButtons.forEach(function (button) {
        if (button !== item) {
          button.setAttribute('aria-selected', false);
          button.classList.toggle(_this2.options.classActive, false);
          toArray(button.ownerDocument.querySelectorAll(button.dataset.target)).forEach(function (element) {
            element.setAttribute('hidden', '');
            element.setAttribute('aria-hidden', 'true');
          });
        }
      });
      item.classList.toggle(this.options.classActive, true);
      item.setAttribute('aria-selected', true);
      toArray(item.ownerDocument.querySelectorAll(item.dataset.target)).forEach(function (element) {
        element.removeAttribute('hidden');
        element.setAttribute('aria-hidden', 'false');
      });

      if (callback) {
        callback();
      }
    }
    /**
     * Selects a content switcher button.
     * If the selected button has `data-target` attribute, DOM elements it points to as a CSS selector will be shown.
     * DOM elements associated with unselected buttons in the same way will be hidden.
     * @param {HTMLElement} item The button to be selected.
     * @param {ChangeState~callback} callback The callback is called once selection is finished
     * or is canceled. Will only invoke callback if it's passed in.
     */

  }, {
    key: "setActive",
    value: function setActive(item, callback) {
      this.changeState({
        group: 'selected',
        item: item
      }, function (error) {
        if (error) {
          if (callback) {
            callback(Object.assign(error, {
              item: item
            }));
          }
        } else if (callback) {
          callback(null, item);
        }
      });
    }
    /**
     * The map associating DOM element and content switcher set instance.
     * @member ContentSwitcher.components
     * @type {WeakMap}
     */

  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor,
     * {@linkcode ContentSwitcher.create .create()}, or {@linkcode ContentSwitcher.init .init()},
     * properties in this object are overriden for the instance being create and how {@linkcode ContentSwitcher.init .init()} works.
     * @member ContentSwitcher.options
     * @type {object}
     * @property {string} selectorInit The CSS selector to find content switcher button set.
     * @property {string} [selectorButton] The CSS selector to find switcher buttons.
     * @property {string} [selectorButtonSelected] The CSS selector to find the selected switcher button.
     * @property {string} [classActive] The CSS class for switcher button's selected state.
     * @property {string} [eventBeforeSelected]
     *   The name of the custom event fired before a switcher button is selected.
     *   Cancellation of this event stops selection of content switcher button.
     * @property {string} [eventAfterSelected] The name of the custom event fired after a switcher button is selected.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-content-switcher]',
        selectorButton: "input[type=\"radio\"], .".concat(prefix, "--content-switcher-btn"),
        classActive: "".concat(prefix, "--content-switcher--selected"),
        eventBeforeSelected: 'content-switcher-beingselected',
        eventAfterSelected: 'content-switcher-selected'
      };
    }
  }]);

  ContentSwitcher.components = new WeakMap();
  return ContentSwitcher;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_evented_state__WEBPACK_IMPORTED_MODULE_4__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (ContentSwitcher);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/copy-button/copy-button.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/copy-button/copy-button.js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */









var CopyButton = /*#__PURE__*/function (_mixin) {
  _inherits(CopyButton, _mixin);

  var _super = _createSuper(CopyButton);
  /**
   * CopyBtn UI.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as a copy button UI.
   */


  function CopyButton(element, options) {
    var _this;

    _classCallCheck(this, CopyButton);

    _this = _super.call(this, element, options);

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__["default"])(_this.element, 'click', function () {
      return _this.handleClick();
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__["default"])(_this.element, 'animationend', function (event) {
      return _this.handleAnimationEnd(event);
    }));

    return _this;
  }
  /**
   * Cleanup animation classes
   */


  _createClass(CopyButton, [{
    key: "handleAnimationEnd",
    value: function handleAnimationEnd(event) {
      if (event.animationName === 'hide-feedback') {
        this.element.classList.remove(this.options.classAnimating);
        this.element.classList.remove(this.options.classFadeOut);
      }
    }
    /**
     * Show the feedback tooltip on click. Hide the feedback tooltip after specified timeout value.
     */

  }, {
    key: "handleClick",
    value: function handleClick() {
      var _this2 = this;

      var feedback = this.element.querySelector(this.options.feedbackTooltip);

      if (feedback) {
        feedback.classList.add(this.options.classShowFeedback);
        setTimeout(function () {
          feedback.classList.remove(_this2.options.classShowFeedback);
        }, this.options.timeoutValue);
      } else {
        this.element.classList.add(this.options.classAnimating);
        this.element.classList.add(this.options.classFadeIn);
        setTimeout(function () {
          _this2.element.classList.remove(_this2.options.classFadeIn);

          _this2.element.classList.add(_this2.options.classFadeOut);
        }, this.options.timeoutValue);
      }
    }
    /**
     * The map associating DOM element and copy button UI instance.
     * @member CopyBtn.components
     * @type {WeakMap}
     */

  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor, {@linkcode CopyBtn.create .create()}, or {@linkcode CopyBtn.init .init()},
     * properties in this object are overriden for the instance being create and how {@linkcode CopyBtn.init .init()} works.
     * @member CopyBtn.options
     * @type {object}
     * @property {string} selectorInit The data attribute to find copy button UIs.
     * @property {string} feedbackTooltip The data attribute to find feedback tooltip.
     * @property {string} classShowFeedback The CSS selector for showing the feedback tooltip.
     * @property {number} timeoutValue The specified timeout value before the feedback tooltip is hidden.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-copy-btn]',
        feedbackTooltip: '[data-feedback]',
        classShowFeedback: "".concat(prefix, "--btn--copy__feedback--displayed"),
        classAnimating: "".concat(prefix, "--copy-btn--animating"),
        classFadeIn: "".concat(prefix, "--copy-btn--fade-in"),
        classFadeOut: "".concat(prefix, "--copy-btn--fade-out"),
        timeoutValue: 2000
      };
    }
  }]);

  CopyButton.components = new WeakMap();
  return CopyButton;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (CopyButton);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/data-table-v2/data-table-v2.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/data-table-v2/data-table-v2.js ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _data_table_data_table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../data-table/data-table */ "./node_modules/carbon-components/es/components/data-table/data-table.js");
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

/* harmony default export */ __webpack_exports__["default"] = (_data_table_data_table__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/data-table/data-table.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/data-table/data-table.js ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_evented_state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/evented-state */ "./node_modules/carbon-components/es/globals/js/mixins/evented-state.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */











var toArray = function toArray(arrayLike) {
  return Array.prototype.slice.call(arrayLike);
};

var DataTable = /*#__PURE__*/function (_mixin) {
  _inherits(DataTable, _mixin);

  var _super = _createSuper(DataTable);
  /**
   * Data Table
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends   EventedState
   * @param {HTMLElement} element The root element of tables
   * @param {object} [options] the... options
   * @param {string} [options.selectorInit] selector initialization
   * @param {string} [options.selectorExpandCells] css selector for expand
   * @param {string} [options.expandableRow] css selector for expand
   * @param {string} [options.selectorParentRows] css selector for rows housing expansion
   * @param {string} [options.selectorTableBody] root css for table body
   * @param {string} [options.eventTrigger] selector for event bubble capture points
   * @param {string} [options.eventParentContainer] used find the bubble container
   */


  function DataTable(_element, options) {
    var _this;

    _classCallCheck(this, DataTable);

    _this = _super.call(this, _element, options);

    _this._sortToggle = function (detail) {
      var element = detail.element,
          previousValue = detail.previousValue;
      toArray(_this.tableHeaders).forEach(function (header) {
        var sortEl = header.querySelector(_this.options.selectorTableSort);

        if (sortEl !== null && sortEl !== element) {
          sortEl.classList.remove(_this.options.classTableSortActive);
          sortEl.classList.remove(_this.options.classTableSortAscending);
        }
      });

      if (!previousValue) {
        element.dataset.previousValue = 'ascending';
        element.classList.add(_this.options.classTableSortActive);
        element.classList.add(_this.options.classTableSortAscending);
      } else if (previousValue === 'ascending') {
        element.dataset.previousValue = 'descending';
        element.classList.add(_this.options.classTableSortActive);
        element.classList.remove(_this.options.classTableSortAscending);
      } else if (previousValue === 'descending') {
        element.removeAttribute('data-previous-value');
        element.classList.remove(_this.options.classTableSortActive);
        element.classList.remove(_this.options.classTableSortAscending);
      }
    };

    _this._selectToggle = function (detail) {
      var element = detail.element;
      var checked = element.checked; // increment the  count

      _this.state.checkboxCount += checked ? 1 : -1;
      _this.countEl.textContent = _this.state.checkboxCount;
      var row = element.parentNode.parentNode;
      row.classList.toggle(_this.options.classTableSelected); // toggle on/off batch action bar

      _this._actionBarToggle(_this.state.checkboxCount > 0);
    };

    _this._selectAllToggle = function (_ref) {
      var element = _ref.element;
      var checked = element.checked;
      var inputs = toArray(_this.element.querySelectorAll(_this.options.selectorCheckbox));
      _this.state.checkboxCount = checked ? inputs.length - 1 : 0;
      inputs.forEach(function (item) {
        item.checked = checked;
        var row = item.parentNode.parentNode;

        if (checked && row) {
          row.classList.add(_this.options.classTableSelected);
        } else {
          row.classList.remove(_this.options.classTableSelected);
        }
      });

      _this._actionBarToggle(_this.state.checkboxCount > 0);

      if (_this.batchActionEl) {
        _this.countEl.textContent = _this.state.checkboxCount;
      }
    };

    _this._actionBarCancel = function () {
      var inputs = toArray(_this.element.querySelectorAll(_this.options.selectorCheckbox));
      var row = toArray(_this.element.querySelectorAll(_this.options.selectorTableSelected));
      row.forEach(function (item) {
        item.classList.remove(_this.options.classTableSelected);
      });
      inputs.forEach(function (item) {
        item.checked = false;
      });
      _this.state.checkboxCount = 0;

      _this._actionBarToggle(false);

      if (_this.batchActionEl) {
        _this.countEl.textContent = _this.state.checkboxCount;
      }
    };

    _this._actionBarToggle = function (toggleOn) {
      var handleTransitionEnd;

      var transition = function transition(evt) {
        if (handleTransitionEnd) {
          handleTransitionEnd = _this.unmanage(handleTransitionEnd).release();
        }

        if (evt.target.matches(_this.options.selectorActions)) {
          if (_this.batchActionEl.dataset.active === 'false') {
            _this.batchActionEl.setAttribute('tabIndex', -1);
          } else {
            _this.batchActionEl.setAttribute('tabIndex', 0);
          }
        }
      };

      if (toggleOn) {
        _this.batchActionEl.dataset.active = true;

        _this.batchActionEl.classList.add(_this.options.classActionBarActive);
      } else if (_this.batchActionEl) {
        _this.batchActionEl.dataset.active = false;

        _this.batchActionEl.classList.remove(_this.options.classActionBarActive);
      }

      if (_this.batchActionEl) {
        handleTransitionEnd = _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.batchActionEl, 'transitionend', transition));
      }
    };

    _this._rowExpandToggle = function (_ref2) {
      var element = _ref2.element,
          forceExpand = _ref2.forceExpand;
      var parent = element.closest(_this.options.eventParentContainer); // NOTE: `data-previous-value` keeps UI state before this method makes change in style
      // eslint-disable-next-line eqeqeq

      var shouldExpand = forceExpand != null ? forceExpand : element.dataset.previousValue === undefined || element.dataset.previousValue === 'expanded';

      if (shouldExpand) {
        element.dataset.previousValue = 'collapsed';
        parent.classList.add(_this.options.classExpandableRow);
      } else {
        parent.classList.remove(_this.options.classExpandableRow);
        element.dataset.previousValue = 'expanded';

        var expandHeader = _this.element.querySelector(_this.options.selectorExpandHeader);

        if (expandHeader) {
          expandHeader.dataset.previousValue = 'expanded';
        }
      }
    };

    _this._rowExpandToggleAll = function (_ref3) {
      var element = _ref3.element; // NOTE: `data-previous-value` keeps UI state before this method makes change in style

      var shouldExpand = element.dataset.previousValue === undefined || element.dataset.previousValue === 'expanded';
      element.dataset.previousValue = shouldExpand ? 'collapsed' : 'expanded';

      var expandCells = _this.element.querySelectorAll(_this.options.selectorExpandCells);

      Array.prototype.forEach.call(expandCells, function (cell) {
        _this._rowExpandToggle({
          element: cell,
          forceExpand: shouldExpand
        });
      });
    };

    _this._expandableHoverToggle = function (evt) {
      var element = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__["default"])(evt, _this.options.selectorChildRow);

      if (element) {
        element.previousElementSibling.classList.toggle(_this.options.classExpandableRowHover, evt.type === 'mouseover');
      }
    };

    _this._toggleState = function (element, evt) {
      var data = element.dataset;
      var label = data.label ? data.label : '';
      var previousValue = data.previousValue ? data.previousValue : '';
      var initialEvt = evt;

      _this.changeState({
        group: data.event,
        element: element,
        label: label,
        previousValue: previousValue,
        initialEvt: initialEvt
      });
    };

    _this._keydownHandler = function (evt) {
      var searchContainer = _this.element.querySelector(_this.options.selectorToolbarSearchContainer);

      var searchEvent = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__["default"])(evt, _this.options.selectorSearchMagnifier);
      var activeSearch = searchContainer.classList.contains(_this.options.classToolbarSearchActive);

      if (evt.which === 27) {
        _this._actionBarCancel();
      }

      if (searchContainer && searchEvent && evt.which === 13) {
        _this.activateSearch(searchContainer);
      }

      if (activeSearch && evt.which === 27) {
        _this.deactivateSearch(searchContainer, evt);
      }
    };

    _this.refreshRows = function () {
      var newExpandCells = toArray(_this.element.querySelectorAll(_this.options.selectorExpandCells));
      var newExpandableRows = toArray(_this.element.querySelectorAll(_this.options.selectorExpandableRows));
      var newParentRows = toArray(_this.element.querySelectorAll(_this.options.selectorParentRows)); // check if this is a refresh or the first time

      if (_this.parentRows.length > 0) {
        var diffParentRows = newParentRows.filter(function (newRow) {
          return !_this.parentRows.some(function (oldRow) {
            return oldRow === newRow;
          });
        }); // check if there are expandable rows

        if (newExpandableRows.length > 0) {
          var diffExpandableRows = diffParentRows.map(function (newRow) {
            return newRow.nextElementSibling;
          });
          var mergedExpandableRows = [].concat(_toConsumableArray(toArray(_this.expandableRows)), _toConsumableArray(toArray(diffExpandableRows)));
          _this.expandableRows = mergedExpandableRows;
        }
      } else if (newExpandableRows.length > 0) {
        _this.expandableRows = newExpandableRows;
      }

      _this.expandCells = newExpandCells;
      _this.parentRows = newParentRows;
    };

    _this.container = _element.parentNode;
    _this.toolbarEl = _this.element.querySelector(_this.options.selectorToolbar);
    _this.batchActionEl = _this.element.querySelector(_this.options.selectorActions);
    _this.countEl = _this.element.querySelector(_this.options.selectorCount);
    _this.cancelEl = _this.element.querySelector(_this.options.selectorActionCancel);
    _this.tableHeaders = _this.element.querySelectorAll('th');
    _this.tableBody = _this.element.querySelector(_this.options.selectorTableBody);
    _this.expandCells = [];
    _this.expandableRows = [];
    _this.parentRows = [];

    _this.refreshRows();

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.element, 'mouseover', _this._expandableHoverToggle));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.element, 'mouseout', _this._expandableHoverToggle));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.element, 'click', function (evt) {
      var eventElement = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__["default"])(evt, _this.options.eventTrigger);

      var searchContainer = _this.element.querySelector(_this.options.selectorToolbarSearchContainer);

      if (eventElement) {
        _this._toggleState(eventElement, evt);
      }

      if (searchContainer) {
        _this._handleDocumentClick(evt);
      }
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.element, 'keydown', _this._keydownHandler));

    _this.state = {
      checkboxCount: 0
    };
    return _this;
  }

  _createClass(DataTable, [{
    key: "_handleDocumentClick",
    value: function _handleDocumentClick(evt) {
      var searchContainer = this.element.querySelector(this.options.selectorToolbarSearchContainer);
      var searchEvent = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__["default"])(evt, this.options.selectorSearchMagnifier);
      var activeSearch = searchContainer.classList.contains(this.options.classToolbarSearchActive);

      if (searchContainer && searchEvent) {
        this.activateSearch(searchContainer);
      }

      if (activeSearch) {
        this.deactivateSearch(searchContainer, evt);
      }
    }
  }, {
    key: "activateSearch",
    value: function activateSearch(container) {
      var input = container.querySelector(this.options.selectorSearchInput);
      container.classList.add(this.options.classToolbarSearchActive);
      input.focus();
    }
  }, {
    key: "deactivateSearch",
    value: function deactivateSearch(container, evt) {
      var trigger = container.querySelector(this.options.selectorSearchMagnifier);
      var input = container.querySelector(this.options.selectorSearchInput);
      var svg = trigger.querySelector('svg');

      if (input.value.length === 0 && evt.target !== input && evt.target !== trigger && evt.target !== svg) {
        container.classList.remove(this.options.classToolbarSearchActive);
        trigger.focus();
      }

      if (evt.which === 27 && evt.target === input) {
        container.classList.remove(this.options.classToolbarSearchActive);
        trigger.focus();
      }
    }
  }, {
    key: "_changeState",
    value: function _changeState(detail, callback) {
      this[this.constructor.eventHandlers[detail.group]](detail);
      callback();
    }
  }], [{
    key: "options",
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: "[data-table]",
        selectorToolbar: ".".concat(prefix, "--table--toolbar"),
        selectorActions: ".".concat(prefix, "--batch-actions"),
        selectorCount: '[data-items-selected]',
        selectorActionCancel: ".".concat(prefix, "--batch-summary__cancel"),
        selectorCheckbox: ".".concat(prefix, "--checkbox"),
        selectorExpandHeader: "th.".concat(prefix, "--table-expand"),
        selectorExpandCells: "td.".concat(prefix, "--table-expand"),
        selectorExpandableRows: ".".concat(prefix, "--expandable-row"),
        selectorParentRows: ".".concat(prefix, "--parent-row"),
        selectorChildRow: '[data-child-row]',
        selectorTableBody: 'tbody',
        selectorTableSort: ".".concat(prefix, "--table-sort"),
        selectorTableSelected: ".".concat(prefix, "--data-table--selected"),
        selectorToolbarSearchContainer: ".".concat(prefix, "--toolbar-search-container-expandable"),
        selectorSearchMagnifier: ".".concat(prefix, "--search-magnifier"),
        selectorSearchInput: ".".concat(prefix, "--search-input"),
        classExpandableRow: "".concat(prefix, "--expandable-row"),
        classExpandableRowHidden: "".concat(prefix, "--expandable-row--hidden"),
        classExpandableRowHover: "".concat(prefix, "--expandable-row--hover"),
        classTableSortAscending: "".concat(prefix, "--table-sort--ascending"),
        classTableSortActive: "".concat(prefix, "--table-sort--active"),
        classToolbarSearchActive: "".concat(prefix, "--toolbar-search-container-active"),
        classActionBarActive: "".concat(prefix, "--batch-actions--active"),
        classTableSelected: "".concat(prefix, "--data-table--selected"),
        eventBeforeExpand: "data-table-beforetoggleexpand",
        eventAfterExpand: "data-table-aftertoggleexpand",
        eventBeforeExpandAll: "data-table-beforetoggleexpandall",
        eventAfterExpandAll: "data-table-aftertoggleexpandall",
        eventBeforeSort: "data-table-beforetogglesort",
        eventAfterSort: "data-table-aftertogglesort",
        eventTrigger: '[data-event]',
        eventParentContainer: '[data-parent-row]'
      };
    }
  }]);

  DataTable.components = new WeakMap();
  DataTable.eventHandlers = {
    expand: '_rowExpandToggle',
    expandAll: '_rowExpandToggleAll',
    sort: '_sortToggle',
    select: '_selectToggle',
    'select-all': '_selectAllToggle',
    'action-bar-cancel': '_actionBarCancel'
  };
  return DataTable;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_evented_state__WEBPACK_IMPORTED_MODULE_4__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (DataTable);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/date-picker/date-picker.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/date-picker/date-picker.js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var flatpickr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! flatpickr */ "./node_modules/flatpickr/dist/flatpickr.js");
/* harmony import */ var flatpickr__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(flatpickr__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _get(target, property, receiver) {
  if (typeof Reflect !== "undefined" && Reflect.get) {
    _get = Reflect.get;
  } else {
    _get = function _get(target, property, receiver) {
      var base = _superPropBase(target, property);

      if (!base) return;
      var desc = Object.getOwnPropertyDescriptor(base, property);

      if (desc.get) {
        return desc.get.call(receiver);
      }

      return desc.value;
    };
  }

  return _get(target, property, receiver || target);
}

function _superPropBase(object, property) {
  while (!Object.prototype.hasOwnProperty.call(object, property)) {
    object = _getPrototypeOf(object);
    if (object === null) break;
  }

  return object;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */









/* eslint no-underscore-dangle: [2, { "allow": ["_input", "_updateClassNames", "_updateInputFields"], "allowAfterThis": true }] */
// `this.options` create-component mix-in creates prototype chain
// so that `options` given in constructor argument wins over the one defined in static `options` property
// 'Flatpickr' wants flat structure of object instead

function flattenOptions(options) {
  var o = {}; // eslint-disable-next-line guard-for-in, no-restricted-syntax

  for (var key in options) {
    o[key] = options[key];
  }

  return o;
} // Weekdays shorthand for english locale


flatpickr__WEBPACK_IMPORTED_MODULE_0___default.a.l10ns.en.weekdays.shorthand.forEach(function (day, index) {
  var currentDay = flatpickr__WEBPACK_IMPORTED_MODULE_0___default.a.l10ns.en.weekdays.shorthand;

  if (currentDay[index] === 'Thu' || currentDay[index] === 'Th') {
    currentDay[index] = 'Th';
  } else {
    currentDay[index] = currentDay[index].charAt(0);
  }
});

var toArray = function toArray(arrayLike) {
  return Array.prototype.slice.call(arrayLike);
};
/**
 * @param {number} monthNumber The month number.
 * @param {boolean} shorthand `true` to use shorthand month.
 * @param {Locale} locale The Flatpickr locale data.
 * @returns {string} The month string.
 */


var monthToStr = function monthToStr(monthNumber, shorthand, locale) {
  return locale.months[shorthand ? 'shorthand' : 'longhand'][monthNumber];
};
/**
 * @param {object} config Plugin configuration.
 * @param {boolean} [config.shorthand] `true` to use shorthand month.
 * @param {string} config.selectorFlatpickrMonthYearContainer The CSS selector for the container of month/year selection UI.
 * @param {string} config.selectorFlatpickrYearContainer The CSS selector for the container of year selection UI.
 * @param {string} config.selectorFlatpickrCurrentMonth The CSS selector for the text-based month selection UI.
 * @param {string} config.classFlatpickrCurrentMonth The CSS class for the text-based month selection UI.
 * @returns {Plugin} A Flatpickr plugin to use text instead of `<select>` for month picker.
 */


var carbonFlatpickrMonthSelectPlugin = function carbonFlatpickrMonthSelectPlugin(config) {
  return function (fp) {
    var setupElements = function setupElements() {
      var _fp$monthElements;

      if (!fp.monthElements) {
        return;
      }

      fp.monthElements.forEach(function (elem) {
        if (!elem.parentNode) return;
        elem.parentNode.removeChild(elem);
      });

      (_fp$monthElements = fp.monthElements).splice.apply(_fp$monthElements, [0, fp.monthElements.length].concat(_toConsumableArray(fp.monthElements.map(function () {
        // eslint-disable-next-line no-underscore-dangle
        var monthElement = fp._createElement('span', config.classFlatpickrCurrentMonth);

        monthElement.textContent = monthToStr(fp.currentMonth, config.shorthand === true, fp.l10n);
        fp.yearElements[0].closest(config.selectorFlatpickrMonthYearContainer).insertBefore(monthElement, fp.yearElements[0].closest(config.selectorFlatpickrYearContainer));
        return monthElement;
      }))));
    };

    var updateCurrentMonth = function updateCurrentMonth() {
      var monthStr = monthToStr(fp.currentMonth, config.shorthand === true, fp.l10n);
      fp.yearElements.forEach(function (elem) {
        var currentMonthContainer = elem.closest(config.selectorFlatpickrMonthYearContainer);
        Array.prototype.forEach.call(currentMonthContainer.querySelectorAll('.cur-month'), function (monthElement) {
          monthElement.textContent = monthStr;
        });
      });
    };

    var register = function register() {
      fp.loadedPlugins.push('carbonFlatpickrMonthSelectPlugin');
    };

    return {
      onMonthChange: updateCurrentMonth,
      onValueUpdate: updateCurrentMonth,
      onOpen: updateCurrentMonth,
      onReady: [setupElements, updateCurrentMonth, register]
    };
  };
};

var DatePicker = /*#__PURE__*/function (_mixin) {
  _inherits(DatePicker, _mixin);

  var _super = _createSuper(DatePicker);
  /**
   * DatePicker.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as an date picker.
   */


  function DatePicker(element, options) {
    var _this;

    _classCallCheck(this, DatePicker);

    _this = _super.call(this, element, options);

    _this._handleFocus = function () {
      if (_this.calendar) {
        _this.calendar.open();
      }
    };

    _this._handleBlur = function (event) {
      if (_this.calendar) {
        var focusTo = event.relatedTarget;

        if (!focusTo || !_this.element.contains(focusTo) && (!_this.calendar.calendarContainer || !_this.calendar.calendarContainer.contains(focusTo))) {
          _this.calendar.close();
        }
      }
    };

    _this._initDatePicker = function (type) {
      if (type === 'range') {
        // Given FlatPickr assumes one `<input>` even in range mode,
        // use a hidden `<input>` for such purpose, separate from our from/to `<input>`s
        var doc = _this.element.ownerDocument;
        var rangeInput = doc.createElement('input');
        rangeInput.className = _this.options.classVisuallyHidden;
        rangeInput.setAttribute('aria-hidden', 'true');

        _this.element.appendChild(rangeInput);

        _this._rangeInput = rangeInput; // An attempt to open the date picker dropdown when this component gets focus,
        // and close the date picker dropdown when this component loses focus

        var w = doc.defaultView;
        var hasFocusin = ('onfocusin' in w);
        var hasFocusout = ('onfocusout' in w);
        var focusinEventName = hasFocusin ? 'focusin' : 'focus';
        var focusoutEventName = hasFocusout ? 'focusout' : 'blur';

        _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element, focusinEventName, _this._handleFocus, !hasFocusin));

        _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element, focusoutEventName, _this._handleBlur, !hasFocusout));

        _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element.querySelector(_this.options.selectorDatePickerIcon), focusoutEventName, _this._handleBlur, !hasFocusout));
      }

      var self = _assertThisInitialized(_this);

      var date = type === 'range' ? _this._rangeInput : _this.element.querySelector(_this.options.selectorDatePickerInput);
      var _this$options = _this.options,
          _onClose = _this$options.onClose,
          _onChange = _this$options.onChange,
          _onMonthChange = _this$options.onMonthChange,
          _onYearChange = _this$options.onYearChange,
          _onOpen = _this$options.onOpen,
          _onValueUpdate = _this$options.onValueUpdate;
      var calendar = new flatpickr__WEBPACK_IMPORTED_MODULE_0___default.a(date, Object.assign(flattenOptions(_this.options), {
        allowInput: true,
        mode: type,
        disableMobile: true,
        positionElement: type === 'range' && _this.element.querySelector(_this.options.selectorDatePickerInputFrom),
        onClose: function onClose(selectedDates) {
          // An attempt to disable Flatpickr's focus tracking system,
          // which has adverse effect with our old set up with two `<input>`s or our latest setup with a hidden `<input>`
          if (self.shouldForceOpen) {
            if (self.calendar.calendarContainer) {
              self.calendar.calendarContainer.classList.add('open');
            }

            self.calendar.isOpen = true;
          }

          for (var _len = arguments.length, remainder = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
            remainder[_key - 1] = arguments[_key];
          }

          if (!_onClose || _onClose.call.apply(_onClose, [this, selectedDates].concat(remainder)) !== false) {
            self._updateClassNames(calendar);

            self._updateInputFields(selectedDates, type);
          }
        },
        onChange: function onChange() {
          for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
            args[_key2] = arguments[_key2];
          }

          if (!_onChange || _onChange.call.apply(_onChange, [this].concat(args)) !== false) {
            self._updateClassNames(calendar);

            if (type === 'range') {
              if (calendar.selectedDates.length === 1 && calendar.isOpen) {
                self.element.querySelector(self.options.selectorDatePickerInputTo).classList.add(self.options.classFocused);
              } else {
                self.element.querySelector(self.options.selectorDatePickerInputTo).classList.remove(self.options.classFocused);
              }
            }
          }
        },
        onMonthChange: function onMonthChange() {
          for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
            args[_key3] = arguments[_key3];
          }

          if (!_onMonthChange || _onMonthChange.call.apply(_onMonthChange, [this].concat(args)) !== false) {
            self._updateClassNames(calendar);
          }
        },
        onYearChange: function onYearChange() {
          for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
            args[_key4] = arguments[_key4];
          }

          if (!_onYearChange || _onYearChange.call.apply(_onYearChange, [this].concat(args)) !== false) {
            self._updateClassNames(calendar);
          }
        },
        onOpen: function onOpen() {
          // An attempt to disable Flatpickr's focus tracking system,
          // which has adverse effect with our old set up with two `<input>`s or our latest setup with a hidden `<input>`
          self.shouldForceOpen = true;
          setTimeout(function () {
            self.shouldForceOpen = false;
          }, 0);

          for (var _len5 = arguments.length, args = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
            args[_key5] = arguments[_key5];
          }

          if (!_onOpen || _onOpen.call.apply(_onOpen, [this].concat(args)) !== false) {
            self._updateClassNames(calendar);
          }
        },
        onValueUpdate: function onValueUpdate() {
          for (var _len6 = arguments.length, args = new Array(_len6), _key6 = 0; _key6 < _len6; _key6++) {
            args[_key6] = arguments[_key6];
          }

          if ((!_onValueUpdate || _onValueUpdate.call.apply(_onValueUpdate, [this].concat(args)) !== false) && type === 'range') {
            self._updateInputFields(self.calendar.selectedDates, type);
          }
        },
        nextArrow: _this._rightArrowHTML(),
        prevArrow: _this._leftArrowHTML(),
        plugins: [].concat(_toConsumableArray(_this.options.plugins || []), [carbonFlatpickrMonthSelectPlugin(_this.options)])
      }));

      if (type === 'range') {
        _this._addInputLogic(_this.element.querySelector(_this.options.selectorDatePickerInputFrom), 0);

        _this._addInputLogic(_this.element.querySelector(_this.options.selectorDatePickerInputTo), 1);
      }

      _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element.querySelector(_this.options.selectorDatePickerIcon), 'click', function () {
        calendar.open();
      }));

      _this._updateClassNames(calendar);

      if (type !== 'range') {
        _this._addInputLogic(date);
      }

      return calendar;
    };

    _this._addInputLogic = function (input, index) {
      if (!isNaN(index) && (index < 0 || index > 1)) {
        throw new RangeError("The index of <input> (".concat(index, ") is out of range."));
      }

      var inputField = input;

      _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(inputField, 'change', function (evt) {
        if (evt.isTrusted || evt.detail && evt.detail.isNotFromFlatpickr) {
          var inputDate = _this.calendar.parseDate(inputField.value);

          if (inputDate && !isNaN(inputDate.valueOf())) {
            if (isNaN(index)) {
              _this.calendar.setDate(inputDate);
            } else {
              var selectedDates = _this.calendar.selectedDates;
              selectedDates[index] = inputDate;

              _this.calendar.setDate(selectedDates);
            }
          }
        }

        _this._updateClassNames(_this.calendar);
      })); // An attempt to temporarily set the `<input>` being edited as the one FlatPicker manages,
      // as FlatPicker attempts to take over `keydown` event handler on `document` to run on the date picker dropdown.


      _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(inputField, 'keydown', function (evt) {
        var origInput = _this.calendar._input;
        _this.calendar._input = evt.target;
        setTimeout(function () {
          _this.calendar._input = origInput;
        });
      }));
    };

    _this._updateClassNames = function (_ref) {
      var calendarContainer = _ref.calendarContainer,
          selectedDates = _ref.selectedDates;

      if (calendarContainer) {
        calendarContainer.classList.add(_this.options.classCalendarContainer);
        calendarContainer.querySelector('.flatpickr-month').classList.add(_this.options.classMonth);
        calendarContainer.querySelector('.flatpickr-weekdays').classList.add(_this.options.classWeekdays);
        calendarContainer.querySelector('.flatpickr-days').classList.add(_this.options.classDays);
        toArray(calendarContainer.querySelectorAll('.flatpickr-weekday')).forEach(function (item) {
          var currentItem = item;
          currentItem.innerHTML = currentItem.innerHTML.replace(/\s+/g, '');
          currentItem.classList.add(_this.options.classWeekday);
        });
        toArray(calendarContainer.querySelectorAll('.flatpickr-day')).forEach(function (item) {
          item.classList.add(_this.options.classDay);

          if (item.classList.contains('today') && selectedDates.length > 0) {
            item.classList.add('no-border');
          } else if (item.classList.contains('today') && selectedDates.length === 0) {
            item.classList.remove('no-border');
          }
        });
      }
    };

    _this._updateInputFields = function (selectedDates, type) {
      if (type === 'range') {
        if (selectedDates.length === 2) {
          _this.element.querySelector(_this.options.selectorDatePickerInputFrom).value = _this._formatDate(selectedDates[0]);
          _this.element.querySelector(_this.options.selectorDatePickerInputTo).value = _this._formatDate(selectedDates[1]);
        } else if (selectedDates.length === 1) {
          _this.element.querySelector(_this.options.selectorDatePickerInputFrom).value = _this._formatDate(selectedDates[0]);
        }
      } else if (selectedDates.length === 1) {
        _this.element.querySelector(_this.options.selectorDatePickerInput).value = _this._formatDate(selectedDates[0]);
      }

      _this._updateClassNames(_this.calendar);
    };

    _this._formatDate = function (date) {
      return _this.calendar.formatDate(date, _this.calendar.config.dateFormat);
    };

    var _type = _this.element.getAttribute(_this.options.attribType);

    _this.calendar = _this._initDatePicker(_type);

    if (_this.calendar.calendarContainer) {
      _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element, 'keydown', function (e) {
        if (e.which === 40) {
          e.preventDefault();

          (_this.calendar.selectedDateElem || _this.calendar.todayDateElem || _this.calendar.calendarContainer).focus();
        }
      }));

      _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.calendar.calendarContainer, 'keydown', function (e) {
        if (e.which === 9 && _type === 'range') {
          _this._updateClassNames(_this.calendar);

          _this.element.querySelector(_this.options.selectorDatePickerInputFrom).focus();
        }
      }));
    }

    return _this;
  }
  /**
   * Opens the date picker dropdown when this component gets focus.
   * Used only for range mode for now.
   * @private
   */


  _createClass(DatePicker, [{
    key: "_rightArrowHTML",
    value: function _rightArrowHTML() {
      return "\n      <svg\n        focusable=\"false\"\n        preserveAspectRatio=\"xMidYMid meet\"\n        style=\"will-change: transform;\"\n        xmlns=\"http://www.w3.org/2000/svg\"\n        width=\"16\"\n        height=\"16\"\n        viewBox=\"0 0 16 16\"\n        aria-hidden=\"true\">\n          <path d=\"M11 8l-5 5-.7-.7L9.6 8 5.3 3.7 6 3z\"></path>\n      </svg>";
    }
  }, {
    key: "_leftArrowHTML",
    value: function _leftArrowHTML() {
      return "\n      <svg\n        focusable=\"false\"\n        preserveAspectRatio=\"xMidYMid meet\"\n        style=\"will-change: transform;\"\n        xmlns=\"http://www.w3.org/2000/svg\"\n        width=\"16\"\n        height=\"16\"\n        viewBox=\"0 0 16 16\"\n        aria-hidden=\"true\"\n      >\n        <path d=\"M5 8l5-5 .7.7L6.4 8l4.3 4.3-.7.7z\"></path>\n      </svg>";
    }
  }, {
    key: "release",
    value: function release() {
      if (this._rangeInput && this._rangeInput.parentNode) {
        this._rangeInput.parentNode.removeChild(this._rangeInput);
      }

      if (this.calendar) {
        try {
          this.calendar.destroy();
        } catch (err) {} // eslint-disable-line no-empty


        this.calendar = null;
      }

      return _get(_getPrototypeOf(DatePicker.prototype), "release", this).call(this);
    }
    /**
     * The component options.
     * If `options` is specified in the constructor,
     * {@linkcode DatePicker.create .create()}, or {@linkcode DatePicker.init .init()},
     * properties in this object are overriden for the instance being create and how {@linkcode DatePicker.init .init()} works.
     * @property {string} selectorInit The CSS selector to find date picker UIs.
     */

  }], [{
    key: "options",
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_1__["default"].prefix;
      return {
        selectorInit: '[data-date-picker]',
        selectorDatePickerInput: '[data-date-picker-input]',
        selectorDatePickerInputFrom: '[data-date-picker-input-from]',
        selectorDatePickerInputTo: '[data-date-picker-input-to]',
        selectorDatePickerIcon: '[data-date-picker-icon]',
        selectorFlatpickrMonthYearContainer: '.flatpickr-current-month',
        selectorFlatpickrYearContainer: '.numInputWrapper',
        selectorFlatpickrCurrentMonth: '.cur-month',
        classCalendarContainer: "".concat(prefix, "--date-picker__calendar"),
        classMonth: "".concat(prefix, "--date-picker__month"),
        classWeekdays: "".concat(prefix, "--date-picker__weekdays"),
        classDays: "".concat(prefix, "--date-picker__days"),
        classWeekday: "".concat(prefix, "--date-picker__weekday"),
        classDay: "".concat(prefix, "--date-picker__day"),
        classFocused: "".concat(prefix, "--focused"),
        classVisuallyHidden: "".concat(prefix, "--visually-hidden"),
        classFlatpickrCurrentMonth: 'cur-month',
        attribType: 'data-date-picker-type',
        dateFormat: 'm/d/Y'
      };
    }
    /**
     * The map associating DOM element and date picker UI instance.
     * @type {WeakMap}
     */

  }]);

  DatePicker.components = new WeakMap();
  return DatePicker;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_2__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_4__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (DatePicker);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/dropdown/dropdown.js":
/*!***************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/dropdown/dropdown.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_track_blur__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/track-blur */ "./node_modules/carbon-components/es/globals/js/mixins/track-blur.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */










var toArray = function toArray(arrayLike) {
  return Array.prototype.slice.call(arrayLike);
};

var Dropdown = /*#__PURE__*/function (_mixin) {
  _inherits(Dropdown, _mixin);

  var _super = _createSuper(Dropdown);
  /**
   * A selector with drop downs.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends TrackBlur
   * @param {HTMLElement} element The element working as a selector.
   * @param {object} [options] The component options.
   * @param {string} [options.selectorItem] The CSS selector to find clickable areas in dropdown items.
   * @param {string} [options.selectorItemSelected] The CSS selector to find the clickable area in the selected dropdown item.
   * @param {string} [options.classSelected] The CSS class for the selected dropdown item.
   * @param {string} [options.classOpen] The CSS class for the open state.
   * @param {string} [options.classDisabled] The CSS class for the disabled state.
   * @param {string} [options.eventBeforeSelected]
   *   The name of the custom event fired before a drop down item is selected.
   *   Cancellation of this event stops selection of drop down item.
   * @param {string} [options.eventAfterSelected] The name of the custom event fired after a drop down item is selected.
   */


  function Dropdown(element, options) {
    var _this;

    _classCallCheck(this, Dropdown);

    _this = _super.call(this, element, options);

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element.ownerDocument, 'click', function (event) {
      _this._toggle(event);
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element, 'keydown', function (event) {
      _this._handleKeyDown(event);
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element, 'click', function (event) {
      var item = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__["default"])(event, _this.options.selectorItem);

      if (item) {
        _this.select(item);
      }
    })); // When using the active descendant approach we use a class to give focus styles during keyboard (up/down arrows)
    // navigation instead of relying on the :focus selector. This leaves the potential to have multiple items when
    // switching interactions between keyboard and mouse users. To more closely align with Carbon React implementation,
    // we want the focus class to move as the user hovers over items. This also updates the location of focus based on
    // the last hovered item if the user switches back to using the keyboard.


    if ( // NOTE: `selectorTrigger` does NOT match the trigger button in older markup
    _this.element.querySelector(_this.options.selectorTrigger) && _this.element.querySelector(_this.options.selectorMenu)) {
      // Using the latest HTML structure that supports the aria-activedescendant attribute
      _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element, 'mouseover', function (event) {
        var item = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__["default"])(event, _this.options.selectorItem);

        if (item) {
          _this._updateFocus(item);
        }
      }));
    }

    return _this;
  }
  /**
   * Handles keydown event.
   * @param {Event} event The event triggering this method.
   */


  _createClass(Dropdown, [{
    key: "_handleKeyDown",
    value: function _handleKeyDown(event) {
      var isOpen = this.element.classList.contains(this.options.classOpen);
      var direction = {
        38: this.constructor.NAVIGATE.BACKWARD,
        40: this.constructor.NAVIGATE.FORWARD
      }[event.which];

      if (isOpen && direction !== undefined) {
        this.navigate(direction);
        event.preventDefault(); // Prevents up/down keys from scrolling container
      } else {
        // get selected item
        // in v10.0, the anchor elements fire click events on Enter keypress when a dropdown item is selected
        // in v10.5 (#3586), focus is no longer placed on the dropdown items and is instead kept fixed on the ul menu
        // so we need to manually call getCurrentNavigation and select the item
        var item = this.getCurrentNavigation();

        if (item && isOpen && (event.which === 13 || event.which === 32) && !this.element.ownerDocument.activeElement.matches(this.options.selectorItem)) {
          event.preventDefault();
          this.select(item);
        }

        this._toggle(event);
      }
    }
    /**
     * When using aria-activedescendant we want to make sure attributes and classes
     * are properly cleaned up when the dropdown is closed
     * @private
     */

  }, {
    key: "_focusCleanup",
    value: function _focusCleanup() {
      // NOTE: `selectorTrigger` does NOT match the trigger button in older markup
      var triggerNode = this.element.querySelector(this.options.selectorTrigger); // only want to grab the listNode IF it's using the latest a11y HTML structure

      var listNode = triggerNode ? this.element.querySelector(this.options.selectorMenu) : null;

      if (listNode) {
        listNode.removeAttribute('aria-activedescendant');
        var focusedItem = this.element.querySelector(this.options.selectorItemFocused);

        if (focusedItem) {
          focusedItem.classList.remove(this.options.classFocused);
        }
      }
    }
    /**
     * Update focus using aria-activedescendant HTML structure
     * @param {HTMLElement} itemToFocus The element to be focused.
     */

  }, {
    key: "_updateFocus",
    value: function _updateFocus(itemToFocus) {
      // NOTE: `selectorTrigger` does NOT match the trigger button in older markup
      var triggerNode = this.element.querySelector(this.options.selectorTrigger); // only want to grab the listNode IF it's using the latest a11y HTML structure

      var listNode = triggerNode ? this.element.querySelector(this.options.selectorMenu) : null;
      var previouslyFocused = listNode.querySelector(this.options.selectorItemFocused);
      itemToFocus.classList.add(this.options.classFocused);
      listNode.setAttribute('aria-activedescendant', itemToFocus.id);

      if (previouslyFocused) {
        previouslyFocused.classList.remove(this.options.classFocused);
      }
    }
    /**
     * Opens and closes the dropdown menu.
     * @param {Event} [event] The event triggering this method.
     *
     * @todo https://github.com/carbon-design-system/carbon/issues/3641
     */

  }, {
    key: "_toggle",
    value: function _toggle(event) {
      var _this2 = this;

      var isDisabled = this.element.classList.contains(this.options.classDisabled);

      if (isDisabled) {
        return;
      } // NOTE: `selectorTrigger` does NOT match the trigger button in older markup


      var triggerNode = this.element.querySelector(this.options.selectorTrigger);

      if ( // User presses down arrow
      event.which === 40 && !event.target.matches(this.options.selectorItem) || // User presses space or enter and the trigger is not a button OR event is not fired by trigger
      (!triggerNode || !triggerNode.contains(event.target)) && [13, 32].indexOf(event.which) >= 0 && !event.target.matches(this.options.selectorItem) || // User presses esc
      event.which === 27 || // User clicks
      event.type === 'click') {
        var isOpen = this.element.classList.contains(this.options.classOpen);
        var isOfSelf = this.element.contains(event.target); // Determine if the open className should be added, removed, or toggled

        var actions = {
          add: isOfSelf && event.which === 40 && !isOpen,
          remove: (!isOfSelf || event.which === 27) && isOpen,
          toggle: isOfSelf && event.which !== 27 && event.which !== 40
        };
        var changedState = false;
        Object.keys(actions).forEach(function (action) {
          if (actions[action]) {
            changedState = true;

            _this2.element.classList[action](_this2.options.classOpen);
          }
        });
        var listItems = toArray(this.element.querySelectorAll(this.options.selectorItem)); // only want to grab the listNode IF it's using the latest a11y HTML structure

        var listNode = triggerNode ? this.element.querySelector(this.options.selectorMenu) : null; // @todo remove conditionals for elements existing once legacy structure is depreciated

        if (changedState && this.element.classList.contains(this.options.classOpen)) {
          // toggled open
          if (triggerNode) {
            triggerNode.setAttribute('aria-expanded', 'true');
          }

          (listNode || this.element).focus();

          if (listNode) {
            var selectedNode = listNode.querySelector(this.options.selectorLinkSelected);
            listNode.setAttribute('aria-activedescendant', (selectedNode || listItems[0]).id);
            (selectedNode || listItems[0]).classList.add(this.options.classFocused);
          }
        } else if (changedState && (isOfSelf || actions.remove)) {
          // toggled close
          // timer is used to call focus AFTER the click event on
          // trigger button (which is caused by keypress e.g. during keyboard navigation)
          setTimeout(function () {
            return (triggerNode || _this2.element).focus();
          }, 0);

          if (triggerNode) {
            triggerNode.setAttribute('aria-expanded', 'false');
          }

          this._focusCleanup();
        } // @todo remove once legacy structure is depreciated


        if (!triggerNode) {
          listItems.forEach(function (item) {
            if (_this2.element.classList.contains(_this2.options.classOpen)) {
              item.tabIndex = 0;
            } else {
              item.tabIndex = -1;
            }
          });
        }

        var menuListNode = this.element.querySelector(this.options.selectorMenu);

        if (menuListNode) {
          menuListNode.tabIndex = this.element.classList.contains(this.options.classOpen) ? '0' : '-1';
        }
      }
    }
    /**
     * @returns {Element} Currently highlighted element.
     */

  }, {
    key: "getCurrentNavigation",
    value: function getCurrentNavigation() {
      var focusedNode; // Using the latest semantic markup structure where trigger is a button
      // @todo remove conditional once legacy structure is depreciated
      // NOTE: `selectorTrigger` does NOT match the trigger button in older markup

      if (this.element.querySelector(this.options.selectorTrigger)) {
        var listNode = this.element.querySelector(this.options.selectorMenu);
        var focusedId = listNode.getAttribute('aria-activedescendant');
        focusedNode = focusedId ? listNode.querySelector("#".concat(focusedId)) : null;
      } else {
        var focused = this.element.ownerDocument.activeElement;
        focusedNode = focused.nodeType === Node.ELEMENT_NODE && focused.matches(this.options.selectorItem) ? focused : null;
      }

      return focusedNode;
    }
    /**
     * Moves up/down the focus.
     * @param {number} direction The direction of navigating.
     */
    // @todo create issue it's a better UX to move the focus when the user hovers so they stay in sync

  }, {
    key: "navigate",
    value: function navigate(direction) {
      var items = toArray(this.element.querySelectorAll(this.options.selectorItem));
      var start = this.getCurrentNavigation() || this.element.querySelector(this.options.selectorLinkSelected);

      var getNextItem = function getNextItem(old) {
        var handleUnderflow = function handleUnderflow(i, l) {
          return i + (i >= 0 ? 0 : l);
        };

        var handleOverflow = function handleOverflow(i, l) {
          return i - (i < l ? 0 : l);
        }; // `items.indexOf(old)` may be -1 (Scenario of no previous focus)


        var index = Math.max(items.indexOf(old) + direction, -1);
        return items[handleUnderflow(handleOverflow(index, items.length), items.length)];
      };

      var isShowSelected = this.element.classList.contains(this.options.classShowSelected);

      for (var current = getNextItem(start); current && current !== start; current = getNextItem(current)) {
        if (!current.matches(this.options.selectorItemHidden) && !current.parentNode.matches(this.options.selectorItemHidden) && (isShowSelected || !isShowSelected && !current.parentElement.matches(this.options.selectorItemSelected))) {
          // Using the latest semantic markup structure where trigger is a button
          // @todo remove conditional once legacy structure is depreciated
          // NOTE: `selectorTrigger` does NOT match the trigger button in older markup
          if (this.element.querySelector(this.options.selectorTrigger)) {
            this._updateFocus(current);
          } else {
            current.focus();
          }

          break;
        }
      }
    }
    /**
     * Handles clicking on the dropdown options, doing the following:
     * * Change Dropdown text to selected option.
     * * Remove selected option from options when selected.
     * * Emit custom events.
     * @param {HTMLElement} itemToSelect The element to be activated.
     */

  }, {
    key: "select",
    value: function select(itemToSelect) {
      var _this3 = this;

      var eventStart = new CustomEvent(this.options.eventBeforeSelected, {
        bubbles: true,
        cancelable: true,
        detail: {
          item: itemToSelect
        }
      });

      if (this.element.dispatchEvent(eventStart)) {
        if (this.element.dataset.dropdownType !== 'navigation') {
          // NOTE: `selectorTrigger` does NOT match the trigger button in older markup
          var selectorText = !this.element.querySelector(this.options.selectorTrigger) && this.element.dataset.dropdownType !== 'inline' ? this.options.selectorText : this.options.selectorTextInner;
          var text = this.element.querySelector(selectorText);

          if (text) {
            text.innerHTML = itemToSelect.innerHTML;
          }

          itemToSelect.parentElement.classList.add(this.options.classSelected);
        }

        this.element.dataset.value = itemToSelect.parentElement.dataset.value;
        toArray(this.element.querySelectorAll(this.options.selectorLinkSelected)).forEach(function (item) {
          if (itemToSelect !== item) {
            item.parentElement.classList.remove(_this3.options.classSelected);
          }
        });
        this.element.dispatchEvent(new CustomEvent(this.options.eventAfterSelected, {
          bubbles: true,
          cancelable: true,
          detail: {
            item: itemToSelect
          }
        }));
      }
    }
    /**
     * Closes the dropdown menu if this component loses focus.
     */

  }, {
    key: "handleBlur",
    value: function handleBlur() {
      this.element.classList.remove(this.options.classOpen);

      this._focusCleanup();
    }
    /**
     * The map associating DOM element and selector instance.
     * @member Dropdown.components
     * @type {WeakMap}
     */

  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor, {@linkcode Dropdown.create .create()}, or {@linkcode Dropdown.init .init()},
     * properties in this object are overridden for the instance being create and how {@linkcode Dropdown.init .init()} works.
     * @member Dropdown.options
     * @type {object}
     * @property {string} selectorInit The CSS selector to find selectors.
     * @property {string} [selectorTrigger]
     *   The CSS selector to find the trigger button when using a11y compliant markup.
     *   NOTE: Does NOT match the trigger button in older markup.
     * @property {string} [selectorMenu] The CSS selector to find menu list when using a11y compliant markup.
     * @property {string} [selectorText] The CSS selector to find the element showing the selected item.
     * @property {string} [selectorTextInner] The CSS selector to find the element showing the selected item, used for inline mode.
     * @property {string} [selectorItem] The CSS selector to find clickable areas in dropdown items.
     * @property {string} [selectorItemHidden]
     *   The CSS selector to find hidden dropdown items.
     *   Used to skip dropdown items for keyboard navigation.
     * @property {string} [selectorItemSelected] The CSS selector to find the clickable area in the selected dropdown item.
     * @property {string} [selectorItemFocused] The CSS selector to find the clickable area in the focused dropdown item.
     * @property {string} [selectorLinkSelected] The CSS selector to target the link node of the selected dropdown item.
     * @property {string} [classShowSelected] The CSS class for the show selected modifier of the dropdown.
     * @property {string} [classSelected] The CSS class for the selected dropdown item.
     * @property {string} [classFocused] The CSS class for the focused dropdown item.
     * @property {string} [classOpen] The CSS class for the open state.
     * @property {string} [classDisabled] The CSS class for the disabled state.
     * @property {string} [eventBeforeSelected]
     *   The name of the custom event fired before a drop down item is selected.
     *   Cancellation of this event stops selection of drop down item.
     * @property {string} [eventAfterSelected] The name of the custom event fired after a drop down item is selected.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-dropdown]',
        selectorTrigger: "button.".concat(prefix, "--dropdown-text"),
        // NOTE: Does NOT match the trigger button in older markup.
        selectorMenu: ".".concat(prefix, "--dropdown-list"),
        selectorText: ".".concat(prefix, "--dropdown-text"),
        selectorTextInner: ".".concat(prefix, "--dropdown-text__inner"),
        selectorItem: ".".concat(prefix, "--dropdown-link"),
        selectorItemSelected: ".".concat(prefix, "--dropdown--selected"),
        selectorItemFocused: ".".concat(prefix, "--dropdown--focused"),
        selectorItemHidden: "[hidden],[aria-hidden=\"true\"]",
        selectorLinkSelected: ".".concat(prefix, "--dropdown--selected .").concat(prefix, "--dropdown-link"),
        classShowSelected: "".concat(prefix, "--dropdown--show-selected"),
        classSelected: "".concat(prefix, "--dropdown--selected"),
        classFocused: "".concat(prefix, "--dropdown--focused"),
        classOpen: "".concat(prefix, "--dropdown--open"),
        classDisabled: "".concat(prefix, "--dropdown--disabled"),
        eventBeforeSelected: 'dropdown-beingselected',
        eventAfterSelected: 'dropdown-selected'
      };
    }
    /**
     * Enum for navigating backward/forward.
     * @readonly
     * @member Dropdown.NAVIGATE
     * @type {object}
     * @property {number} BACKWARD Navigating backward.
     * @property {number} FORWARD Navigating forward.
     */

  }]);

  Dropdown.components = new WeakMap();
  Dropdown.NAVIGATE = {
    BACKWARD: -1,
    FORWARD: 1
  };
  return Dropdown;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_track_blur__WEBPACK_IMPORTED_MODULE_4__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (Dropdown);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/file-uploader/file-uploader.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/file-uploader/file-uploader.js ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_evented_state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/evented-state */ "./node_modules/carbon-components/es/globals/js/mixins/evented-state.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */











var toArray = function toArray(arrayLike) {
  return Array.prototype.slice.call(arrayLike);
};

var FileUploader = /*#__PURE__*/function (_mixin) {
  _inherits(FileUploader, _mixin);

  var _super = _createSuper(FileUploader);
  /**
   * File uploader.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends eventedState
   * @extends Handles
   * @param {HTMLElement} element The element working as a file uploader.
   * @param {object} [options] The component options. See static options.
   */


  function FileUploader(element) {
    var _this;

    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    _classCallCheck(this, FileUploader);

    _this = _super.call(this, element, options);

    _this._changeState = function (state, detail, callback) {
      if (state === 'delete-filename-fileuploader') {
        _this.container.removeChild(detail.filenameElement);
      }

      if (typeof callback === 'function') {
        callback();
      }
    };

    _this._handleDeleteButton = function (evt) {
      var target = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__["default"])(evt, _this.options.selectorCloseButton);

      if (target) {
        _this.changeState('delete-filename-fileuploader', {
          initialEvt: evt,
          filenameElement: target.closest(_this.options.selectorSelectedFile)
        });
      }
    };

    _this._handleDragDrop = function (evt) {
      var isOfSelf = _this.element.contains(evt.target); // In IE11 `evt.dataTransfer.types` is a `DOMStringList` instead of an array


      if (Array.prototype.indexOf.call(evt.dataTransfer.types, 'Files') >= 0 && !Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__["default"])(evt, _this.options.selectorOtherDropContainers)) {
        var inArea = isOfSelf && Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__["default"])(evt, _this.options.selectorDropContainer);

        if (evt.type === 'dragover') {
          evt.preventDefault();
          var dropEffect = inArea ? 'copy' : 'none';

          if (Array.isArray(evt.dataTransfer.types)) {
            // IE11 throws a "permission denied" error accessing `.effectAllowed`
            evt.dataTransfer.effectAllowed = dropEffect;
          }

          evt.dataTransfer.dropEffect = dropEffect;

          _this.dropContainer.classList.toggle(_this.options.classDragOver, Boolean(inArea));
        }

        if (evt.type === 'dragleave') {
          _this.dropContainer.classList.toggle(_this.options.classDragOver, false);
        }

        if (inArea && evt.type === 'drop') {
          evt.preventDefault();

          _this._displayFilenames(evt.dataTransfer.files);

          _this.dropContainer.classList.remove(_this.options.classDragOver);
        }
      }
    };

    _this.input = _this.element.querySelector(_this.options.selectorInput);
    _this.container = _this.element.querySelector(_this.options.selectorContainer);
    _this.dropContainer = _this.element.querySelector(_this.options.selectorDropContainer);

    if (!_this.input) {
      throw new TypeError('Cannot find the file input box.');
    }

    if (!_this.container) {
      throw new TypeError('Cannot find the file names container.');
    }

    _this.inputId = _this.input.getAttribute('id');

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.input, 'change', function () {
      return _this._displayFilenames();
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.container, 'click', _this._handleDeleteButton));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.element.ownerDocument, 'dragleave', _this._handleDragDrop));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.dropContainer, 'dragover', _this._handleDragDrop));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.dropContainer, 'drop', _this._handleDragDrop));

    return _this;
  }

  _createClass(FileUploader, [{
    key: "_filenamesHTML",
    value: function _filenamesHTML(name, id) {
      return "<span class=\"".concat(this.options.classSelectedFile, "\">\n      <p class=\"").concat(this.options.classFileName, "\">").concat(name, "</p>\n      <span data-for=\"").concat(id, "\" class=\"").concat(this.options.classStateContainer, "\"></span>\n    </span>");
    }
  }, {
    key: "_uploadHTML",
    value: function _uploadHTML() {
      return "\n      <div class=\"".concat(this.options.classLoadingAnimation, "\">\n        <div data-inline-loading-spinner class=\"").concat(this.options.classLoading, "\">\n          <svg class=\"").concat(this.options.classLoadingSvg, "\" viewBox=\"-75 -75 150 150\">\n            <circle class=\"").concat(this.options.classLoadingBackground, "\" cx=\"0\" cy=\"0\" r=\"37.5\" />\n            <circle class=\"").concat(this.options.classLoadingStroke, "\" cx=\"0\" cy=\"0\" r=\"37.5\" />\n          </svg>\n        </div>\n      </div>");
    }
  }, {
    key: "_closeButtonHTML",
    value: function _closeButtonHTML() {
      return "\n      <button class=\"".concat(this.options.classFileClose, "\" type=\"button\" aria-label=\"close\">\n      <svg aria-hidden=\"true\" viewBox=\"0 0 16 16\" width=\"16\" height=\"16\">\n      <path fill=\"#231F20\" d=\"M12 4.7l-.7-.7L8 7.3 4.7 4l-.7.7L7.3 8 4 11.3l.7.7L8 8.7l3.3 3.3.7-.7L8.7 8z\"/>\n      </svg>\n      </button>");
    }
  }, {
    key: "_checkmarkHTML",
    value: function _checkmarkHTML() {
      return "\n      <svg focusable=\"false\"\n        preserveAspectRatio=\"xMidYMid meet\"\n        style=\"will-change: transform;\"\n        xmlns=\"http://www.w3.org/2000/svg\"\n        class=\"".concat(this.options.classFileComplete, "\"\n        width=\"16\" height=\"16\" viewBox=\"0 0 16 16\"\n        aria-hidden=\"true\">\n        <path d=\"M8 1C4.1 1 1 4.1 1 8s3.1 7 7 7 7-3.1 7-7-3.1-7-7-7zM7 11L4.3 8.3l.9-.8L7 9.3l4-3.9.9.8L7 11z\"></path>\n        <path d=\"M7 11L4.3 8.3l.9-.8L7 9.3l4-3.9.9.8L7 11z\" data-icon-path=\"inner-path\" opacity=\"0\"></path>\n      </svg>\n    ");
    }
  }, {
    key: "_getStateContainers",
    value: function _getStateContainers() {
      var stateContainers = toArray(this.element.querySelectorAll("[data-for=".concat(this.inputId, "]")));

      if (stateContainers.length === 0) {
        throw new TypeError('State container elements not found; invoke _displayFilenames() first');
      }

      if (stateContainers[0].dataset.for !== this.inputId) {
        throw new TypeError('File input id must equal [data-for] attribute');
      }

      return stateContainers;
    }
    /**
     * Inject selected files into DOM. Invoked on change event.
     * @param {File[]} files The files to upload.
     */

  }, {
    key: "_displayFilenames",
    value: function _displayFilenames() {
      var _this2 = this;

      var files = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.input.files;
      var container = this.element.querySelector(this.options.selectorContainer);
      var HTMLString = toArray(files).map(function (file) {
        return _this2._filenamesHTML(file.name, _this2.inputId);
      }).join('');
      container.insertAdjacentHTML('afterbegin', HTMLString);
    }
  }, {
    key: "_removeState",
    value: function _removeState(element) {
      if (!element || element.nodeType !== Node.ELEMENT_NODE) {
        throw new TypeError('DOM element should be given to initialize this widget.');
      }

      while (element.firstChild) {
        element.removeChild(element.firstChild);
      }
    }
  }, {
    key: "_handleStateChange",
    value: function _handleStateChange(elements, selectIndex, html) {
      var _this3 = this;

      if (selectIndex === undefined) {
        elements.forEach(function (el) {
          _this3._removeState(el);

          el.insertAdjacentHTML('beforeend', html);
        });
      } else {
        elements.forEach(function (el, index) {
          if (index === selectIndex) {
            _this3._removeState(el);

            el.insertAdjacentHTML('beforeend', html);
          }
        });
      }
    }
    /**
     * Handles delete button.
     * @param {Event} evt The event triggering this action.
     * @private
     */

  }, {
    key: "setState",
    value: function setState(state, selectIndex) {
      var stateContainers = this._getStateContainers();

      if (state === 'edit') {
        this._handleStateChange(stateContainers, selectIndex, this._closeButtonHTML());
      }

      if (state === 'upload') {
        this._handleStateChange(stateContainers, selectIndex, this._uploadHTML());
      }

      if (state === 'complete') {
        this._handleStateChange(stateContainers, selectIndex, this._checkmarkHTML());
      }
    }
    /**
     * The map associating DOM element and file uploader instance.
     * @member FileUploader.components
     * @type {WeakMap}
     */

  }], [{
    key: "options",
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-file]',
        selectorInput: "input[type=\"file\"].".concat(prefix, "--file-input"),
        selectorContainer: '[data-file-container]',
        selectorCloseButton: ".".concat(prefix, "--file-close"),
        selectorSelectedFile: ".".concat(prefix, "--file__selected-file"),
        selectorDropContainer: "[data-file-drop-container]",
        selectorOtherDropContainers: '[data-drop-container]',
        classLoading: "".concat(prefix, "--loading ").concat(prefix, "--loading--small"),
        classLoadingAnimation: "".concat(prefix, "--inline-loading__animation"),
        classLoadingSvg: "".concat(prefix, "--loading__svg"),
        classLoadingBackground: "".concat(prefix, "--loading__background"),
        classLoadingStroke: "".concat(prefix, "--loading__stroke"),
        classFileName: "".concat(prefix, "--file-filename"),
        classFileClose: "".concat(prefix, "--file-close"),
        classFileComplete: "".concat(prefix, "--file-complete"),
        classSelectedFile: "".concat(prefix, "--file__selected-file"),
        classStateContainer: "".concat(prefix, "--file__state-container"),
        classDragOver: "".concat(prefix, "--file__drop-container--drag-over"),
        eventBeforeDeleteFilenameFileuploader: 'fileuploader-before-delete-filename',
        eventAfterDeleteFilenameFileuploader: 'fileuploader-after-delete-filename'
      };
    }
  }]);

  FileUploader.components = new WeakMap();
  return FileUploader;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_evented_state__WEBPACK_IMPORTED_MODULE_4__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (FileUploader);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/floating-menu/floating-menu.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/floating-menu/floating-menu.js ***!
  \*************************************************************************************/
/*! exports provided: DIRECTION_LEFT, DIRECTION_TOP, DIRECTION_RIGHT, DIRECTION_BOTTOM, getFloatingPosition, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DIRECTION_LEFT", function() { return DIRECTION_LEFT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DIRECTION_TOP", function() { return DIRECTION_TOP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DIRECTION_RIGHT", function() { return DIRECTION_RIGHT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DIRECTION_BOTTOM", function() { return DIRECTION_BOTTOM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFloatingPosition", function() { return getFloatingPosition; });
/* harmony import */ var warning__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! warning */ "./node_modules/warning/browser.js");
/* harmony import */ var warning__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(warning__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_evented_show_hide_state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/evented-show-hide-state */ "./node_modules/carbon-components/es/globals/js/mixins/evented-show-hide-state.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_mixins_track_blur__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/mixins/track-blur */ "./node_modules/carbon-components/es/globals/js/mixins/track-blur.js");
/* harmony import */ var _globals_js_misc_get_launching_details__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../globals/js/misc/get-launching-details */ "./node_modules/carbon-components/es/globals/js/misc/get-launching-details.js");
/* harmony import */ var _globals_js_misc_resize__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../globals/js/misc/resize */ "./node_modules/carbon-components/es/globals/js/misc/resize.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _get(target, property, receiver) {
  if (typeof Reflect !== "undefined" && Reflect.get) {
    _get = Reflect.get;
  } else {
    _get = function _get(target, property, receiver) {
      var base = _superPropBase(target, property);

      if (!base) return;
      var desc = Object.getOwnPropertyDescriptor(base, property);

      if (desc.get) {
        return desc.get.call(receiver);
      }

      return desc.value;
    };
  }

  return _get(target, property, receiver || target);
}

function _superPropBase(object, property) {
  while (!Object.prototype.hasOwnProperty.call(object, property)) {
    object = _getPrototypeOf(object);
    if (object === null) break;
  }

  return object;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */












/**
 * The structure for the position of floating menu.
 * @typedef {object} FloatingMenu~position
 * @property {number} left The left position.
 * @property {number} top The top position.
 * @property {number} right The right position.
 * @property {number} bottom The bottom position.
 */

/**
 * The structure for the size of floating menu.
 * @typedef {object} FloatingMenu~size
 * @property {number} width The width.
 * @property {number} height The height.
 */

/**
 * The structure for the position offset of floating menu.
 * @typedef {object} FloatingMenu~offset
 * @property {number} top The top position.
 * @property {number} left The left position.
 */

var DIRECTION_LEFT = 'left';
var DIRECTION_TOP = 'top';
var DIRECTION_RIGHT = 'right';
var DIRECTION_BOTTOM = 'bottom';
/**
 * @param {object} params The parameters.
 * @param {FloatingMenu~size} params.menuSize The size of the menu.
 * @param {FloatingMenu~position} params.refPosition The position of the triggering element.
 * @param {FloatingMenu~offset} [params.offset={ left: 0, top: 0 }] The position offset of the menu.
 * @param {string} [params.direction=bottom] The menu direction.
 * @param {number} [params.scrollX=0] The scroll position of the viewport.
 * @param {number} [params.scrollY=0] The scroll position of the viewport.
 * @returns {FloatingMenu~offset} The position of the menu, relative to the top-left corner of the viewport.
 * @private
 */

var getFloatingPosition = function getFloatingPosition(_ref) {
  var _DIRECTION_LEFT$DIREC;

  var menuSize = _ref.menuSize,
      refPosition = _ref.refPosition,
      _ref$offset = _ref.offset,
      offset = _ref$offset === void 0 ? {} : _ref$offset,
      _ref$direction = _ref.direction,
      direction = _ref$direction === void 0 ? DIRECTION_BOTTOM : _ref$direction,
      _ref$scrollX = _ref.scrollX,
      scrollX = _ref$scrollX === void 0 ? 0 : _ref$scrollX,
      _ref$scrollY = _ref.scrollY,
      scrollY = _ref$scrollY === void 0 ? 0 : _ref$scrollY;
  var _refPosition$left = refPosition.left,
      refLeft = _refPosition$left === void 0 ? 0 : _refPosition$left,
      _refPosition$top = refPosition.top,
      refTop = _refPosition$top === void 0 ? 0 : _refPosition$top,
      _refPosition$right = refPosition.right,
      refRight = _refPosition$right === void 0 ? 0 : _refPosition$right,
      _refPosition$bottom = refPosition.bottom,
      refBottom = _refPosition$bottom === void 0 ? 0 : _refPosition$bottom;
  var width = menuSize.width,
      height = menuSize.height;
  var _offset$top = offset.top,
      top = _offset$top === void 0 ? 0 : _offset$top,
      _offset$left = offset.left,
      left = _offset$left === void 0 ? 0 : _offset$left;
  var refCenterHorizontal = (refLeft + refRight) / 2;
  var refCenterVertical = (refTop + refBottom) / 2;
  return (_DIRECTION_LEFT$DIREC = {}, _defineProperty(_DIRECTION_LEFT$DIREC, DIRECTION_LEFT, {
    left: refLeft - width + scrollX - left,
    top: refCenterVertical - height / 2 + scrollY + top
  }), _defineProperty(_DIRECTION_LEFT$DIREC, DIRECTION_TOP, {
    left: refCenterHorizontal - width / 2 + scrollX + left,
    top: refTop - height + scrollY - top
  }), _defineProperty(_DIRECTION_LEFT$DIREC, DIRECTION_RIGHT, {
    left: refRight + scrollX + left,
    top: refCenterVertical - height / 2 + scrollY + top
  }), _defineProperty(_DIRECTION_LEFT$DIREC, DIRECTION_BOTTOM, {
    left: refCenterHorizontal - width / 2 + scrollX + left,
    top: refBottom + scrollY + top
  }), _DIRECTION_LEFT$DIREC)[direction];
};

var FloatingMenu = /*#__PURE__*/function (_mixin) {
  _inherits(FloatingMenu, _mixin);

  var _super = _createSuper(FloatingMenu);
  /**
   * Floating menu.
   * @extends CreateComponent
   * @extends EventedShowHideState
   * @param {HTMLElement} element The element working as a modal dialog.
   * @param {object} [options] The component options.
   * @param {string} [options.selectorContainer] The CSS selector to find the container to put this menu in.
   * @param {string} [options.attribDirection] The attribute name to specify menu placement direction (top/right/bottom/left).
   * @param {string} [options.classShown] The CSS class for shown state, for the menu.
   * @param {string} [options.classRefShown] The CSS class for shown state, for the trigger button.
   * @param {string} [options.eventBeforeShown]
   *   The name of the custom event fired before this menu is shown.
   *   Cancellation of this event stops hiding the menu.
   * @param {string} [options.eventAfterShown]
   *   The name of the custom event telling that menu is sure shown
   *   without being canceled by the event handler named by `eventBeforeShown` option (`floating-menu-beingshown`).
   * @param {string} [options.eventBeforeHidden]
   *   The name of the custom event fired before this menu is hidden.
   *   Cancellation of this event stops hiding the menu.
   * @param {string} [options.eventAfterHidden]
   *   The name of the custom event telling that menu is sure hidden
   *   without being canceled by the event handler named by `eventBeforeHidden` option (`floating-menu-beinghidden`).
   * @param {Element} [options.refNode] The launching element of the menu. Used for calculating the geometry of the menu.
   * @param {object} [options.offset] The offset to adjust the geometry of the menu. Should have `top`/`left` properties.
   */


  function FloatingMenu(element, options) {
    var _this;

    _classCallCheck(this, FloatingMenu);

    _this = _super.call(this, element, options);

    var attribDirectionValue = _this.element.getAttribute(_this.options.attribDirection);

    if (!_this.options.direction) {
      _this.options.direction = attribDirectionValue || 'bottom';
    }

    if (!attribDirectionValue) {
      // Update attribute for styling
      _this.element.setAttribute(_this.options.attribDirection, _this.options.direction);
    }

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_9__["default"])(_this.element.ownerDocument, 'keydown', function (event) {
      _this._handleKeydown(event);
    }));

    return _this;
  }
  /**
   * Handles key press on document.
   * @param {Event} event The triggering event.
   * @private
   */


  _createClass(FloatingMenu, [{
    key: "_handleKeydown",
    value: function _handleKeydown(event) {
      var key = event.which;
      var _this$options = this.options,
          triggerNode = _this$options.triggerNode,
          refNode = _this$options.refNode;
      var isOfMenu = this.element.contains(event.target);

      switch (key) {
        // Esc
        case 27:
          this.changeState('hidden', Object(_globals_js_misc_get_launching_details__WEBPACK_IMPORTED_MODULE_7__["default"])(event), function () {
            if (isOfMenu) {
              (triggerNode || refNode).focus();
            }
          });
          break;

        default:
          break;
      }
    }
    /**
     * Focuses back on the trigger button if this component loses focus.
     */

  }, {
    key: "handleBlur",
    value: function handleBlur(event) {
      if (this.element.classList.contains(this.options.classShown)) {
        this.changeState('hidden', Object(_globals_js_misc_get_launching_details__WEBPACK_IMPORTED_MODULE_7__["default"])(event));
        var _this$options2 = this.options,
            refNode = _this$options2.refNode,
            triggerNode = _this$options2.triggerNode;

        if ((event.relatedTarget === null || this.element.contains(event.relatedTarget)) && refNode && event.target !== refNode) {
          HTMLElement.prototype.focus.call(triggerNode || refNode); // SVGElement in IE11 does not have `.focus()` method
        }
      }
    }
    /**
     * @private
     * @returns {Element} The element that this menu should be placed to.
     */

  }, {
    key: "_getContainer",
    value: function _getContainer() {
      return this.element.closest(this.options.selectorContainer) || this.element.ownerDocument.body;
    }
    /**
     * @private
     * @returns {object} The menu position, with `top` and `left` properties.
     */

  }, {
    key: "_getPos",
    value: function _getPos() {
      var element = this.element;
      var _this$options3 = this.options,
          refNode = _this$options3.refNode,
          offset = _this$options3.offset,
          direction = _this$options3.direction;

      if (!refNode) {
        throw new Error('Cannot find the reference node for positioning floating menu.');
      }

      return getFloatingPosition({
        menuSize: element.getBoundingClientRect(),
        refPosition: refNode.getBoundingClientRect(),
        offset: typeof offset !== 'function' ? offset : offset(element, direction, refNode),
        direction: direction,
        scrollX: refNode.ownerDocument.defaultView.pageXOffset,
        scrollY: refNode.ownerDocument.defaultView.pageYOffset
      });
    }
    /**
     * Sees if the computed style is what this floating menu expects.
     * @private
     */

  }, {
    key: "_testStyles",
    value: function _testStyles() {
      if (!this.options.debugStyle) {
        return;
      }

      var element = this.element;
      var computedStyle = element.ownerDocument.defaultView.getComputedStyle(element);
      var styles = {
        position: 'absolute',
        right: 'auto',
        margin: 0
      };
      Object.keys(styles).forEach(function (key) {
        var expected = typeof styles[key] === 'number' ? parseFloat(styles[key]) : styles[key];
        var actual = computedStyle.getPropertyValue(key);

        if (expected !== actual) {
          // eslint-disable-next-line no-console
          console.warn("Floating menu component expects ".concat(key, ": ").concat(styles[key], " style."));
        }
      });
    }
    /**
     * Places the menu.
     * @private
     */

  }, {
    key: "_place",
    value: function _place() {
      var element = this.element;

      var _this$_getPos = this._getPos(),
          left = _this$_getPos.left,
          top = _this$_getPos.top;

      element.style.left = "".concat(left, "px");
      element.style.top = "".concat(top, "px");

      this._testStyles();
    }
    /**
     * @param {string} state The new state.
     * @returns {boolean} `true` of the current state is different from the given new state.
     */

  }, {
    key: "shouldStateBeChanged",
    value: function shouldStateBeChanged(state) {
      return (state === 'shown' || state === 'hidden') && state !== (this.element.classList.contains(this.options.classShown) ? 'shown' : 'hidden');
    }
    /**
     * Changes the shown/hidden state.
     * @private
     * @param {string} state The new state.
     * @param {object} detail The detail of the event trigging this action.
     * @param {Function} callback Callback called when change in state completes.
     */

  }, {
    key: "_changeState",
    value: function _changeState(state, detail, callback) {
      var _this2 = this;

      var shown = state === 'shown';
      var _this$options4 = this.options,
          refNode = _this$options4.refNode,
          classShown = _this$options4.classShown,
          classRefShown = _this$options4.classRefShown,
          triggerNode = _this$options4.triggerNode;

      if (!refNode) {
        throw new TypeError('Cannot find the reference node for changing the style.');
      }

      if (state === 'shown') {
        if (!this.hResize) {
          this.hResize = _globals_js_misc_resize__WEBPACK_IMPORTED_MODULE_8__["default"].add(function () {
            _this2._place();
          });
        }

        this._getContainer().appendChild(this.element);
      }

      this.element.setAttribute('aria-hidden', (!shown).toString());
      (triggerNode || refNode).setAttribute('aria-expanded', shown.toString());
      this.element.classList.toggle(classShown, shown);

      if (classRefShown) {
        refNode.classList.toggle(classRefShown, shown);
      }

      if (state === 'shown') {
        this._place(); // IE11 puts focus on elements with `.focus()`, even ones without `tabindex` attribute


        if (!this.element.hasAttribute(this.options.attribAvoidFocusOnOpen)) {
          var primaryFocusNode = this.element.querySelector(this.options.selectorPrimaryFocus);
          var contentNode = this.options.contentNode || this.element;
          var tabbableNode = contentNode.querySelector(_globals_js_settings__WEBPACK_IMPORTED_MODULE_2__["default"].selectorTabbable); // The programmatically focusable element may be (and typically will be) the content node itself;

          var focusableNode = contentNode.matches(_globals_js_settings__WEBPACK_IMPORTED_MODULE_2__["default"].selectorFocusable) ? contentNode : contentNode.querySelector(_globals_js_settings__WEBPACK_IMPORTED_MODULE_2__["default"].selectorFocusable);

          if (primaryFocusNode) {
            // User defined focusable node
            primaryFocusNode.focus();
          } else if (tabbableNode) {
            // First sequentially focusable node
            tabbableNode.focus();
          } else if (focusableNode) {
            // First programmatic focusable node
            focusableNode.focus();
          } else {
            this.element.focus();

            if (true) {
               true ? warning__WEBPACK_IMPORTED_MODULE_0___default()(focusableNode === null, 'Floating Menus must have at least a programmatically focusable child. ' + 'This can be accomplished by adding tabindex="-1" to the content element.') : undefined;
            }
          }
        }
      }

      if (state === 'hidden' && this.hResize) {
        this.hResize.release();
        this.hResize = null;
      }

      callback();
    }
  }, {
    key: "release",
    value: function release() {
      if (this.hResize) {
        this.hResize.release();
        this.hResize = null;
      }

      _get(_getPrototypeOf(FloatingMenu.prototype), "release", this).call(this);
    }
  }]);

  FloatingMenu.options = {
    selectorContainer: '[data-floating-menu-container]',
    selectorPrimaryFocus: '[data-floating-menu-primary-focus]',
    attribDirection: 'data-floating-menu-direction',
    attribAvoidFocusOnOpen: 'data-avoid-focus-on-open',
    classShown: '',
    // Should be provided from options arg in constructor
    classRefShown: '',
    // Should be provided from options arg in constructor
    eventBeforeShown: 'floating-menu-beingshown',
    eventAfterShown: 'floating-menu-shown',
    eventBeforeHidden: 'floating-menu-beinghidden',
    eventAfterHidden: 'floating-menu-hidden',
    refNode: null,
    // Should be provided from options arg in constructor
    offset: {
      left: 0,
      top: 0
    }
  };
  FloatingMenu.components = new WeakMap();
  return FloatingMenu;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_evented_show_hide_state__WEBPACK_IMPORTED_MODULE_4__["default"], _globals_js_mixins_track_blur__WEBPACK_IMPORTED_MODULE_6__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (FloatingMenu);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/inline-loading/inline-loading.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/inline-loading/inline-loading.js ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_toggle_attribute__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/toggle-attribute */ "./node_modules/carbon-components/es/globals/js/misc/toggle-attribute.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */









var InlineLoading = /*#__PURE__*/function (_mixin) {
  _inherits(InlineLoading, _mixin);

  var _super = _createSuper(InlineLoading);
  /**
   * Spinner indicating loading state.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as a spinner.
   * @param {object} [options] The component options.
   * @param {string} [options.initialState] The initial state, should be `inactive`, `active` or `finished`.
   */


  function InlineLoading(element, options) {
    var _this;

    _classCallCheck(this, InlineLoading);

    _this = _super.call(this, element, options); // Sets the initial state

    var initialState = _this.options.initialState;

    if (initialState) {
      _this.setState(initialState);
    }

    return _this;
  }
  /**
   * Sets active/inactive state.
   * @param {string} state The new state, should be `inactive`, `active` or `finished`.
   */


  _createClass(InlineLoading, [{
    key: "setState",
    value: function setState(state) {
      var states = this.constructor.states;
      var values = Object.keys(states).map(function (key) {
        return states[key];
      });

      if (values.indexOf(state) < 0) {
        throw new Error("One of the following value should be given as the state: ".concat(values.join(', ')));
      }

      var elem = this.element;
      var _this$options = this.options,
          selectorSpinner = _this$options.selectorSpinner,
          selectorFinished = _this$options.selectorFinished,
          selectorError = _this$options.selectorError,
          selectorTextActive = _this$options.selectorTextActive,
          selectorTextFinished = _this$options.selectorTextFinished,
          selectorTextError = _this$options.selectorTextError;
      var spinner = elem.querySelector(selectorSpinner);
      var finished = elem.querySelector(selectorFinished);
      var error = elem.querySelector(selectorError);
      var textActive = elem.querySelector(selectorTextActive);
      var textFinished = elem.querySelector(selectorTextFinished);
      var textError = elem.querySelector(selectorTextError);

      if (spinner) {
        spinner.classList.toggle(this.options.classLoadingStop, state !== states.ACTIVE);
        Object(_globals_js_misc_toggle_attribute__WEBPACK_IMPORTED_MODULE_5__["default"])(spinner, 'hidden', state !== states.INACTIVE && state !== states.ACTIVE);
      }

      if (finished) {
        Object(_globals_js_misc_toggle_attribute__WEBPACK_IMPORTED_MODULE_5__["default"])(finished, 'hidden', state !== states.FINISHED);
      }

      if (error) {
        Object(_globals_js_misc_toggle_attribute__WEBPACK_IMPORTED_MODULE_5__["default"])(error, 'hidden', state !== states.ERROR);
      }

      if (textActive) {
        Object(_globals_js_misc_toggle_attribute__WEBPACK_IMPORTED_MODULE_5__["default"])(textActive, 'hidden', state !== states.ACTIVE);
      }

      if (textFinished) {
        Object(_globals_js_misc_toggle_attribute__WEBPACK_IMPORTED_MODULE_5__["default"])(textFinished, 'hidden', state !== states.FINISHED);
      }

      if (textError) {
        Object(_globals_js_misc_toggle_attribute__WEBPACK_IMPORTED_MODULE_5__["default"])(textError, 'hidden', state !== states.ERROR);
      }

      return this;
    }
    /**
     * The list of states.
     * @type {object<string, string>}
     */

  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor, {@linkcode InlineLoading.create .create()},
     * or {@linkcode InlineLoading.init .init()},
     * properties in this object are overriden for the instance being create and how {@linkcode InlineLoading.init .init()} works.
     * @member InlineLoading.options
     * @type {object}
     * @property {string} selectorInit The CSS selector to find inline loading components.
     * @property {string} selectorSpinner The CSS selector to find the spinner.
     * @property {string} selectorFinished The CSS selector to find the "finished" icon.
     * @property {string} selectorError The CSS selector to find the "error" icon.
     * @property {string} selectorTextActive The CSS selector to find the text describing the active state.
     * @property {string} selectorTextFinished The CSS selector to find the text describing the finished state.
     * @property {string} selectorTextError The CSS selector to find the text describing the error state.
     * @property {string} classLoadingStop The CSS class for spinner's stopped state.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-inline-loading]',
        selectorSpinner: '[data-inline-loading-spinner]',
        selectorFinished: '[data-inline-loading-finished]',
        selectorError: '[data-inline-loading-error]',
        selectorTextActive: '[data-inline-loading-text-active]',
        selectorTextFinished: '[data-inline-loading-text-finished]',
        selectorTextError: '[data-inline-loading-text-error]',
        classLoadingStop: "".concat(prefix, "--loading--stop")
      };
    }
  }]);

  InlineLoading.states = {
    INACTIVE: 'inactive',
    ACTIVE: 'active',
    FINISHED: 'finished',
    ERROR: 'error'
  };
  InlineLoading.components = new WeakMap();
  return InlineLoading;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (InlineLoading);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/loading/loading.js":
/*!*************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/loading/loading.js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */









var Loading = /*#__PURE__*/function (_mixin) {
  _inherits(Loading, _mixin);

  var _super = _createSuper(Loading);
  /**
   * Spinner indicating loading state.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as a spinner.
   * @param {object} [options] The component options.
   * @param {boolean} [options.active] `true` if this spinner should roll.
   */


  function Loading(element, options) {
    var _this;

    _classCallCheck(this, Loading);

    _this = _super.call(this, element, options);
    _this.active = _this.options.active; // Initialize spinner

    _this.set(_this.active);

    return _this;
  }
  /**
   * Sets active/inactive state.
   * @param {boolean} active `true` if this spinner should roll.
   */


  _createClass(Loading, [{
    key: "set",
    value: function set(active) {
      if (typeof active !== 'boolean') {
        throw new TypeError('set expects a boolean.');
      }

      this.active = active;
      this.element.classList.toggle(this.options.classLoadingStop, !this.active);
      /**
       * If overlay is the parentNode then toggle it too.
       */

      var parentNode = this.element.parentNode;

      if (parentNode && parentNode.classList.contains(this.options.classLoadingOverlay)) {
        parentNode.classList.toggle(this.options.classLoadingOverlayStop, !this.active);
      }

      return this;
    }
    /**
     * Toggles active/inactive state.
     */

  }, {
    key: "toggle",
    value: function toggle() {
      return this.set(!this.active);
    }
    /**
     * @returns {boolean} `true` if this spinner is rolling.
     */

  }, {
    key: "isActive",
    value: function isActive() {
      return this.active;
    }
    /**
     * Sets state to inactive and deletes the loading element.
     */

  }, {
    key: "end",
    value: function end() {
      var _this2 = this;

      this.set(false);
      var handleAnimationEnd = this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__["default"])(this.element, 'animationend', function (evt) {
        if (handleAnimationEnd) {
          handleAnimationEnd = _this2.unmanage(handleAnimationEnd).release();
        }

        if (evt.animationName === 'rotate-end-p2') {
          _this2._deleteElement();
        }
      }));
    }
    /**
     * Delete component from the DOM.
     */

  }, {
    key: "_deleteElement",
    value: function _deleteElement() {
      var parentNode = this.element.parentNode;
      parentNode.removeChild(this.element);

      if (parentNode.classList.contains(this.options.selectorLoadingOverlay)) {
        parentNode.remove();
      }
    }
    /**
     * The map associating DOM element and spinner instance.
     * @member Loading.components
     * @type {WeakMap}
     */

  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor, {@linkcode Loading.create .create()}, or {@linkcode Loading.init .init()},
     * properties in this object are overriden for the instance being create and how {@linkcode Loading.init .init()} works.
     * @member Loading.options
     * @type {object}
     * @property {string} selectorInit The CSS selector to find spinners.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-loading]',
        selectorLoadingOverlay: ".".concat(prefix, "--loading-overlay"),
        classLoadingOverlay: "".concat(prefix, "--loading-overlay"),
        classLoadingStop: "".concat(prefix, "--loading--stop"),
        classLoadingOverlayStop: "".concat(prefix, "--loading-overlay--stop"),
        active: true
      };
    }
  }]);

  Loading.components = new WeakMap();
  return Loading;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (Loading);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/modal/modal.js":
/*!*********************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/modal/modal.js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var warning__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! warning */ "./node_modules/warning/browser.js");
/* harmony import */ var warning__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(warning__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_launcher__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-launcher */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-launcher.js");
/* harmony import */ var _globals_js_mixins_evented_show_hide_state__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/mixins/evented-show-hide-state */ "./node_modules/carbon-components/es/globals/js/mixins/evented-show-hide-state.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */












var Modal = /*#__PURE__*/function (_mixin) {
  _inherits(Modal, _mixin);

  var _super = _createSuper(Modal);
  /**
   * Modal dialog.
   * @extends CreateComponent
   * @extends InitComponentByLauncher
   * @extends EventedShowHideState
   * @extends Handles
   * @param {HTMLElement} element The element working as a modal dialog.
   * @param {object} [options] The component options.
   * @param {string} [options.classVisible] The CSS class for the visible state.
   * @param {string} [options.classBody] The CSS class for `<body>` with open modal.
   * @param {string} [options.eventBeforeShown]
   *   The name of the custom event fired before this modal is shown.
   *   Cancellation of this event stops showing the modal.
   * @param {string} [options.eventAfterShown]
   *   The name of the custom event telling that modal is sure shown
   *   without being canceled by the event handler named by `eventBeforeShown` option (`modal-beingshown`).
   * @param {string} [options.eventBeforeHidden]
   *   The name of the custom event fired before this modal is hidden.
   *   Cancellation of this event stops hiding the modal.
   * @param {string} [options.eventAfterHidden]
   *   The name of the custom event telling that modal is sure hidden
   *   without being canceled by the event handler named by `eventBeforeHidden` option (`modal-beinghidden`).
   */


  function Modal(element, options) {
    var _this;

    _classCallCheck(this, Modal);

    _this = _super.call(this, element, options);
    _this._handleFocusinListener = void 0;
    _this._handleKeydownListener = void 0;

    _this._handleFocusin = function (evt) {
      var focusWrapNode = _this.element.querySelector(_this.options.selectorModalContainer) || _this.element;

      if (_this.element.classList.contains(_this.options.classVisible) && !focusWrapNode.contains(evt.target) && _this.options.selectorsFloatingMenus.every(function (selector) {
        return !Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_7__["default"])(evt, selector);
      })) {
        _this.element.querySelector(_globals_js_settings__WEBPACK_IMPORTED_MODULE_1__["default"].selectorTabbable).focus();
      }
    };

    _this._hookCloseActions();

    return _this;
  }
  /**
   * The handle for `focusin` event listener.
   * Used for "focus-wrap" feature.
   * @type {Handle}
   * @private
   */


  _createClass(Modal, [{
    key: "createdByLauncher",

    /**
     * A method that runs when `.init()` is called from `initComponentByLauncher`.
     * @param {Event} evt The event fired on the launcher button.
     */
    value: function createdByLauncher(evt) {
      this.show(evt);
    }
    /**
     * Determines whether or not to emit events and callback function when `.changeState()` is called from `eventedState`.
     * @param {string} state The new state.
     * @returns {boolean} `true` if the given `state` is different from current state.
     */

  }, {
    key: "shouldStateBeChanged",
    value: function shouldStateBeChanged(state) {
      if (state === 'shown') {
        return !this.element.classList.contains(this.options.classVisible);
      }

      return this.element.classList.contains(this.options.classVisible);
    }
    /**
     * Changes the shown/hidden state.
     * @private
     * @param {string} state The new state.
     * @param {object} detail The detail data to be included in the event that will be fired.
     * @param {Function} callback Callback called when change in state completes.
     */

  }, {
    key: "_changeState",
    value: function _changeState(state, detail, callback) {
      var _this2 = this;

      var handleTransitionEnd;

      var transitionEnd = function transitionEnd() {
        if (handleTransitionEnd) {
          handleTransitionEnd = _this2.unmanage(handleTransitionEnd).release();
        }

        if (state === 'shown' && _this2.element.offsetWidth > 0 && _this2.element.offsetHeight > 0) {
          _this2.previouslyFocusedNode = _this2.element.ownerDocument.activeElement;

          var focusableItem = _this2.element.querySelector(_this2.options.selectorPrimaryFocus) || _this2.element.querySelector(_globals_js_settings__WEBPACK_IMPORTED_MODULE_1__["default"].selectorTabbable);

          focusableItem.focus();

          if (true) {
             true ? warning__WEBPACK_IMPORTED_MODULE_0___default()(focusableItem, "Modals need to contain a focusable element by either using " + "`".concat(_this2.options.selectorPrimaryFocus, "` or settings.selectorTabbable.")) : undefined;
          }
        }

        callback();
      };

      if (this._handleFocusinListener) {
        this._handleFocusinListener = this.unmanage(this._handleFocusinListener).release();
      }

      if (state === 'shown') {
        var hasFocusin = ('onfocusin' in this.element.ownerDocument.defaultView);
        var focusinEventName = hasFocusin ? 'focusin' : 'focus';
        this._handleFocusinListener = this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_8__["default"])(this.element.ownerDocument, focusinEventName, this._handleFocusin, !hasFocusin));
      }

      if (state === 'hidden') {
        this.element.classList.toggle(this.options.classVisible, false);
        this.element.ownerDocument.body.classList.toggle(this.options.classBody, false);

        if (this.options.selectorFocusOnClose || this.previouslyFocusedNode) {
          (this.element.ownerDocument.querySelector(this.options.selectorFocusOnClose) || this.previouslyFocusedNode).focus();
        }
      } else if (state === 'shown') {
        this.element.classList.toggle(this.options.classVisible, true);
        this.element.ownerDocument.body.classList.toggle(this.options.classBody, true);
      }

      handleTransitionEnd = this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_8__["default"])(this.element, 'transitionend', transitionEnd));
    }
  }, {
    key: "_hookCloseActions",
    value: function _hookCloseActions() {
      var _this3 = this;

      this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_8__["default"])(this.element, 'click', function (evt) {
        var closeButton = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_7__["default"])(evt, _this3.options.selectorModalClose);

        if (closeButton) {
          evt.delegateTarget = closeButton; // eslint-disable-line no-param-reassign
        }

        if (closeButton || evt.target === _this3.element) {
          _this3.hide(evt);
        }
      }));

      if (this._handleKeydownListener) {
        this._handleKeydownListener = this.unmanage(this._handleKeydownListener).release();
      }

      this._handleKeydownListener = this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_8__["default"])(this.element.ownerDocument.body, 'keydown', function (evt) {
        // Avoid running `evt.stopPropagation()` only when modal is shown
        if (evt.which === 27 && _this3.shouldStateBeChanged('hidden')) {
          evt.stopPropagation();

          _this3.hide(evt);
        }
      }));
    }
    /**
     * Handles `focusin` (or `focus` depending on browser support of `focusin`) event to do wrap-focus behavior.
     * @param {Event} evt The event.
     * @private
     */

  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor, {@linkcode Modal.create .create()}, or {@linkcode Modal.init .init()},
     * properties in this object are overriden for the instance being create and how {@linkcode Modal.init .init()} works.
     * @member Modal.options
     * @type {object}
     * @property {string} selectorInit The CSS class to find modal dialogs.
     * @property {string} [selectorModalClose] The selector to find elements that close the modal.
     * @property {string} [selectorPrimaryFocus] The CSS selector to determine the element to put focus when modal gets open.
     * @property {string} [selectorFocusOnClose] The CSS selector to determine the element to put focus when modal closes.
     *   If undefined, focus returns to the previously focused element prior to the modal opening.
     * @property {string} [selectorModalContainer] The CSS selector for the content container of the modal for focus wrap feature.
     * @property {string} attribInitTarget The attribute name in the launcher buttons to find target modal dialogs.
     * @property {string[]} [selectorsFloatingMenu]
     *   The CSS selectors of floating menus.
     *   Used for detecting if focus-wrap behavior should be disabled temporarily.
     * @property {string} [classVisible] The CSS class for the visible state.
     * @property {string} [classBody] The CSS class for `<body>` with open modal.
     * @property {string} [classNoScroll] The CSS class for hiding scroll bar in body element while modal is shown.
     * @property {string} [eventBeforeShown]
     *   The name of the custom event fired before this modal is shown.
     *   Cancellation of this event stops showing the modal.
     * @property {string} [eventAfterShown]
     *   The name of the custom event telling that modal is sure shown
     *   without being canceled by the event handler named by `eventBeforeShown` option (`modal-beingshown`).
     * @property {string} [eventBeforeHidden]
     *   The name of the custom event fired before this modal is hidden.
     *   Cancellation of this event stops hiding the modal.
     * @property {string} [eventAfterHidden]
     *   The name of the custom event telling that modal is sure hidden
     *   without being canceled by the event handler named by `eventBeforeHidden` option (`modal-beinghidden`).
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_1__["default"].prefix;
      return {
        selectorInit: '[data-modal]',
        selectorModalClose: '[data-modal-close]',
        selectorPrimaryFocus: '[data-modal-primary-focus]',
        selectorsFloatingMenus: [".".concat(prefix, "--overflow-menu-options"), ".".concat(prefix, "--tooltip"), '.flatpickr-calendar'],
        selectorModalContainer: ".".concat(prefix, "--modal-container"),
        classVisible: 'is-visible',
        classBody: "".concat(prefix, "--body--with-modal-open"),
        attribInitTarget: 'data-modal-target',
        initEventNames: ['click'],
        eventBeforeShown: 'modal-beingshown',
        eventAfterShown: 'modal-shown',
        eventBeforeHidden: 'modal-beinghidden',
        eventAfterHidden: 'modal-hidden'
      };
    }
  }]);

  Modal.components = new WeakMap();
  return Modal;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_2__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_init_component_by_launcher__WEBPACK_IMPORTED_MODULE_4__["default"], _globals_js_mixins_evented_show_hide_state__WEBPACK_IMPORTED_MODULE_5__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_6__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (Modal);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/notification/notification.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/notification/notification.js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_evented_state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/evented-state */ "./node_modules/carbon-components/es/globals/js/mixins/evented-state.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */









var Notification = /*#__PURE__*/function (_mixin) {
  _inherits(Notification, _mixin);

  var _super = _createSuper(Notification);
  /**
   * InlineNotification.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as a InlineNotification.
   */


  function Notification(element, options) {
    var _this;

    _classCallCheck(this, Notification);

    _this = _super.call(this, element, options);

    _this._changeState = function (state, callback) {
      if (state === 'delete-notification') {
        _this.element.parentNode.removeChild(_this.element);

        _this.release();
      }

      callback();
    };

    _this.button = element.querySelector(_this.options.selectorButton);

    if (_this.button) {
      _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__["default"])(_this.button, 'click', function (evt) {
        if (evt.currentTarget === _this.button) {
          _this.remove();
        }
      }));
    }

    return _this;
  }

  _createClass(Notification, [{
    key: "remove",
    value: function remove() {
      this.changeState('delete-notification');
    }
    /**
     * The map associating DOM element and accordion UI instance.
     * @type {WeakMap}
     */

  }]);

  Notification.components = new WeakMap();
  Notification.options = {
    selectorInit: '[data-notification]',
    selectorButton: '[data-notification-btn]',
    eventBeforeDeleteNotification: 'notification-before-delete',
    eventAfterDeleteNotification: 'notification-after-delete'
  };
  return Notification;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_0__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_1__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_evented_state__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (Notification);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/number-input/number-input.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/number-input/number-input.js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */









var NumberInput = /*#__PURE__*/function (_mixin) {
  _inherits(NumberInput, _mixin);

  var _super = _createSuper(NumberInput);
  /**
   * Number input UI.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as a number input UI.
   */


  function NumberInput(element, options) {
    var _this;

    _classCallCheck(this, NumberInput);

    _this = _super.call(this, element, options); // Broken DOM tree is seen with up/down arrows <svg> in IE, which breaks event delegation.
    // <svg> does not have `Element.classList` in IE11

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__["default"])(_this.element.querySelector('.up-icon'), 'click', function (event) {
      _this._handleClick(event);
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__["default"])(_this.element.querySelector('.down-icon'), 'click', function (event) {
      _this._handleClick(event);
    }));

    return _this;
  }
  /**
   * Increase/decrease number by clicking on up/down icons.
   * @param {Event} event The event triggering this method.
   */


  _createClass(NumberInput, [{
    key: "_handleClick",
    value: function _handleClick(event) {
      var numberInput = this.element.querySelector(this.options.selectorInput);
      var target = event.currentTarget.getAttribute('class').split(' ');
      var min = Number(numberInput.min);
      var max = Number(numberInput.max);
      var step = Number(numberInput.step) || 1;

      if (target.indexOf('up-icon') >= 0) {
        var nextValue = Number(numberInput.value) + step;

        if (numberInput.max === '') {
          numberInput.value = nextValue;
        } else if (numberInput.value < max) {
          if (nextValue > max) {
            numberInput.value = max;
          } else if (nextValue < min) {
            numberInput.value = min;
          } else {
            numberInput.value = nextValue;
          }
        }
      } else if (target.indexOf('down-icon') >= 0) {
        var _nextValue = Number(numberInput.value) - step;

        if (numberInput.min === '') {
          numberInput.value = _nextValue;
        } else if (numberInput.value > min) {
          if (_nextValue < min) {
            numberInput.value = min;
          } else if (_nextValue > max) {
            numberInput.value = max;
          } else {
            numberInput.value = _nextValue;
          }
        }
      } // Programmatic change in value (including `stepUp()`/`stepDown()`) won't fire change event


      numberInput.dispatchEvent(new CustomEvent('change', {
        bubbles: true,
        cancelable: false
      }));
    }
    /**
     * The map associating DOM element and number input UI instance.
     * @member NumberInput.components
     * @type {WeakMap}
     */

  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor,
     * {@linkcode NumberInput.create .create()}, or {@linkcode NumberInput.init .init()},
     * properties in this object are overriden for the instance being create and how {@linkcode NumberInput.init .init()} works.
     * @member NumberInput.options
     * @type {object}
     * @property {string} selectorInit The CSS selector to find number input UIs.
     * @property {string} [selectorInput] The CSS selector to find the `<input>` element.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-numberinput]',
        selectorInput: ".".concat(prefix, "--number input")
      };
    }
  }]);

  NumberInput.components = new WeakMap();
  return NumberInput;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (NumberInput);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/overflow-menu/overflow-menu.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/overflow-menu/overflow-menu.js ***!
  \*************************************************************************************/
/*! exports provided: getMenuOffset, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMenuOffset", function() { return getMenuOffset; });
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_evented_show_hide_state__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/mixins/evented-show-hide-state */ "./node_modules/carbon-components/es/globals/js/mixins/evented-show-hide-state.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../floating-menu/floating-menu */ "./node_modules/carbon-components/es/components/floating-menu/floating-menu.js");
/* harmony import */ var _globals_js_misc_get_launching_details__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../globals/js/misc/get-launching-details */ "./node_modules/carbon-components/es/globals/js/misc/get-launching-details.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */












/**
 * The CSS property names of the arrow keyed by the floating menu direction.
 * @type {object<string, string>}
 */

var triggerButtonPositionProps = /* #__PURE__ */function () {
  var _ref;

  return _ref = {}, _defineProperty(_ref, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_7__["DIRECTION_TOP"], 'bottom'), _defineProperty(_ref, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_7__["DIRECTION_BOTTOM"], 'top'), _defineProperty(_ref, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_7__["DIRECTION_LEFT"], 'left'), _defineProperty(_ref, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_7__["DIRECTION_RIGHT"], 'right'), _ref;
}();
/**
 * Determines how the position of arrow should affect the floating menu position.
 * @type {object<string, number>}
 */


var triggerButtonPositionFactors = /* #__PURE__ */function () {
  var _ref2;

  return _ref2 = {}, _defineProperty(_ref2, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_7__["DIRECTION_TOP"], -2), _defineProperty(_ref2, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_7__["DIRECTION_BOTTOM"], -1), _defineProperty(_ref2, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_7__["DIRECTION_LEFT"], -2), _defineProperty(_ref2, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_7__["DIRECTION_RIGHT"], -1), _ref2;
}();
/**
 * @param {Element} menuBody The menu body with the menu arrow.
 * @param {string} direction The floating menu direction.
 * @param {Element} trigger The trigger button.
 * @returns {FloatingMenu~offset} The adjustment of the floating menu position, upon the position of the menu arrow.
 * @private
 */


var getMenuOffset = function getMenuOffset(menuBody, direction, trigger) {
  var triggerButtonPositionProp = triggerButtonPositionProps[direction];
  var triggerButtonPositionFactor = triggerButtonPositionFactors[direction];

  if (!triggerButtonPositionProp || !triggerButtonPositionFactor) {
    console.warn('Wrong floating menu direction:', direction); // eslint-disable-line no-console
  }

  var menuWidth = menuBody.offsetWidth;
  var menuHeight = menuBody.offsetHeight; // eslint-disable-next-line no-use-before-define

  var menu = OverflowMenu.components.get(trigger);

  if (!menu) {
    throw new TypeError('Overflow menu instance cannot be found.');
  }

  var flip = menuBody.classList.contains(menu.options.classMenuFlip);

  if (triggerButtonPositionProp === 'top' || triggerButtonPositionProp === 'bottom') {
    var triggerWidth = trigger.offsetWidth;
    return {
      left: (!flip ? 1 : -1) * (menuWidth / 2 - triggerWidth / 2),
      top: 0
    };
  }

  if (triggerButtonPositionProp === 'left' || triggerButtonPositionProp === 'right') {
    var triggerHeight = trigger.offsetHeight;
    return {
      left: 0,
      top: (!flip ? 1 : -1) * (menuHeight / 2 - triggerHeight / 2)
    };
  }

  return undefined;
};

var OverflowMenu = /*#__PURE__*/function (_mixin) {
  _inherits(OverflowMenu, _mixin);

  var _super = _createSuper(OverflowMenu);
  /**
   * Overflow menu.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as a modal dialog.
   * @param {object} [options] The component options.
   * @param {string} [options.selectorOptionMenu] The CSS selector to find the menu.
   * @param {string} [options.selectorTrigger] The CSS selector to find the trigger button.
   * @param {string} [options.classShown] The CSS class for the shown state, for the trigger UI.
   * @param {string} [options.classMenuShown] The CSS class for the shown state, for the menu.
   * @param {string} [options.classMenuFlip] The CSS class for the flipped state of the menu.
   * @param {object} [options.objMenuOffset] The offset locating the menu for the non-flipped state.
   * @param {object} [options.objMenuOffsetFlip] The offset locating the menu for the flipped state.
   */


  function OverflowMenu(element, options) {
    var _this;

    _classCallCheck(this, OverflowMenu);

    _this = _super.call(this, element, options);

    _this.getCurrentNavigation = function () {
      var focused = _this.element.ownerDocument.activeElement;
      return focused.nodeType === Node.ELEMENT_NODE && focused.matches(_this.options.selectorItem) ? focused : null;
    };

    _this.navigate = function (direction) {
      var items = _toConsumableArray(_this.element.ownerDocument.querySelectorAll(_this.options.selectorItem));

      var start = _this.getCurrentNavigation() || _this.element.querySelector(_this.options.selectorItemSelected);

      var getNextItem = function getNextItem(old) {
        var handleUnderflow = function handleUnderflow(index, length) {
          return index + (index >= 0 ? 0 : length);
        };

        var handleOverflow = function handleOverflow(index, length) {
          return index - (index < length ? 0 : length);
        }; // `items.indexOf(old)` may be -1 (Scenario of no previous focus)


        var index = Math.max(items.indexOf(old) + direction, -1);
        return items[handleUnderflow(handleOverflow(index, items.length), items.length)];
      };

      for (var current = getNextItem(start); current && current !== start; current = getNextItem(current)) {
        if (!current.matches(_this.options.selectorItemHidden) && !current.parentNode.matches(_this.options.selectorItemHidden) && !current.matches(_this.options.selectorItemSelected)) {
          current.focus();
          break;
        }
      }
    };

    if (_this.element.getAttribute('role') !== 'button') {
      // Would prefer to use the aria-controls with a specific ID but we
      // don't have the menuOptions list at this point to pull the ID from
      _this.triggerNode = _this.element.querySelector(_this.options.selectorTrigger);
    }

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_9__["default"])(_this.element.ownerDocument, 'click', function (event) {
      _this._handleDocumentClick(event);

      _this.wasOpenBeforeClick = undefined;
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_9__["default"])(_this.element.ownerDocument, 'keydown', function (event) {
      _this._handleKeyPress(event);
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_9__["default"])(_this.element, 'mousedown', function () {
      _this.wasOpenBeforeClick = element.classList.contains(_this.options.classShown);
    }));

    return _this;
  }
  /**
   * Changes the shown/hidden state.
   * @param {string} state The new state.
   * @param {object} detail The detail of the event trigging this action.
   * @param {Function} callback Callback called when change in state completes.
   */


  _createClass(OverflowMenu, [{
    key: "changeState",
    value: function changeState(state, detail, callback) {
      if (!this.optionMenu) {
        var optionMenu = this.element.querySelector(this.options.selectorOptionMenu);

        if (!optionMenu) {
          throw new Error('Cannot find the target menu.');
        } // Lazily create a component instance for menu


        this.optionMenu = _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_7__["default"].create(optionMenu, {
          refNode: this.element,
          classShown: this.options.classMenuShown,
          classRefShown: this.options.classShown,
          offset: this.options.objMenuOffset,
          triggerNode: this.triggerNode,
          contentNode: this.element.querySelector(this.options.selectorContent)
        });
        this.children.push(this.optionMenu);
      }

      if (this.optionMenu.element.classList.contains(this.options.classMenuFlip)) {
        this.optionMenu.options.offset = this.options.objMenuOffsetFlip;
      } // Delegates the action of changing state to the menu.
      // (And thus the before/after shown/hidden events are fired from the menu)


      this.optionMenu.changeState(state, Object.assign(detail, {
        delegatorNode: this.element
      }), callback);
    }
    /**
     * Handles click on document.
     * @param {Event} event The triggering event.
     * @private
     */

  }, {
    key: "_handleDocumentClick",
    value: function _handleDocumentClick(event) {
      var _this2 = this;

      var element = this.element,
          optionMenu = this.optionMenu,
          wasOpenBeforeClick = this.wasOpenBeforeClick,
          triggerNode = this.triggerNode;
      var isOfSelf = element.contains(event.target);
      var isOfMenu = optionMenu && optionMenu.element.contains(event.target);
      var shouldBeOpen = isOfSelf && !wasOpenBeforeClick;
      var state = shouldBeOpen ? 'shown' : 'hidden';

      if (isOfSelf) {
        if (element.tagName === 'A') {
          event.preventDefault();
        }

        event.delegateTarget = element; // eslint-disable-line no-param-reassign
      }

      if (!isOfMenu || Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_1__["default"])(event, this.options.selectorItem)) {
        this.changeState(state, Object(_globals_js_misc_get_launching_details__WEBPACK_IMPORTED_MODULE_8__["default"])(event), function () {
          if (state === 'hidden' && isOfMenu) {
            // @todo Can clean up to use `this.triggerNode` once non-compliant code is deprecated
            _this2[triggerNode ? 'triggerNode' : 'element'].focus();
          }
        });
      }
    }
    /**
     * Provides the element to move focus from
     * @returns {Element} Currently highlighted element.
     */

  }, {
    key: "_handleKeyPress",

    /**
     * Handles key press on document.
     * @param {Event} event The triggering event.
     * @private
     */
    value: function _handleKeyPress(event) {
      var _this3 = this;

      var key = event.which;
      var element = this.element,
          optionMenu = this.optionMenu,
          options = this.options,
          triggerNode = this.triggerNode;
      var isOfMenu = optionMenu && optionMenu.element.contains(event.target);
      var isExpanded = this.element.classList.contains(this.options.classShown); // @todo Can clean up to use `this.triggerNode` once non-compliant code is deprecated

      var triggerElement = triggerNode ? 'triggerNode' : 'element';

      switch (key) {
        // Enter || Space bar
        case 13:
        case 32:
          {
            if (!isExpanded && this.element.ownerDocument.activeElement !== this.element) {
              return;
            }

            var isOfSelf = element.contains(event.target);
            var shouldBeOpen = isOfSelf && !element.classList.contains(options.classShown);
            var state = shouldBeOpen ? 'shown' : 'hidden';

            if (isOfSelf) {
              event.delegateTarget = element; // eslint-disable-line no-param-reassign

              event.preventDefault(); // prevent scrolling

              this.changeState(state, Object(_globals_js_misc_get_launching_details__WEBPACK_IMPORTED_MODULE_8__["default"])(event), function () {
                if (state === 'hidden' && isOfMenu) {
                  _this3[triggerElement].focus();
                }
              });
            }

            break;
          }

        case 38: // up arrow

        case 40:
          // down arrow
          {
            if (!isExpanded) {
              return;
            }

            event.preventDefault(); // prevent scrolling

            var direction = {
              38: -1,
              40: 1
            }[event.which];
            this.navigate(direction);
          }
          break;

        default:
          break;
      }
    }
  }], [{
    key: "options",
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-overflow-menu]',
        selectorOptionMenu: ".".concat(prefix, "--overflow-menu-options"),
        selectorTrigger: 'button[aria-haspopup]',
        selectorContent: ".".concat(prefix, "--overflow-menu-options__content"),
        selectorItem: "\n        .".concat(prefix, "--overflow-menu-options--open\n        .").concat(prefix, "--overflow-menu-options__option:not(.").concat(prefix, "--overflow-menu-options__option--disabled) >\n        .").concat(prefix, "--overflow-menu-options__btn\n      "),
        classShown: "".concat(prefix, "--overflow-menu--open"),
        classMenuShown: "".concat(prefix, "--overflow-menu-options--open"),
        classMenuFlip: "".concat(prefix, "--overflow-menu--flip"),
        objMenuOffset: getMenuOffset,
        objMenuOffsetFlip: getMenuOffset
      };
    }
  }]);

  OverflowMenu.components = new WeakMap();
  return OverflowMenu;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_2__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_4__["default"], _globals_js_mixins_evented_show_hide_state__WEBPACK_IMPORTED_MODULE_5__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_6__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (OverflowMenu);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/pagination-nav/pagination-nav.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/pagination-nav/pagination-nav.js ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */









var PaginationNav = /*#__PURE__*/function (_mixin) {
  _inherits(PaginationNav, _mixin);

  var _super = _createSuper(PaginationNav);
  /**
   * Pagination Nav component
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as a pagination nav.
   */


  function PaginationNav(element, options) {
    var _this;

    _classCallCheck(this, PaginationNav);

    _this = _super.call(this, element, options);

    _this.getActivePageNumber = function () {
      var pageNum;

      var activePageElement = _this.element.querySelector(_this.options.selectorPageActive);

      if (activePageElement) {
        pageNum = Number(activePageElement.getAttribute(_this.options.attribPage));
      }

      return pageNum;
    };

    _this.clearActivePage = function (evt) {
      var pageButtonNodeList = _this.element.querySelectorAll(_this.options.selectorPageButton);

      var pageSelectElement = _this.element.querySelector(_this.options.selectorPageSelect);

      Array.prototype.forEach.call(pageButtonNodeList, function (el) {
        el.classList.remove(_this.options.classActive, _this.options.classDisabled);
        el.removeAttribute(_this.options.attribActive);
        el.removeAttribute('aria-disabled');
        el.removeAttribute('aria-current');
      });

      if (pageSelectElement) {
        pageSelectElement.removeAttribute('aria-current');
        var pageSelectElementOptions = pageSelectElement.options;
        Array.prototype.forEach.call(pageSelectElementOptions, function (el) {
          el.removeAttribute(_this.options.attribActive);
        });

        if (!evt.target.matches(_this.options.selectorPageSelect)) {
          pageSelectElement.classList.remove(_this.options.classActive);
          pageSelectElement.value = '';
        }
      }
    };

    _this.handleClick = function (evt) {
      if (!evt.target.getAttribute('aria-disabled') === true) {
        var nextActivePageNumber = _this.getActivePageNumber();

        var pageElementNodeList = _this.element.querySelectorAll(_this.options.selectorPageElement);

        var pageSelectElement = _this.element.querySelector(_this.options.selectorPageSelect);

        _this.clearActivePage(evt);

        if (evt.target.matches(_this.options.selectorPageButton)) {
          nextActivePageNumber = Number(evt.target.getAttribute(_this.options.attribPage));
        }

        if (evt.target.matches(_this.options.selectorPagePrevious)) {
          nextActivePageNumber -= 1;
        }

        if (evt.target.matches(_this.options.selectorPageNext)) {
          nextActivePageNumber += 1;
        }

        var pageTargetElement = pageElementNodeList[nextActivePageNumber - 1];
        pageTargetElement.setAttribute(_this.options.attribActive, true);

        if (pageTargetElement.tagName === 'OPTION') {
          pageSelectElement.value = _this.getActivePageNumber();
          pageSelectElement.classList.add(_this.options.classActive);
          pageSelectElement.setAttribute('aria-current', 'page');
        } else {
          pageTargetElement.classList.add(_this.options.classActive, _this.options.classDisabled);
          pageTargetElement.setAttribute('aria-disabled', true);
          pageTargetElement.setAttribute('aria-current', 'page');
        }

        _this.setPrevNextStates();
      }
    };

    _this.handleSelectChange = function (evt) {
      _this.clearActivePage(evt);

      var pageSelectElement = _this.element.querySelector(_this.options.selectorPageSelect);

      var pageSelectElementOptions = pageSelectElement.options;
      pageSelectElementOptions[pageSelectElementOptions.selectedIndex].setAttribute(_this.options.attribActive, true);
      evt.target.setAttribute('aria-current', 'page');
      evt.target.classList.add(_this.options.classActive);

      _this.setPrevNextStates();
    };

    _this.setPrevNextStates = function () {
      var pageElementNodeList = _this.element.querySelectorAll(_this.options.selectorPageElement);

      var totalPages = pageElementNodeList.length;

      var pageDirectionElementPrevious = _this.element.querySelector(_this.options.selectorPagePrevious);

      var pageDirectionElementNext = _this.element.querySelector(_this.options.selectorPageNext);

      if (pageDirectionElementPrevious) {
        if (_this.getActivePageNumber() <= 1) {
          pageDirectionElementPrevious.setAttribute('aria-disabled', true);
          pageDirectionElementPrevious.classList.add(_this.options.classDisabled);
        } else {
          pageDirectionElementPrevious.removeAttribute('aria-disabled');
          pageDirectionElementPrevious.classList.remove(_this.options.classDisabled);
        }
      }

      if (pageDirectionElementNext) {
        if (_this.getActivePageNumber() >= totalPages) {
          pageDirectionElementNext.setAttribute('aria-disabled', true);
          pageDirectionElementNext.classList.add(_this.options.classDisabled);
        } else {
          pageDirectionElementNext.removeAttribute('aria-disabled');
          pageDirectionElementNext.classList.remove(_this.options.classDisabled);
        }
      }
    };

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__["default"])(_this.element, 'click', function (evt) {
      return _this.handleClick(evt);
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__["default"])(_this.element, 'change', function (evt) {
      if (evt.target.matches(_this.options.selectorPageSelect)) {
        _this.handleSelectChange(evt);
      }
    }));

    return _this;
  }
  /**
   * Get active page number
   */


  _createClass(PaginationNav, null, [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor, {@linkcode PaginationNav.create .create()},
     * or {@linkcode PaginationNav.init .init()},
     * properties in this object are overriden for the instance being create and how {@linkcode PaginationNav.init .init()} works.
     * @member PaginationNav.options
     * @type {object}
     * @property {string} selectorInit The data attribute to find pagination nav.
     * @property {string} selectorPageElement The data attribute to find page element.
     * @property {string} selectorPageButton The data attribute to find page interactive element.
     * @property {string} selectorPageDirection The data attribute to find page change element.
     * @property {string} selectorPageSelect The data attribute to find page select element.
     * @property {string} selectorPageActive The data attribute to find active page element.
     * @property {string} [classActive] The CSS class for page's selected state.
     * @property {string} [classDisabled] The CSS class for page's disabled state.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-pagination-nav]',
        selectorPageElement: '[data-page]',
        selectorPageButton: '[data-page-button]',
        selectorPagePrevious: '[data-page-previous]',
        selectorPageNext: '[data-page-next]',
        selectorPageSelect: '[data-page-select]',
        selectorPageActive: '[data-page-active="true"]',
        attribPage: 'data-page',
        attribActive: 'data-page-active',
        classActive: "".concat(prefix, "--pagination-nav__page--active"),
        classDisabled: "".concat(prefix, "--pagination-nav__page--disabled")
      };
    }
  }]);

  PaginationNav.components = new WeakMap();
  return PaginationNav;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (PaginationNav);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/pagination/pagination.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/pagination/pagination.js ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */









var Pagination = /*#__PURE__*/function (_mixin) {
  _inherits(Pagination, _mixin);

  var _super = _createSuper(Pagination);
  /**
   * Pagination component.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @param {HTMLElement} element The element working as a pagination component.
   * @param {object} [options] The component options.
   * @property {string} [selectorInit] The CSS selector to find pagination components.
   * @property {string} [selectorItemsPerPageInput]
   *   The CSS selector to find the input that determines the number of items per page.
   * @property {string} [selectorPageNumberInput] The CSS selector to find the input that changes the page displayed.
   * @property {string} [selectorPageBackward] The CSS selector to find the button that goes back a page.
   * @property {string} [selectorPageForward] The CSS selector to find the button that goes forward a page.
   * @property {string} [eventItemsPerPage]
   *   The name of the custom event fired when a user changes the number of items per page.
   *   event.detail.value contains the number of items a user wishes to see.
   * @property {string} [eventPageNumber]
   *   The name of the custom event fired when a user inputs a specific page number.
   *   event.detail.value contains the value that the user input.
   * @property {string} [eventPageChange]
   *   The name of the custom event fired when a user goes forward or backward a page.
   *   event.detail.direction contains the direction a user wishes to go.
   */


  function Pagination(element, options) {
    var _this;

    _classCallCheck(this, Pagination);

    _this = _super.call(this, element, options);

    _this._emitEvent = function (evtName, detail) {
      var event = new CustomEvent("".concat(evtName), {
        bubbles: true,
        cancelable: true,
        detail: detail
      });

      _this.element.dispatchEvent(event);
    };

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__["default"])(_this.element, 'click', function (evt) {
      if (Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_4__["default"])(evt, _this.options.selectorPageBackward)) {
        var detail = {
          initialEvt: evt,
          element: evt.target,
          direction: 'backward'
        };

        _this._emitEvent(_this.options.eventPageChange, detail);
      } else if (Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_4__["default"])(evt, _this.options.selectorPageForward)) {
        var _detail = {
          initialEvt: evt,
          element: evt.target,
          direction: 'forward'
        };

        _this._emitEvent(_this.options.eventPageChange, _detail);
      }
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__["default"])(_this.element, 'input', function (evt) {
      if (Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_4__["default"])(evt, _this.options.selectorItemsPerPageInput)) {
        var detail = {
          initialEvt: evt,
          element: evt.target,
          value: evt.target.value
        };

        _this._emitEvent(_this.options.eventItemsPerPage, detail);
      } else if (Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_4__["default"])(evt, _this.options.selectorPageNumberInput)) {
        var _detail2 = {
          initialEvt: evt,
          element: evt.target,
          value: evt.target.value
        };

        _this._emitEvent(_this.options.eventPageNumber, _detail2);
      }
    }));

    return _this;
  }
  /**
   * Dispatches a custom event
   * @param {string} evtName name of the event to be dispatched.
   * @param {object} detail contains the original event and any other necessary details.
   */


  Pagination.components = new WeakMap();
  Pagination.options = {
    selectorInit: '[data-pagination]',
    selectorItemsPerPageInput: '[data-items-per-page]',
    selectorPageNumberInput: '[data-page-number-input]',
    selectorPageBackward: '[data-page-backward]',
    selectorPageForward: '[data-page-forward]',
    eventItemsPerPage: 'itemsPerPage',
    eventPageNumber: 'pageNumber',
    eventPageChange: 'pageChange'
  };
  return Pagination;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_0__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_1__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_3__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (Pagination);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/progress-indicator/progress-indicator.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/progress-indicator/progress-indicator.js ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */







var toArray = function toArray(arrayLike) {
  return Array.prototype.slice.call(arrayLike);
};

var ProgressIndicator = /*#__PURE__*/function (_mixin) {
  _inherits(ProgressIndicator, _mixin);

  var _super = _createSuper(ProgressIndicator);
  /**
   * ProgressIndicator.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @param {HTMLElement} element The element representing the ProgressIndicator.
   * @param {object} [options] The component options.
   * @property {string} [options.selectorStepElement] The CSS selector to find step elements.
   * @property {string} [options.selectorCurrent] The CSS selector to find the current step element.
   * @property {string} [options.selectorIncomplete] The CSS class to find incomplete step elements.
   * @property {string} [options.selectorComplete] The CSS selector to find completed step elements.
   * @property {string} [options.classStep] The className for a step element.
   * @property {string} [options.classComplete] The className for a completed step element.
   * @property {string} [options.classCurrent] The className for the current step element.
   * @property {string} [options.classIncomplete] The className for a incomplete step element.
   */


  function ProgressIndicator(element, options) {
    var _this;

    _classCallCheck(this, ProgressIndicator);

    _this = _super.call(this, element, options);
    /**
     * The component state.
     * @type {object}
     */

    _this.state = {
      /**
       * The current step index.
       * @type {number}
       */
      currentIndex: _this.getCurrent().index,

      /**
       * Total number of steps.
       * @type {number}
       */
      totalSteps: _this.getSteps().length
    };

    _this.addOverflowTooltip();

    return _this;
  }
  /**
   * Returns all steps with details about element and index.
   */


  _createClass(ProgressIndicator, [{
    key: "getSteps",
    value: function getSteps() {
      return toArray(this.element.querySelectorAll(this.options.selectorStepElement)).map(function (element, index) {
        return {
          element: element,
          index: index
        };
      });
    }
    /**
     * Returns current step; gives detail about element and index.
     */

  }, {
    key: "getCurrent",
    value: function getCurrent() {
      var currentEl = this.element.querySelector(this.options.selectorCurrent);
      return this.getSteps().filter(function (step) {
        return step.element === currentEl;
      })[0];
    }
    /**
     * Sets the current step.
     * * @param {Number} new step index or use default in `this.state.currentIndex`.
     */

  }, {
    key: "setCurrent",
    value: function setCurrent() {
      var _this2 = this;

      var newCurrentStep = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.state.currentIndex;
      var changed = false;

      if (newCurrentStep !== this.state.currentIndex) {
        this.state.currentIndex = newCurrentStep;
        changed = true;
      }

      if (changed) {
        this.getSteps().forEach(function (step) {
          if (step.index < newCurrentStep) {
            _this2._updateStep({
              element: step.element,
              className: _this2.options.classComplete,
              html: _this2._getSVGComplete()
            });
          }

          if (step.index === newCurrentStep) {
            _this2._updateStep({
              element: step.element,
              className: _this2.options.classCurrent,
              html: _this2._getCurrentSVG()
            });
          }

          if (step.index > newCurrentStep) {
            _this2._updateStep({
              element: step.element,
              className: _this2.options.classIncomplete,
              html: _this2._getIncompleteSVG()
            });
          }
        });
      }
    }
    /**
     * Update step with correct inline SVG and className
     * @param {object} args
     * @param {object} [args.element] target element
     * @param {object} [args.className] new className
     * @param {object} [args.html] new inline SVG to insert
     */

  }, {
    key: "_updateStep",
    value: function _updateStep(args) {
      var element = args.element,
          className = args.className,
          html = args.html;

      if (element.firstElementChild) {
        element.removeChild(element.firstElementChild);
      }

      if (!element.classList.contains(className)) {
        element.setAttribute('class', this.options.classStep);
        element.classList.add(className);
      }

      element.insertAdjacentHTML('afterbegin', html);
    }
    /**
     * Returns HTML string for an SVG used to represent a compelted step (checkmark)
     */

  }, {
    key: "_getSVGComplete",
    value: function _getSVGComplete() {
      return "<svg width=\"24px\" height=\"24px\" viewBox=\"0 0 24 24\">\n        <circle cx=\"12\" cy=\"12\" r=\"12\"></circle>\n        <polygon points=\"10.3 13.6 7.7 11 6.3 12.4 10.3 16.4 17.8 9 16.4 7.6\"></polygon>\n      </svg>";
    }
    /**
     * Returns HTML string for an SVG used to represent current step (circles, like a radio button, but not.)
     */

  }, {
    key: "_getCurrentSVG",
    value: function _getCurrentSVG() {
      return "<svg>\n        <circle cx=\"12\" cy=\"12\" r=\"12\"></circle>\n        <circle cx=\"12\" cy=\"12\" r=\"6\"></circle>\n      </svg>";
    }
    /**
     * Returns HTML string for an SVG used to represent incomple step (grey empty circle)
     */

  }, {
    key: "_getIncompleteSVG",
    value: function _getIncompleteSVG() {
      return "<svg>\n        <circle cx=\"12\" cy=\"12\" r=\"12\"></circle>\n      </svg>";
    }
  }, {
    key: "addOverflowTooltip",
    value: function addOverflowTooltip() {
      var _this3 = this;

      var stepLabels = toArray(this.element.querySelectorAll(this.options.selectorLabel));
      var tooltips = toArray(this.element.querySelectorAll(this.options.selectorTooltip));
      stepLabels.forEach(function (step) {
        if (step.scrollWidth > _this3.options.maxWidth) {
          step.classList.add(_this3.options.classOverflowLabel);
        }
      });
      tooltips.forEach(function (tooltip) {
        var childText = tooltip.querySelector(_this3.options.selectorTooltipText);

        if (childText.scrollHeight > _this3.options.tooltipMaxHeight) {
          tooltip.classList.add(_this3.options.classTooltipMulti);
        }
      });
    }
  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor,
     * {@linkcode ProgressIndicator.create .create()}, or {@linkcode ProgressIndicator.init .init()},
     * properties in this object are overriden for the instance being created.
     * @member ProgressIndicator.options
     * @type {object}
     * @property {string} selectorInit The CSS selector to find content switcher button set.
     * @property {string} [selectorStepElement] The CSS selector to find step elements.
     * @property {string} [selectorCurrent] The CSS selector to find the current step element.
     * @property {string} [selectorIncomplete] The CSS class to find incomplete step elements.
     * @property {string} [selectorComplete] The CSS selector to find completed step elements.
     * @property {string} [classStep] The className for a step element.
     * @property {string} [classComplete] The className for a completed step element.
     * @property {string} [classCurrent] The className for the current step element.
     * @property {string} [classIncomplete] The className for a incomplete step element.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-progress]',
        selectorStepElement: ".".concat(prefix, "--progress-step"),
        selectorCurrent: ".".concat(prefix, "--progress-step--current"),
        selectorIncomplete: ".".concat(prefix, "--progress-step--incomplete"),
        selectorComplete: ".".concat(prefix, "--progress-step--complete"),
        selectorLabel: ".".concat(prefix, "--progress-label"),
        selectorTooltip: ".".concat(prefix, "--tooltip"),
        selectorTooltipText: ".".concat(prefix, "--tooltip__text"),
        classStep: "".concat(prefix, "--progress-step"),
        classComplete: "".concat(prefix, "--progress-step--complete"),
        classCurrent: "".concat(prefix, "--progress-step--current"),
        classIncomplete: "".concat(prefix, "--progress-step--incomplete"),
        classOverflowLabel: "".concat(prefix, "--progress-label-overflow"),
        classTooltipMulti: "".concat(prefix, "--tooltip_multi"),
        maxWidth: 87,
        tooltipMaxHeight: 21
      };
    }
  }]);

  ProgressIndicator.components = new WeakMap();
  return ProgressIndicator;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (ProgressIndicator);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/search/search.js":
/*!***********************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/search/search.js ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
/* harmony import */ var _globals_js_misc_svg_toggle_class__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../globals/js/misc/svg-toggle-class */ "./node_modules/carbon-components/es/globals/js/misc/svg-toggle-class.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */











var toArray = function toArray(arrayLike) {
  return Array.prototype.slice.call(arrayLike);
};

var Search = /*#__PURE__*/function (_mixin) {
  _inherits(Search, _mixin);

  var _super = _createSuper(Search);
  /**
   * Search with Options.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as the search component.
   * @param {object} [options] The component options
   * @property {string} [options.selectorInit]
   *   The selector to find search UIs with options.
   * @property {string} [options.selectorSearchView]
   *   The selector to find the search view icon containers.
   * @property {string} [options.selectorSearchInput]
   *   The selector to find the search input.
   * @property {string} [options.selectorClearIcon]
   *   The selector for the clear icon that clears the search box.
   * @property {string} [options.selectorIconContainer] The data attribute selector for the icon layout container.
   * @property {string} [options.classClearHidden] The class used to hide the clear icon.
   * @property {string} [options.classLayoutHidden] The class used to hide nonselected layout view.
   */


  function Search(element, options) {
    var _this;

    _classCallCheck(this, Search);

    _this = _super.call(this, element, options);

    var closeIcon = _this.element.querySelector(_this.options.selectorClearIcon);

    var input = _this.element.querySelector(_this.options.selectorSearchInput);

    if (!input) {
      throw new Error('Cannot find the search input.');
    }

    if (closeIcon) {
      _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(closeIcon, 'click', function () {
        Object(_globals_js_misc_svg_toggle_class__WEBPACK_IMPORTED_MODULE_7__["default"])(closeIcon, _this.options.classClearHidden, true);
        input.value = '';
        input.focus();
      }));
    }

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element, 'click', function (evt) {
      var toggleItem = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__["default"])(evt, _this.options.selectorIconContainer);
      if (toggleItem) _this.toggleLayout(toggleItem);
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(input, 'input', function (evt) {
      if (closeIcon) _this.showClear(evt.target.value, closeIcon);
    }));

    return _this;
  }
  /**
   * Toggles between the grid and list layout.
   * @param {HTMLElement} element The element contining the layout toggle.
   */


  _createClass(Search, [{
    key: "toggleLayout",
    value: function toggleLayout(element) {
      var _this2 = this;

      toArray(element.querySelectorAll(this.options.selectorSearchView)).forEach(function (item) {
        item.classList.toggle(_this2.options.classLayoutHidden);
      });
    }
    /**
     * Toggles the clear icon visibility
     * @param {HTMLElement} value The element serving as the search input.
     * @param {HTMLElement} icon The element serving as close icon.
     */

  }, {
    key: "showClear",
    value: function showClear(value, icon) {
      Object(_globals_js_misc_svg_toggle_class__WEBPACK_IMPORTED_MODULE_7__["default"])(icon, this.options.classClearHidden, value.length === 0);
    }
    /**
     * The component options.
     * If `options` is specified in the constructor,
     * {@linkcode Search.create .create()}, or {@linkcode Search.init .init()},
     * properties in this object are overriden for the instance being created
     * and how {@linkcode Search.init .init()} works.
     * @member Search.options
     * @type {object}
     * @property {string} [options.selectorInit]
     *   The selector to find search UIs with options.
     * @property {string} [options.selectorSearchView]
     *   The selector to find the search view icon containers.
     * @property {string} [options.selectorSearchInput]
     *   The selector to find the search input.
     * @property {string} [options.selectorClearIcon]
     *   The selector for the clear icon that clears the search box.
     * @property {string} [options.selectorIconContainer] The data attribute selector for the icon layout container.
     * @property {string} [options.classClearHidden] The class used to hide the clear icon.
     * @property {string} [options.classLayoutHidden] The class used to hide nonselected layout view.
     */

  }], [{
    key: "options",
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-search]',
        selectorSearchView: '[data-search-view]',
        selectorSearchInput: ".".concat(prefix, "--search-input"),
        selectorClearIcon: ".".concat(prefix, "--search-close"),
        selectorIconContainer: ".".concat(prefix, "--search-button[data-search-toggle]"),
        classClearHidden: "".concat(prefix, "--search-close--hidden"),
        classLayoutHidden: "".concat(prefix, "--search-view--hidden")
      };
    }
    /**
     * The map associating DOM element and search instance.
     * @member Search.components
     * @type {WeakMap}
     */

  }]);

  Search.components = new WeakMap();
  return Search;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (Search);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/slider/slider.js":
/*!***********************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/slider/slider.js ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_evented_state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/evented-state */ "./node_modules/carbon-components/es/globals/js/mixins/evented-state.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */










var Slider = /*#__PURE__*/function (_mixin) {
  _inherits(Slider, _mixin);

  var _super = _createSuper(Slider);
  /**
   * Slider.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as an slider.
   */


  function Slider(element, options) {
    var _this;

    _classCallCheck(this, Slider);

    _this = _super.call(this, element, options);

    _this._changeState = function (state, detail, callback) {
      callback();
    };

    _this.sliderActive = false;
    _this.dragging = false;
    _this.track = _this.element.querySelector(_this.options.selectorTrack);
    _this.filledTrack = _this.element.querySelector(_this.options.selectorFilledTrack);
    _this.thumb = _this.element.querySelector(_this.options.selectorThumb);
    _this.input = _this.element.querySelector(_this.options.selectorInput);

    if (_this.element.dataset.sliderInputBox) {
      _this.boundInput = _this.element.ownerDocument.querySelector(_this.element.dataset.sliderInputBox);

      _this._updateInput();

      _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.boundInput, 'change', function (evt) {
        _this.setValue(evt.target.value);
      }));

      _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.boundInput, 'focus', function (evt) {
        evt.target.select();
      })); // workaround for safari


      _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.boundInput, 'mouseup', function (evt) {
        evt.preventDefault();
      }));
    }

    _this._updatePosition();

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.thumb, 'mousedown', function () {
      _this.sliderActive = true;
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element.ownerDocument, 'mouseup', function () {
      _this.sliderActive = false;
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element.ownerDocument, 'mousemove', function (evt) {
      var disabled = _this.element.classList.contains(_this.options.classDisabled);

      if (_this.sliderActive === true && !disabled) {
        _this._updatePosition(evt);
      }
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.thumb, 'keydown', function (evt) {
      var disabled = _this.element.classList.contains(_this.options.classDisabled);

      if (!disabled) {
        _this._updatePosition(evt);
      }
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.track, 'click', function (evt) {
      var disabled = _this.element.classList.contains(_this.options.classDisabled);

      if (!disabled) {
        _this._updatePosition(evt);
      }
    }));

    return _this;
  }

  _createClass(Slider, [{
    key: "_updatePosition",
    value: function _updatePosition(evt) {
      var _this2 = this;

      var _this$_calcValue = this._calcValue(evt),
          left = _this$_calcValue.left,
          newValue = _this$_calcValue.newValue;

      if (this.dragging) {
        return;
      }

      this.dragging = true;
      requestAnimationFrame(function () {
        _this2.dragging = false;
        _this2.thumb.style.left = "".concat(left, "%");
        _this2.filledTrack.style.transform = "translate(0%, -50%) scaleX(".concat(left / 100, ")");
        _this2.input.value = newValue;

        _this2._updateInput();

        _this2.changeState('slider-value-change', {
          value: newValue
        });
      });
    }
  }, {
    key: "_calcValue",
    value: function _calcValue(evt) {
      var _this$getInputProps = this.getInputProps(),
          value = _this$getInputProps.value,
          min = _this$getInputProps.min,
          max = _this$getInputProps.max,
          step = _this$getInputProps.step;

      var range = max - min;
      var valuePercentage = (value - min) / range * 100;
      var left;
      var newValue;
      left = valuePercentage;
      newValue = value;

      if (evt) {
        var type = evt.type;

        if (type === 'keydown') {
          var direction = {
            40: -1,
            // decreasing
            37: -1,
            // decreasing
            38: 1,
            // increasing
            39: 1 // increasing

          }[evt.which];

          if (direction !== undefined) {
            var multiplier = evt.shiftKey === true ? range / step / this.options.stepMultiplier : 1;
            var stepMultiplied = step * multiplier;
            var stepSize = stepMultiplied / range * 100;
            left = valuePercentage + stepSize * direction;
            newValue = Number(value) + stepMultiplied * direction;
          }
        }

        if (type === 'mousemove' || type === 'click') {
          if (type === 'click') {
            this.element.querySelector(this.options.selectorThumb).classList.add(this.options.classThumbClicked);
          } else {
            this.element.querySelector(this.options.selectorThumb).classList.remove(this.options.classThumbClicked);
          }

          var track = this.track.getBoundingClientRect();
          var unrounded = (evt.clientX - track.left) / track.width;
          var rounded = Math.round(range * unrounded / step) * step;
          left = rounded / range * 100;
          newValue = rounded + min;
        }
      }

      if (newValue <= Number(min)) {
        left = 0;
        newValue = min;
      }

      if (newValue >= Number(max)) {
        left = 100;
        newValue = max;
      }

      return {
        left: left,
        newValue: newValue
      };
    }
  }, {
    key: "_updateInput",
    value: function _updateInput() {
      if (this.boundInput) {
        this.boundInput.value = this.input.value;
      }
    }
  }, {
    key: "getInputProps",
    value: function getInputProps() {
      var values = {
        value: Number(this.input.value),
        min: Number(this.input.min),
        max: Number(this.input.max),
        step: this.input.step ? Number(this.input.step) : 1
      };
      return values;
    }
  }, {
    key: "setValue",
    value: function setValue(value) {
      this.input.value = value;

      this._updatePosition();
    }
  }, {
    key: "stepUp",
    value: function stepUp() {
      this.input.stepUp();

      this._updatePosition();
    }
  }, {
    key: "stepDown",
    value: function stepDown() {
      this.input.stepDown();

      this._updatePosition();
    }
    /**
     * The map associating DOM element and Slider UI instance.
     * @type {WeakMap}
     */

  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor,
     * properties in this object are overriden for the instance being created.
     * @property {string} selectorInit The CSS selector to find slider instances.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-slider]',
        selectorTrack: ".".concat(prefix, "--slider__track"),
        selectorFilledTrack: ".".concat(prefix, "--slider__filled-track"),
        selectorThumb: ".".concat(prefix, "--slider__thumb"),
        selectorInput: ".".concat(prefix, "--slider__input"),
        classDisabled: "".concat(prefix, "--slider--disabled"),
        classThumbClicked: "".concat(prefix, "--slider__thumb--clicked"),
        eventBeforeSliderValueChange: 'slider-before-value-change',
        eventAfterSliderValueChange: 'slider-after-value-change',
        stepMultiplier: 4
      };
    }
  }]);

  Slider.components = new WeakMap();
  return Slider;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_evented_state__WEBPACK_IMPORTED_MODULE_4__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (Slider);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/structured-list/structured-list.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/structured-list/structured-list.js ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */










var toArray = function toArray(arrayLike) {
  return Array.prototype.slice.call(arrayLike);
};

var StructuredList = /*#__PURE__*/function (_mixin) {
  _inherits(StructuredList, _mixin);

  var _super = _createSuper(StructuredList);
  /**
   * StructuredList
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The root element of tables
   * @param {object} [options] the... options
   * @param {string} [options.selectorInit] selector initialization
   * @param {string} [options.selectorRow] css selector for selected row
   */


  function StructuredList(element, options) {
    var _this;

    _classCallCheck(this, StructuredList);

    _this = _super.call(this, element, options);

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element, 'keydown', function (evt) {
      if (evt.which === 37 || evt.which === 38 || evt.which === 39 || evt.which === 40) {
        _this._handleKeydownArrow(evt);
      }

      if (evt.which === 13 || evt.which === 32) {
        _this._handleKeydownChecked(evt);
      }
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element, 'click', function (evt) {
      _this._handleClick(evt);
    }));

    return _this;
  }

  _createClass(StructuredList, [{
    key: "_direction",
    value: function _direction(evt) {
      return {
        37: -1,
        // backward
        38: -1,
        // backward
        39: 1,
        // forward
        40: 1 // forward

      }[evt.which];
    }
  }, {
    key: "_nextIndex",
    value: function _nextIndex(array, arrayItem, direction) {
      return array.indexOf(arrayItem) + direction; // returns -1, 0, 1, 2, 3, 4...
    }
  }, {
    key: "_getInput",
    value: function _getInput(index) {
      var rows = toArray(this.element.querySelectorAll(this.options.selectorRow));
      return this.element.ownerDocument.querySelector(this.options.selectorListInput(rows[index].getAttribute('for')));
    }
  }, {
    key: "_handleInputChecked",
    value: function _handleInputChecked(index) {
      var rows = this.element.querySelectorAll(this.options.selectorRow);
      var input = this.getInput(index) || rows[index].querySelector('input');
      input.checked = true;
    }
  }, {
    key: "_handleClick",
    value: function _handleClick(evt) {
      var _this2 = this;

      var selectedRow = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__["default"])(evt, this.options.selectorRow);
      toArray(this.element.querySelectorAll(this.options.selectorRow)).forEach(function (row) {
        return row.classList.remove(_this2.options.classActive);
      });

      if (selectedRow) {
        selectedRow.classList.add(this.options.classActive);
      }
    } // Handle Enter or Space keydown events for selecting <label> rows

  }, {
    key: "_handleKeydownChecked",
    value: function _handleKeydownChecked(evt) {
      var _this3 = this;

      evt.preventDefault(); // prevent spacebar from scrolling page

      var selectedRow = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__["default"])(evt, this.options.selectorRow);
      toArray(this.element.querySelectorAll(this.options.selectorRow)).forEach(function (row) {
        return row.classList.remove(_this3.options.classActive);
      });

      if (selectedRow) {
        selectedRow.classList.add(this.options.classActive);
        var input = selectedRow.querySelector(this.options.selectorListInput(selectedRow.getAttribute('for'))) || selectedRow.querySelector('input');
        input.checked = true;
      }
    } // Handle up and down keydown events for selecting <label> rows

  }, {
    key: "_handleKeydownArrow",
    value: function _handleKeydownArrow(evt) {
      var _this4 = this;

      evt.preventDefault(); // prevent arrow keys from scrolling

      var selectedRow = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__["default"])(evt, this.options.selectorRow);

      var direction = this._direction(evt);

      if (direction && selectedRow !== undefined) {
        var rows = toArray(this.element.querySelectorAll(this.options.selectorRow));
        rows.forEach(function (row) {
          return row.classList.remove(_this4.options.classActive);
        });
        var firstIndex = 0;

        var nextIndex = this._nextIndex(rows, selectedRow, direction);

        var lastIndex = rows.length - 1;

        var getSelectedIndex = function getSelectedIndex() {
          switch (nextIndex) {
            case -1:
              return lastIndex;

            case rows.length:
              return firstIndex;

            default:
              return nextIndex;
          }
        };

        var selectedIndex = getSelectedIndex();
        rows[selectedIndex].classList.add(this.options.classActive);
        rows[selectedIndex].focus();

        this._handleInputChecked(selectedIndex);
      }
    }
  }], [{
    key: "options",
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-structured-list]',
        selectorRow: "[data-structured-list] .".concat(prefix, "--structured-list-tbody > label.").concat(prefix, "--structured-list-row"),
        selectorListInput: function selectorListInput(id) {
          return "#".concat(id, ".").concat(prefix, "--structured-list-input");
        },
        classActive: "".concat(prefix, "--structured-list-row--selected")
      };
    }
  }]);

  StructuredList.components = new WeakMap();
  return StructuredList;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (StructuredList);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/tabs/tabs.js":
/*!*******************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/tabs/tabs.js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _content_switcher_content_switcher__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../content-switcher/content-switcher */ "./node_modules/carbon-components/es/components/content-switcher/content-switcher.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _get(target, property, receiver) {
  if (typeof Reflect !== "undefined" && Reflect.get) {
    _get = Reflect.get;
  } else {
    _get = function _get(target, property, receiver) {
      var base = _superPropBase(target, property);

      if (!base) return;
      var desc = Object.getOwnPropertyDescriptor(base, property);

      if (desc.get) {
        return desc.get.call(receiver);
      }

      return desc.value;
    };
  }

  return _get(target, property, receiver || target);
}

function _superPropBase(object, property) {
  while (!Object.prototype.hasOwnProperty.call(object, property)) {
    object = _getPrototypeOf(object);
    if (object === null) break;
  }

  return object;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */







var toArray = function toArray(arrayLike) {
  return Array.prototype.slice.call(arrayLike);
};

var Tab = /*#__PURE__*/function (_ContentSwitcher) {
  _inherits(Tab, _ContentSwitcher);

  var _super = _createSuper(Tab);
  /**
   * Container of tabs.
   * @extends ContentSwitcher
   * @param {HTMLElement} element The element working as a container of tabs.
   * @param {object} [options] The component options.
   * @param {string} [options.selectorMenu] The CSS selector to find the drop down menu used in narrow mode.
   * @param {string} [options.selectorTrigger] The CSS selector to find the button to open the drop down menu used in narrow mode.
   * @param {string} [options.selectorTriggerText]
   *   The CSS selector to find the element used in narrow mode showing the selected tab item.
   * @param {string} [options.selectorButton] The CSS selector to find tab containers.
   * @param {string} [options.selectorButtonSelected] The CSS selector to find the selected tab.
   * @param {string} [options.selectorLink] The CSS selector to find the links in tabs.
   * @param {string} [options.classActive] The CSS class for tab's selected state.
   * @param {string} [options.classHidden] The CSS class for the drop down menu's hidden state used in narrow mode.
   * @param {string} [options.eventBeforeSelected]
   *   The name of the custom event fired before a tab is selected.
   *   Cancellation of this event stops selection of tab.
   * @param {string} [options.eventAfterSelected] The name of the custom event fired after a tab is selected.
   */


  function Tab(element, options) {
    var _this;

    _classCallCheck(this, Tab);

    _this = _super.call(this, element, options);

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_3__["default"])(_this.element, 'keydown', function (event) {
      _this._handleKeyDown(event);
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_3__["default"])(_this.element.ownerDocument, 'click', function (event) {
      _this._handleDocumentClick(event);
    }));

    var selected = _this.element.querySelector(_this.options.selectorButtonSelected);

    if (selected) {
      _this._updateTriggerText(selected);
    }

    return _this;
  }
  /**
   * Internal method of {@linkcode Tab#setActive .setActive()}, to select a tab item.
   * @private
   * @param {object} detail The detail of the event trigging this action.
   * @param {HTMLElement} detail.item The tab item to be selected.
   * @param {Function} callback Callback called when change in state completes.
   */


  _createClass(Tab, [{
    key: "_changeState",
    value: function _changeState(detail, callback) {
      var _this2 = this;

      _get(_getPrototypeOf(Tab.prototype), "_changeState", this).call(this, detail, function (error) {
        if (!error) {
          _this2._updateTriggerText(detail.item);
        }

        for (var _len = arguments.length, data = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
          data[_key - 1] = arguments[_key];
        }

        callback.apply(void 0, [error].concat(data));
      });
    }
    /**
     * Handles click on tab container.
     * * If the click is on a tab, activates it.
     * * If the click is on the button to open the drop down menu, does so.
     * @param {Event} event The event triggering this method.
     */

  }, {
    key: "_handleClick",
    value: function _handleClick(event) {
      var button = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_1__["default"])(event, this.options.selectorButton);
      var trigger = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_1__["default"])(event, this.options.selectorTrigger);

      if (button && !button.classList.contains(this.options.classButtonDisabled)) {
        _get(_getPrototypeOf(Tab.prototype), "_handleClick", this).call(this, event);

        this._updateMenuState(false);
      }

      if (trigger) {
        this._updateMenuState();
      }
    }
    /**
     * Handles click on document.
     * @param {Event} event The triggering event.
     * @private
     */

  }, {
    key: "_handleDocumentClick",
    value: function _handleDocumentClick(event) {
      var element = this.element;
      var isOfSelf = element.contains(event.target);

      if (isOfSelf) {
        return;
      }

      this._updateMenuState(false);
    }
    /**
     * Handles arrow keys on tab container.
     * * Left keys are used to go to previous tab.
     * * Right keys are used to go to next tab.
     * @param {Event} event The event triggering this method.
     */

  }, {
    key: "_handleKeyDown",
    value: function _handleKeyDown(event) {
      var _this3 = this;

      var triggerNode = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_1__["default"])(event, this.options.selectorTrigger);

      if (triggerNode) {
        if (event.which === 13) {
          this._updateMenuState();
        }

        return;
      }

      var direction = {
        37: this.constructor.NAVIGATE.BACKWARD,
        39: this.constructor.NAVIGATE.FORWARD
      }[event.which];

      if (direction) {
        var buttons = toArray(this.element.querySelectorAll(this.options.selectorButtonEnabled));
        var button = this.element.querySelector(this.options.selectorButtonSelected);
        var nextIndex = Math.max(buttons.indexOf(button) + direction, -1
        /* For `button` not found in `buttons` */
        );
        var nextIndexLooped = nextIndex >= 0 && nextIndex < buttons.length ? nextIndex : nextIndex - Math.sign(nextIndex) * buttons.length;
        this.setActive(buttons[nextIndexLooped], function (error, item) {
          if (item) {
            var link = item.querySelector(_this3.options.selectorLink);

            if (link) {
              link.focus();
            }
          }
        });
        event.preventDefault();
      }
    }
    /**
     * Shows/hides the drop down menu used in narrow mode.
     * @param {boolean} [force] `true` to show the menu, `false` to hide the menu, otherwise toggles the menu.
     */

  }, {
    key: "_updateMenuState",
    value: function _updateMenuState(force) {
      var menu = this.element.querySelector(this.options.selectorMenu);
      var trigger = this.element.querySelector(this.options.selectorTrigger);

      if (menu) {
        menu.classList.toggle(this.options.classHidden, typeof force === 'undefined' ? force : !force);

        if (menu.classList.contains(this.options.classHidden)) {
          trigger.classList.remove(this.options.classOpen);
        } else {
          trigger.classList.add(this.options.classOpen);
        }
      }
    }
    /**
     * Updates the text indicating the currently selected tab item.
     * @param {HTMLElement} target The newly selected tab item.
     */

  }, {
    key: "_updateTriggerText",
    value: function _updateTriggerText(target) {
      var triggerText = this.element.querySelector(this.options.selectorTriggerText);

      if (triggerText) {
        triggerText.textContent = target.textContent;
      }
    }
    /**
     * The map associating DOM element and tab container instance.
     * @member Tab.components
     * @type {WeakMap}
     */

  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor, {@linkcode ContentSwitcher.create .create()}, or {@linkcode Tab.init .init()},
     * properties in this object are overriden for the instance being create and how {@linkcode Tab.init .init()} works.
     * @member Tab.options
     * @type {object}
     * @property {string} selectorInit The CSS selector to find tab containers.
     * @property {string} [selectorMenu] The CSS selector to find the drop down menu used in narrow mode.
     * @property {string} [selectorTrigger] The CSS selector to find the button to open the drop down menu used in narrow mode.
     * @property {string} [selectorTriggerText]
     *   The CSS selector to find the element used in narrow mode showing the selected tab item.
     * @property {string} [selectorButton] The CSS selector to find tab containers.
     * @property {string} [selectorButtonSelected] The CSS selector to find the selected tab.
     * @property {string} [selectorLink] The CSS selector to find the links in tabs.
     * @property {string} [classActive] The CSS class for tab's selected state.
     * @property {string} [classHidden] The CSS class for the drop down menu's hidden state used in narrow mode.
     * @property {string} [eventBeforeSelected]
     *   The name of the custom event fired before a tab is selected.
     *   Cancellation of this event stops selection of tab.
     * @property {string} [eventAfterSelected] The name of the custom event fired after a tab is selected.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return Object.assign(Object.create(_content_switcher_content_switcher__WEBPACK_IMPORTED_MODULE_2__["default"].options), {
        selectorInit: '[data-tabs]',
        selectorMenu: ".".concat(prefix, "--tabs__nav"),
        selectorTrigger: ".".concat(prefix, "--tabs-trigger"),
        selectorTriggerText: ".".concat(prefix, "--tabs-trigger-text"),
        selectorButton: ".".concat(prefix, "--tabs__nav-item"),
        selectorButtonEnabled: ".".concat(prefix, "--tabs__nav-item:not(.").concat(prefix, "--tabs__nav-item--disabled)"),
        selectorButtonSelected: ".".concat(prefix, "--tabs__nav-item--selected"),
        selectorLink: ".".concat(prefix, "--tabs__nav-link"),
        classActive: "".concat(prefix, "--tabs__nav-item--selected"),
        classHidden: "".concat(prefix, "--tabs__nav--hidden"),
        classOpen: "".concat(prefix, "--tabs-trigger--open"),
        classButtonDisabled: "".concat(prefix, "--tabs__nav-item--disabled"),
        eventBeforeSelected: 'tab-beingselected',
        eventAfterSelected: 'tab-selected'
      });
    }
    /**
     * Enum for navigating backward/forward.
     * @readonly
     * @member Tab.NAVIGATE
     * @type {object}
     * @property {number} BACKWARD Navigating backward.
     * @property {number} FORWARD Navigating forward.
     */

  }]);

  Tab.components = new WeakMap();
  Tab.NAVIGATE = {
    BACKWARD: -1,
    FORWARD: 1
  };
  return Tab;
}(_content_switcher_content_switcher__WEBPACK_IMPORTED_MODULE_2__["default"]);

/* harmony default export */ __webpack_exports__["default"] = (Tab);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/text-input/text-input.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/text-input/text-input.js ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TextInput; });
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */










var TextInput = /*#__PURE__*/function (_mixin) {
  _inherits(TextInput, _mixin);

  var _super = _createSuper(TextInput);
  /**
   * Text Input.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element - The element functioning as a text field.
   */


  function TextInput(_element, options) {
    var _this;

    _classCallCheck(this, TextInput);

    _this = _super.call(this, _element, options);

    _this._setIconVisibility = function (_ref) {
      var iconVisibilityOn = _ref.iconVisibilityOn,
          iconVisibilityOff = _ref.iconVisibilityOff,
          passwordIsVisible = _ref.passwordIsVisible,
          selectorPasswordVisibilityTooltip = _ref.selectorPasswordVisibilityTooltip;

      if (passwordIsVisible) {
        iconVisibilityOn.setAttribute('hidden', true);
        iconVisibilityOff.removeAttribute('hidden');
        selectorPasswordVisibilityTooltip.textContent = 'Hide password';
        return;
      }

      iconVisibilityOn.removeAttribute('hidden');
      iconVisibilityOff.setAttribute('hidden', true);
      selectorPasswordVisibilityTooltip.textContent = 'Show password';
    };

    _this._toggle = function (_ref2) {
      var element = _ref2.element,
          button = _ref2.button; // toggle action must come before querying the classList

      element.classList.toggle(_this.options.passwordIsVisible);
      var passwordIsVisible = element.classList.contains(_this.options.passwordIsVisible);
      var iconVisibilityOn = button.querySelector(_this.options.svgIconVisibilityOn);
      var iconVisibilityOff = button.querySelector(_this.options.svgIconVisibilityOff);
      var input = element.querySelector(_this.options.selectorPasswordField);
      var selectorPasswordVisibilityTooltip = element.querySelector(_this.options.selectorPasswordVisibilityTooltip);

      _this._setIconVisibility({
        iconVisibilityOn: iconVisibilityOn,
        iconVisibilityOff: iconVisibilityOff,
        passwordIsVisible: passwordIsVisible,
        selectorPasswordVisibilityTooltip: selectorPasswordVisibilityTooltip
      });

      input.type = passwordIsVisible ? 'text' : 'password';
    };

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element, 'click', function (event) {
      var toggleVisibilityButton = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__["default"])(event, _this.options.selectorPasswordVisibilityButton);

      if (toggleVisibilityButton) {
        _this._toggle({
          element: _element,
          button: toggleVisibilityButton
        });
      }
    }));

    return _this;
  }
  /**
   *
   * @param {object} obj - Object containing selectors and visibility status
   * @param {HTMLElement} obj.iconVisibilityOn - The element functioning as
   * the SVG icon for visibility on
   * @param {HTMLElement} obj.iconVisibilityOff - The element functioning as
   * the SVG icon for visibility off
   * @param {boolean} obj.passwordIsVisible - The visibility of the password in the
   * input field
   */


  _createClass(TextInput, null, [{
    key: "options",

    /**
     * The component options.
     *
     * If `options` is specified in the constructor,
     * {@linkcode TextInput.create .create()},
     * or {@linkcode TextInput.init .init()},
     * properties in this object are overriden for the instance being
     * created and how {@linkcode TextInput.init .init()} works.
     * @property {string} selectorInit The CSS selector to find text input UIs.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-text-input]',
        selectorPasswordField: ".".concat(prefix, "--text-input[data-toggle-password-visibility]"),
        selectorPasswordVisibilityButton: ".".concat(prefix, "--text-input--password__visibility__toggle"),
        selectorPasswordVisibilityTooltip: ".".concat(prefix, "--text-input--password__visibility__toggle > .").concat(prefix, "--assistive-text"),
        passwordIsVisible: "".concat(prefix, "--text-input--password-visible"),
        svgIconVisibilityOn: "svg.".concat(prefix, "--icon--visibility-on"),
        svgIconVisibilityOff: "svg.".concat(prefix, "--icon--visibility-off")
      };
    }
    /**
     * The map associating DOM element and text input UI instance.
     * @type {WeakMap}
     */

  }]);

  TextInput.components = new WeakMap();
  return TextInput;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"]));



/***/ }),

/***/ "./node_modules/carbon-components/es/components/tile/tile.js":
/*!*******************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/tile/tile.js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _get(target, property, receiver) {
  if (typeof Reflect !== "undefined" && Reflect.get) {
    _get = Reflect.get;
  } else {
    _get = function _get(target, property, receiver) {
      var base = _superPropBase(target, property);

      if (!base) return;
      var desc = Object.getOwnPropertyDescriptor(base, property);

      if (desc.get) {
        return desc.get.call(receiver);
      }

      return desc.value;
    };
  }

  return _get(target, property, receiver || target);
}

function _superPropBase(object, property) {
  while (!Object.prototype.hasOwnProperty.call(object, property)) {
    object = _getPrototypeOf(object);
    if (object === null) break;
  }

  return object;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */








var Tile = /*#__PURE__*/function (_mixin) {
  _inherits(Tile, _mixin);

  var _super = _createSuper(Tile);
  /**
   * Tile.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @param {HTMLElement} element The element working as an Tile.
   */


  function Tile(element, options) {
    var _this;

    _classCallCheck(this, Tile);

    _this = _super.call(this, element, options);

    _this._getClass = function (type) {
      var typeObj = {
        expandable: _this.options.classExpandedTile,
        clickable: _this.options.classClickableTile,
        selectable: _this.options.classSelectableTile
      };
      return typeObj[type];
    };

    _this._hookActions = function (tileClass) {
      var isExpandable = _this.tileType === 'expandable';

      if (isExpandable) {
        var aboveTheFold = _this.element.querySelector(_this.options.selectorAboveTheFold);

        var getStyle = _this.element.ownerDocument.defaultView.getComputedStyle(_this.element, null);

        var tilePaddingTop = parseInt(getStyle.getPropertyValue('padding-top'), 10);
        var tilePaddingBottom = parseInt(getStyle.getPropertyValue('padding-bottom'), 10);
        var tilePadding = tilePaddingTop + tilePaddingBottom;

        if (aboveTheFold) {
          _this.tileHeight = _this.element.getBoundingClientRect().height;
          _this.atfHeight = aboveTheFold.getBoundingClientRect().height + tilePadding;
          _this.element.style.maxHeight = "".concat(_this.atfHeight, "px");
        }

        if (_this.element.classList.contains(_this.options.classExpandedTile)) {
          _this._setTileHeight();
        }
      }

      _this.element.addEventListener('click', function (evt) {
        var input = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_4__["default"])(evt, _this.options.selectorTileInput);

        if (!input) {
          _this.element.classList.toggle(tileClass);
        }

        if (isExpandable) {
          _this._setTileHeight();
        }
      });

      _this.element.addEventListener('keydown', function (evt) {
        var input = _this.element.querySelector(_this.options.selectorTileInput);

        if (input) {
          if (evt.which === 13 || evt.which === 32) {
            if (!isExpandable) {
              _this.element.classList.toggle(tileClass);

              input.checked = !input.checked;
            }
          }
        }
      });
    };

    _this._setTileHeight = function () {
      var isExpanded = _this.element.classList.contains(_this.options.classExpandedTile);

      _this.element.style.maxHeight = isExpanded ? "".concat(_this.tileHeight, "px") : "".concat(_this.atfHeight, "px");
    };

    _this.tileType = _this.element.dataset.tile;
    _this.tileHeight = 0; // Tracks expandable tile height

    _this.atfHeight = 0; // Tracks above the fold height

    _this._hookActions(_this._getClass(_this.tileType));

    return _this;
  }

  _createClass(Tile, [{
    key: "release",
    value: function release() {
      _get(_getPrototypeOf(Tile.prototype), "release", this).call(this);
    }
    /**
     * The map associating DOM element and Tile UI instance.
     * @type {WeakMap}
     */

  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor,
     * properties in this object are overriden for the instance being created.
     * @property {string} selectorInit The CSS selector to find Tile instances.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-tile]',
        selectorAboveTheFold: '[data-tile-atf]',
        selectorTileInput: '[data-tile-input]',
        classExpandedTile: "".concat(prefix, "--tile--is-expanded"),
        classClickableTile: "".concat(prefix, "--tile--is-clicked"),
        classSelectableTile: "".concat(prefix, "--tile--is-selected")
      };
    }
  }]);

  Tile.components = new WeakMap();
  return Tile;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (Tile);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/toolbar/toolbar.js":
/*!*************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/toolbar/toolbar.js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */










var toArray = function toArray(arrayLike) {
  return Array.prototype.slice.call(arrayLike);
};

var Toolbar = /*#__PURE__*/function (_mixin) {
  _inherits(Toolbar, _mixin);

  var _super = _createSuper(Toolbar);
  /**
   * Toolbar.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as an toolbar.
   */


  function Toolbar(element, options) {
    var _this;

    _classCallCheck(this, Toolbar);

    _this = _super.call(this, element, options);

    if (!_this.element.dataset.tableTarget) {
      console.warn('There is no table bound to this toolbar!'); // eslint-disable-line no-console
    } else {
      var boundTable = _this.element.ownerDocument.querySelector(_this.element.dataset.tableTarget);

      var rowHeightBtns = _this.element.querySelector(_this.options.selectorRowHeight);

      if (rowHeightBtns) {
        _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(rowHeightBtns, 'click', function (event) {
          _this._handleRowHeightChange(event, boundTable);
        })); // toArray(this.element.querySelectorAll(this.options.selectorRowHeight)).forEach((item) => {
        //   item.addEventListener('click', (event) => { this._handleRowHeightChange(event, boundTable); });
        // });

      }
    }

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element.ownerDocument, 'keydown', function (evt) {
      _this._handleKeyDown(evt);
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element.ownerDocument, 'click', function (evt) {
      _this._handleDocumentClick(evt);
    }));

    return _this;
  }
  /**
   * Handles toggling of active state of the toolbar search input
   * @param {Event} event The event triggering this method.
   */


  _createClass(Toolbar, [{
    key: "_handleDocumentClick",
    value: function _handleDocumentClick(event) {
      var _this2 = this;

      var searchInput = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__["default"])(event, this.options.selectorSearch);
      var isOfSelfSearchInput = searchInput && this.element.contains(searchInput);

      if (isOfSelfSearchInput) {
        var shouldBeOpen = isOfSelfSearchInput && !this.element.classList.contains(this.options.classSearchActive);
        searchInput.classList.toggle(this.options.classSearchActive, shouldBeOpen);

        if (shouldBeOpen) {
          searchInput.querySelector('input').focus();
        }
      }

      var targetComponentElement = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__["default"])(event, this.options.selectorInit);
      toArray(this.element.ownerDocument.querySelectorAll(this.options.selectorSearch)).forEach(function (item) {
        if (!targetComponentElement || !targetComponentElement.contains(item)) {
          item.classList.remove(_this2.options.classSearchActive);
        }
      });
    }
    /**
     * Handles toggling of active state of the toolbar search input via the keyboard
     * @param {Event} event The event triggering this method.
     */

  }, {
    key: "_handleKeyDown",
    value: function _handleKeyDown(event) {
      var searchInput = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_5__["default"])(event, this.options.selectorSearch);

      if (searchInput && event.which === 27) {
        searchInput.classList.remove(this.options.classSearchActive);
      }
    }
    /**
     * Handles toggling of the row height of the associated table
     * @param {Event} event The event triggering this method.
     * @param {HTMLElement} boundTable The table associated with the toolbar.
     */

  }, {
    key: "_handleRowHeightChange",
    value: function _handleRowHeightChange(event, boundTable) {
      var _event$currentTarget$ = event.currentTarget.querySelector('input:checked'),
          value = _event$currentTarget$.value;

      if (value === 'tall') {
        boundTable.classList.add(this.options.classTallRows);
      } else {
        boundTable.classList.remove(this.options.classTallRows);
      }
    }
    /**
     * The map associating DOM element and Toolbar UI instance.
     * @type {WeakMap}
     */

  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor,
     * properties in this object are overriden for the instance being created.
     * @property {string} selectorInit The CSS selector to find toolbar instances.
     * @property {string} selectorSearch The CSS selector to find search inputs in a toolbar.
     * @property {string} selectorRowHeight The CSS selector to find the row height inputs in a toolbar.
     * @property {string} classTallRows The CSS class for making table rows into tall rows.
     * @property {string} classSearchActive The CSS class the active state of the search input.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-toolbar]',
        selectorSearch: '[data-toolbar-search]',
        selectorRowHeight: '[data-row-height]',
        classTallRows: "".concat(prefix, "--responsive-table--tall"),
        classSearchActive: "".concat(prefix, "--toolbar-search--active")
      };
    }
  }]);

  Toolbar.components = new WeakMap();
  return Toolbar;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (Toolbar);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/tooltip/tooltip--simple.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/tooltip/tooltip--simple.js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return TooltipSimple; });
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash.debounce */ "./node_modules/lodash.debounce/index.js");
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */











var TooltipSimple = /*#__PURE__*/function (_mixin) {
  _inherits(TooltipSimple, _mixin);

  var _super = _createSuper(TooltipSimple);
  /**
   * Simple Tooltip.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element - The element functioning as a text field.
   */


  function TooltipSimple(element, options) {
    var _this;

    _classCallCheck(this, TooltipSimple);

    _this = _super.call(this, element, options);
    _this.tooltipFadeOut = lodash_debounce__WEBPACK_IMPORTED_MODULE_0___default()(function () {
      var tooltipTriggerButton = _this.getTooltipTriggerButton();

      if (tooltipTriggerButton) {
        tooltipTriggerButton.classList.remove(_this.options.classTooltipVisible);
      }
    }, 100);

    _this.getTooltipTriggerButton = function () {
      return _this.element.matches(_this.options.selectorTriggerButton) ? _this.element : _this.element.querySelector(_this.options.selectorTriggerButton);
    };

    _this.allowTooltipVisibility = function (_ref) {
      var visible = _ref.visible;

      var tooltipTriggerButton = _this.getTooltipTriggerButton();

      if (!tooltipTriggerButton) {
        return;
      }

      if (visible) {
        tooltipTriggerButton.classList.remove(_this.options.classTooltipHidden);
      } else {
        tooltipTriggerButton.classList.add(_this.options.classTooltipHidden);
      }
    };

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.element.ownerDocument, 'keydown', function (event) {
      // ESC
      if (event.which === 27) {
        _this.allowTooltipVisibility({
          visible: false
        });

        var tooltipTriggerButton = _this.getTooltipTriggerButton();

        if (tooltipTriggerButton) {
          tooltipTriggerButton.classList.remove(_this.options.classTooltipVisible);
        }
      }
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.element, 'mouseenter', function () {
      _this.tooltipFadeOut.cancel();

      _this.allowTooltipVisibility({
        visible: true
      });

      var tooltipTriggerButton = _this.getTooltipTriggerButton();

      if (tooltipTriggerButton) {
        tooltipTriggerButton.classList.add(_this.options.classTooltipVisible);
      }
    }));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.element, 'mouseleave', _this.tooltipFadeOut));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_7__["default"])(_this.element, 'focusin', function (event) {
      if (Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__["default"])(event, _this.options.selectorTriggerButton)) {
        _this.allowTooltipVisibility({
          visible: true
        });
      }
    }));

    return _this;
  }

  _createClass(TooltipSimple, null, [{
    key: "options",

    /**
     * The component options.
     *
     * If `options` is specified in the constructor,
     * {@linkcode TooltipSimple.create .create()},
     * or {@linkcode TooltipSimple.init .init()},
     * properties in this object are overriden for the instance being
     * created and how {@linkcode TooltipSimple.init .init()} works.
     * @property {string} selectorInit The CSS selector to find simple tooltip UIs.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_1__["default"].prefix;
      return {
        selectorInit: '[data-tooltip-definition],[data-tooltip-icon]',
        selectorTriggerButton: ".".concat(prefix, "--tooltip__trigger.").concat(prefix, "--tooltip--a11y"),
        classTooltipHidden: "".concat(prefix, "--tooltip--hidden"),
        classTooltipVisible: "".concat(prefix, "--tooltip--visible")
      };
    }
    /**
     * The map associating DOM element and simple tooltip UI instance.
     * @type {WeakMap}
     */

  }]);

  TooltipSimple.components = new WeakMap();
  return TooltipSimple;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_2__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_4__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__["default"]));



/***/ }),

/***/ "./node_modules/carbon-components/es/components/tooltip/tooltip.js":
/*!*************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/tooltip/tooltip.js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_event__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-event */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-event.js");
/* harmony import */ var _globals_js_mixins_evented_show_hide_state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/evented-show-hide-state */ "./node_modules/carbon-components/es/globals/js/mixins/evented-show-hide-state.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../floating-menu/floating-menu */ "./node_modules/carbon-components/es/components/floating-menu/floating-menu.js");
/* harmony import */ var _globals_js_misc_get_launching_details__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../globals/js/misc/get-launching-details */ "./node_modules/carbon-components/es/globals/js/misc/get-launching-details.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    if (enumerableOnly) symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    });
    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */











/**
 * @param {Element} menuBody The menu body with the menu arrow.
 * @param {string} menuDirection Where the floating menu menu should be placed relative to the trigger button.
 * @returns {FloatingMenu~offset} The adjustment of the floating menu position, upon the position of the menu arrow.
 * @private
 */

var getMenuOffset = function getMenuOffset(menuBody, menuDirection) {
  var _DIRECTION_LEFT$DIREC, _DIRECTION_LEFT$DIREC2;

  var arrowStyle = menuBody.ownerDocument.defaultView.getComputedStyle(menuBody, ':before');
  var arrowPositionProp = (_DIRECTION_LEFT$DIREC = {}, _defineProperty(_DIRECTION_LEFT$DIREC, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_6__["DIRECTION_LEFT"], 'right'), _defineProperty(_DIRECTION_LEFT$DIREC, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_6__["DIRECTION_TOP"], 'bottom'), _defineProperty(_DIRECTION_LEFT$DIREC, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_6__["DIRECTION_RIGHT"], 'left'), _defineProperty(_DIRECTION_LEFT$DIREC, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_6__["DIRECTION_BOTTOM"], 'top'), _DIRECTION_LEFT$DIREC)[menuDirection];
  var menuPositionAdjustmentProp = (_DIRECTION_LEFT$DIREC2 = {}, _defineProperty(_DIRECTION_LEFT$DIREC2, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_6__["DIRECTION_LEFT"], 'left'), _defineProperty(_DIRECTION_LEFT$DIREC2, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_6__["DIRECTION_TOP"], 'top'), _defineProperty(_DIRECTION_LEFT$DIREC2, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_6__["DIRECTION_RIGHT"], 'left'), _defineProperty(_DIRECTION_LEFT$DIREC2, _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_6__["DIRECTION_BOTTOM"], 'top'), _DIRECTION_LEFT$DIREC2)[menuDirection];
  var values = [arrowPositionProp, 'border-bottom-width'].reduce(function (o, name) {
    return _objectSpread(_objectSpread({}, o), {}, _defineProperty({}, name, Number((/^([\d-.]+)px$/.exec(arrowStyle.getPropertyValue(name)) || [])[1])));
  }, {});
  var margin = 0;

  if (menuDirection !== _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_6__["DIRECTION_BOTTOM"]) {
    var style = menuBody.ownerDocument.defaultView.getComputedStyle(menuBody);
    margin = Number((/^([\d-.]+)px$/.exec(style.getPropertyValue('margin-top')) || [])[1]);
  }

  values[arrowPositionProp] = values[arrowPositionProp] || -6; // IE, etc.

  if (Object.keys(values).every(function (name) {
    return !isNaN(values[name]);
  })) {
    var arrowPosition = values[arrowPositionProp],
        borderBottomWidth = values['border-bottom-width'];
    return _defineProperty({
      left: 0,
      top: 0
    }, menuPositionAdjustmentProp, Math.sqrt(Math.pow(borderBottomWidth, 2) * 2) - arrowPosition + margin * (menuDirection === _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_6__["DIRECTION_TOP"] ? 2 : 1));
  }

  return undefined;
};
/**
 * Key codes for allowed keys that will trigger opening a tooltip
 * @type {Integer[]}
 * @private
 */


var allowedOpenKeys = [32, 13];

var Tooltip = /*#__PURE__*/function (_mixin) {
  _inherits(Tooltip, _mixin);

  var _super = _createSuper(Tooltip);
  /**
   * Tooltip.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   */


  function Tooltip(element, options) {
    var _this;

    _classCallCheck(this, Tooltip);

    _this = _super.call(this, element, options);
    _this._hasContextMenu = false;

    _this._hookOn(element);

    return _this;
  }
  /**
   * A flag to detect if `oncontextmenu` event is fired right before `focus`/`blur` events.
   * @type {boolean}
   */


  _createClass(Tooltip, [{
    key: "createdByEvent",

    /**
     * A method called when this widget is created upon events.
     * @param {Event} event The event triggering the creation.
     */
    value: function createdByEvent(event) {
      var relatedTarget = event.relatedTarget,
          type = event.type,
          which = event.which;

      if (type === 'click' || allowedOpenKeys.includes(which)) {
        this._handleClick({
          relatedTarget: relatedTarget,
          type: type,
          details: Object(_globals_js_misc_get_launching_details__WEBPACK_IMPORTED_MODULE_7__["default"])(event)
        });
      }
    }
    /**
     * Changes the shown/hidden state.
     * @param {string} state The new state.
     * @param {object} detail The detail of the event trigging this action.
     * @param {Function} callback Callback called when change in state completes.
     */

  }, {
    key: "changeState",
    value: function changeState(state, detail, callback) {
      if (!this.tooltip) {
        var tooltip = this.element.ownerDocument.querySelector(this.element.getAttribute(this.options.attribTooltipTarget));

        if (!tooltip) {
          throw new Error('Cannot find the target tooltip.');
        } // Lazily create a component instance for tooltip


        this.tooltip = _floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_6__["default"].create(tooltip, {
          refNode: this.element,
          classShown: this.options.classShown,
          offset: this.options.objMenuOffset,
          contentNode: tooltip.querySelector(this.options.selectorContent)
        });

        this._hookOn(tooltip);

        this.children.push(this.tooltip);
      } // Delegates the action of changing state to the tooltip.
      // (And thus the before/after shown/hidden events are fired from the tooltip)


      this.tooltip.changeState(state, Object.assign(detail, {
        delegatorNode: this.element
      }), callback);
    }
    /**
     * Attaches event handlers to show the tooltip.
     * @param {Element} element The element to attach the events to.
     * @private
     */

  }, {
    key: "_hookOn",
    value: function _hookOn(element) {
      var _this2 = this;
      /**
       * Setup the _handleClick function for displaying a tooltip
       * @param {Event} evt - user initiated event
       * @param {Integer[]} [allowedKeys] - allowed key codes the user may press to open the tooltip
       * @private
       */


      var handleClickContextMenu = function handleClickContextMenu(evt, allowedKeys) {
        var relatedTarget = evt.relatedTarget,
            type = evt.type,
            which = evt.which; // Allow user to use `space` or `enter` to open tooltip

        if (typeof allowedKeys === 'undefined' || allowedKeys.includes(which)) {
          var hadContextMenu = _this2._hasContextMenu;
          _this2._hasContextMenu = type === 'contextmenu';

          _this2._handleClick({
            relatedTarget: relatedTarget,
            type: type,
            hadContextMenu: hadContextMenu,
            details: Object(_globals_js_misc_get_launching_details__WEBPACK_IMPORTED_MODULE_7__["default"])(evt)
          });
        }
      };

      this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_8__["default"])(element, 'click', handleClickContextMenu, false));

      if (this.element.tagName !== 'BUTTON') {
        this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_8__["default"])(this.element, 'keydown', function (event) {
          handleClickContextMenu(event, allowedOpenKeys);
        }, false));
      }
    }
    /**
     * Handles click/focus events.
     * @param {object} params The parameters.
     * @param {Element} params.relatedTarget The element that focus went to. (For `blur` event)
     * @param {string} params.type The event type triggering this method.
     * @param {boolean} params.hadContextMenu
     * @param {object} params.details The event details.
     * @private
     */

  }, {
    key: "_handleClick",
    value: function _handleClick(_ref2) {
      var relatedTarget = _ref2.relatedTarget,
          type = _ref2.type,
          hadContextMenu = _ref2.hadContextMenu,
          details = _ref2.details;
      var state = {
        click: 'shown',
        keydown: 'shown',
        blur: 'hidden',
        touchleave: 'hidden',
        touchcancel: 'hidden'
      }[type];
      var shouldPreventClose;

      if (type === 'blur') {
        // Note: SVGElement in IE11 does not have `.contains()`
        var wentToSelf = relatedTarget && this.element.contains && this.element.contains(relatedTarget) || this.tooltip && this.tooltip.element.contains(relatedTarget);
        shouldPreventClose = hadContextMenu || wentToSelf;
      }

      if (!shouldPreventClose) {
        this.changeState(state, details);
      }
    }
  }], [{
    key: "options",
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_0__["default"].prefix;
      return {
        selectorInit: '[data-tooltip-trigger]',
        selectorContent: ".".concat(prefix, "--tooltip__content"),
        classShown: "".concat(prefix, "--tooltip--shown"),
        attribTooltipTarget: 'data-tooltip-target',
        objMenuOffset: getMenuOffset,
        initEventNames: ['click', 'keydown']
      };
    }
  }]);

  Tooltip.components = new WeakMap();
  return Tooltip;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_1__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_init_component_by_event__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_evented_show_hide_state__WEBPACK_IMPORTED_MODULE_4__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_5__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (Tooltip);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/ui-shell/header-nav.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/ui-shell/header-nav.js ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */









var toArray = function toArray(arrayLike) {
  return Array.prototype.slice.call(arrayLike);
};

var HeaderNav = /*#__PURE__*/function (_mixin) {
  _inherits(HeaderNav, _mixin);

  var _super = _createSuper(HeaderNav);
  /**
   * Header nav.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as an header nav.
   * @param {object} [options] The component options.
   * @param {string} [options.selectorSubmenu] The CSS selector to find sub menus.
   * @param {string} [options.selectorSubmenuLink] The CSS selector to find the trigger buttons of sub menus.
   * @param {string} [options.selectorSubmenuItem] The CSS selector to find the sub menu items.
   */


  function HeaderNav(element, options) {
    var _this;

    _classCallCheck(this, HeaderNav);

    _this = _super.call(this, element, options);

    _this.getCurrentNavigation = function () {
      var focused = _this.element.ownerDocument.activeElement.closest(_this.options.selectorSubmenu);

      return focused && focused.nodeType === Node.ELEMENT_NODE ? focused.querySelector(_this.options.selectorSubmenuLink) : null;
    };

    _this.navigate = function (direction) {
      var items = toArray(_this.element.querySelectorAll(_this.options.selectorSubmenuLink));

      var start = _this.getCurrentNavigation();

      var getNextItem = function getNextItem(old) {
        var handleUnderflow = function handleUnderflow(index, length) {
          return index + (index >= 0 ? 0 : length);
        };

        var handleOverflow = function handleOverflow(index, length) {
          return index - (index < length ? 0 : length);
        }; // `items.indexOf(old)` may be -1 (Scenario of no previous focus)


        var index = Math.max(items.indexOf(old) + direction, -1);
        return items[handleUnderflow(handleOverflow(index, items.length), items.length)];
      };

      getNextItem(start).focus();
    };

    _this._handleKeyDown = function (event) {
      var keyCodes = {
        37: _this.constructor.NAVIGATE.BACKWARD,
        // left arrow
        39: _this.constructor.NAVIGATE.FORWARD // right arrow

      };
      var keyCodeMatches = keyCodes[event.which];

      if (keyCodeMatches) {
        _this.navigate(keyCodeMatches);
      }
    };

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_4__["default"])(_this.element, 'keydown', _this._handleKeyDown));

    return _this;
  }
  /**
   * The map associating DOM element and Header instance.
   * @member HeaderNav.components
   * @type {WeakMap}
   */


  _createClass(HeaderNav, null, [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor,
     * {@linkcode HeaderNav.create .create()}, or
     * {@linkcode HeaderNav.init .init()},
     * properties in this object are overriden for the instance being create and
     * how {@linkcode HeaderNav.init .init()} works.
     * @member HeaderNav.options
     * @type {object}
     * @property {string} selectorInit The data attribute to find side navs.
     * @property {string} [selectorSubmenu] The CSS selector to find sub menus.
     * @property {string} [selectorSubmenuLink] The CSS selector to find the trigger buttons of sub menus.
     * @property {string} [selectorSubmenuItem] The CSS selector to find the sub menu items.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_5__["default"].prefix;
      return {
        selectorInit: '[data-header-nav]',
        selectorNavKind: '[data-header-nav-kind]',
        selectorSubmenu: ".".concat(prefix, "--header__submenu"),
        selectorSubmenuLink: ".".concat(prefix, "--header__menu-title"),
        selectorSubmenuItem: ".".concat(prefix, "--header__menu-title > .").concat(prefix, "--header__menu-item")
      };
    }
    /**
     * Enum for navigating backward/forward.
     * @readonly
     * @member Header.NAVIGATE
     * @type {object}
     * @property {number} BACKWARD Navigating backward.
     * @property {number} FORWARD Navigating forward.
     */

  }]);

  HeaderNav.components = new WeakMap();
  HeaderNav.NAVIGATE = {
    BACKWARD: -1,
    FORWARD: 1
  };
  return HeaderNav;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_0__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_1__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_3__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (HeaderNav);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/ui-shell/header-submenu.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/ui-shell/header-submenu.js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

function _iterableToArrayLimit(arr, i) {
  if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return;
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */










var forEach = /* #__PURE__ */function () {
  return Array.prototype.forEach;
}();

var toArray = function toArray(arrayLike) {
  return Array.prototype.slice.call(arrayLike);
};

var HeaderSubmenu = /*#__PURE__*/function (_mixin) {
  _inherits(HeaderSubmenu, _mixin);

  var _super = _createSuper(HeaderSubmenu);
  /**
   * Sub menus in header nav.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as a submenu in header nav.
   * @param {object} [options] The component options.
   * @param {string} [options.selectorTrigger] The CSS selector to find the trigger button.
   * @param {string} [options.selectorItem] The CSS selector to find the menu items.
   * @param {string} [options.attribExpanded] The attribute that represents the expanded/collapsed state.
   */


  function HeaderSubmenu(element, options) {
    var _this;

    _classCallCheck(this, HeaderSubmenu);

    _this = _super.call(this, element, options);

    _this._getAction = function (event) {
      var isFlyoutMenu = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__["default"])(event, _this.options.selectorFlyoutMenu);

      if (isFlyoutMenu) {
        return _this.constructor.actions.DELEGATE_TO_FLYOUT_MENU;
      }

      switch (event.type) {
        case 'keydown':
          return {
            32: _this.constructor.actions.TOGGLE_SUBMENU_WITH_FOCUS,
            // space bar
            13: _this.constructor.actions.TOGGLE_SUBMENU_WITH_FOCUS,
            // enter
            27: _this.constructor.actions.CLOSE_SUBMENU // esc
            // possible arrow keys

          }[event.which];

        case 'click':
          return Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__["default"])(event, _this.options.selectorItem) ? _this.constructor.actions.CLOSE_SUBMENU : null;

        case 'blur':
        case 'focusout':
          {
            var isOfSelf = _this.element.contains(event.relatedTarget);

            return isOfSelf ? null : _this.constructor.actions.CLOSE_SUBMENU;
          }

        case 'mouseenter':
          return _this.constructor.actions.OPEN_SUBMENU;

        case 'mouseleave':
          return _this.constructor.actions.CLOSE_SUBMENU;

        default:
          return null;
      }
    };

    _this._getNewState = function (action) {
      var trigger = _this.element.querySelector(_this.options.selectorTrigger);

      var isExpanded = trigger.getAttribute(_this.options.attribExpanded) === 'true';

      switch (action) {
        case _this.constructor.actions.CLOSE_SUBMENU:
          return false;

        case _this.constructor.actions.OPEN_SUBMENU:
          return true;

        case _this.constructor.actions.TOGGLE_SUBMENU_WITH_FOCUS:
          return !isExpanded;

        default:
          return isExpanded;
      }
    };

    _this._setState = function (_ref) {
      var shouldBeExpanded = _ref.shouldBeExpanded,
          shouldFocusOnOpen = _ref.shouldFocusOnOpen;

      var trigger = _this.element.querySelector(_this.options.selectorTrigger);

      trigger.setAttribute(_this.options.attribExpanded, shouldBeExpanded);
      forEach.call(_this.element.querySelectorAll(_this.options.selectorItem), function (item) {
        item.tabIndex = shouldBeExpanded ? 0 : -1;
      }); // focus first submenu item

      if (shouldBeExpanded && shouldFocusOnOpen) {
        _this.element.querySelector(_this.options.selectorItem).focus();
      }
    };

    _this.getCurrentNavigation = function () {
      var focused = _this.element.ownerDocument.activeElement;
      return focused.nodeType === Node.ELEMENT_NODE && focused.matches(_this.options.selectorItem) ? focused : null;
    };

    _this.navigate = function (direction) {
      var items = toArray(_this.element.querySelectorAll(_this.options.selectorItem));

      var start = _this.getCurrentNavigation() || _this.element.querySelector(_this.options.selectorItemSelected);

      var getNextItem = function getNextItem(old) {
        var handleUnderflow = function handleUnderflow(index, length) {
          return index + (index >= 0 ? 0 : length);
        };

        var handleOverflow = function handleOverflow(index, length) {
          return index - (index < length ? 0 : length);
        }; // `items.indexOf(old)` may be -1 (Scenario of no previous focus)


        var index = Math.max(items.indexOf(old) + direction, -1);
        return items[handleUnderflow(handleOverflow(index, items.length), items.length)];
      };

      for (var current = getNextItem(start); current && current !== start; current = getNextItem(current)) {
        if (!current.matches(_this.options.selectorItemHidden) && !current.parentNode.matches(_this.options.selectorItemHidden) && !current.matches(_this.options.selectorItemSelected)) {
          current.focus();
          break;
        }
      }
    };

    _this._handleEvent = function (event) {
      var trigger = _this.element.querySelector(_this.options.selectorTrigger);

      if (!trigger) {
        return;
      }

      var action = _this._getAction(event);

      if (action) {
        var shouldBeExpanded = _this._getNewState(action);

        _this._setState({
          shouldBeExpanded: shouldBeExpanded
        });
      }
    };

    _this._handleKeyDown = function (event) {
      var trigger = _this.element.querySelector(_this.options.selectorTrigger);

      if (!trigger) {
        return;
      }

      var action = _this._getAction(event);

      if (event.which === 32) {
        event.preventDefault();
      }

      switch (action) {
        case _this.constructor.actions.DELEGATE_TO_FLYOUT_MENU:
          // currently we do not have a scenario that handles flyout menu
          // handleFlyoutMenu
          break;
        // currently we do not have a scenario that opens a submenu on keydown
        // case this.constructor.actions.OPEN_SUBMENU:

        case _this.constructor.actions.CLOSE_SUBMENU:
          {
            var shouldBeExpanded = _this._getNewState(action);

            _this._setState({
              shouldBeExpanded: shouldBeExpanded
            });

            break;
          }

        case _this.constructor.actions.TOGGLE_SUBMENU_WITH_FOCUS:
          {
            var _shouldBeExpanded = _this._getNewState(action);

            _this._setState({
              shouldBeExpanded: _shouldBeExpanded,
              shouldFocusOnOpen: true
            });

            break;
          }

        default:
          {
            var expanded = trigger.getAttribute(_this.options.attribExpanded) === 'true';

            if (expanded) {
              var direction = {
                38: _this.constructor.NAVIGATE.BACKWARD,
                40: _this.constructor.NAVIGATE.FORWARD
              }[event.which];

              switch (event.which) {
                case 35:
                  {
                    // end key
                    event.preventDefault(); // prevents key from scrolling page

                    var menuItems = _this.element.querySelectorAll(_this.options.selectorItem);

                    var lastMenuItem = menuItems[menuItems.length - 1];

                    if (lastMenuItem) {
                      lastMenuItem.focus();
                    }

                    break;
                  }

                case 36:
                  {
                    // home key
                    event.preventDefault(); // prevents key from scrolling page

                    var _this$element$querySe = _this.element.querySelectorAll(_this.options.selectorItem),
                        _this$element$querySe2 = _slicedToArray(_this$element$querySe, 1),
                        firstMenuItem = _this$element$querySe2[0];

                    if (firstMenuItem) {
                      firstMenuItem.focus();
                    }

                    break;
                  }

                case 38: // up arrow

                case 40:
                  // down arrow
                  _this.navigate(direction);

                  event.preventDefault(); // prevents keys from scrolling page

                  break;

                default:
                  break;
              }
            }

            break;
          }
      }
    };

    var hasFocusOut = ('onfocusout' in window);

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_4__["default"])(_this.element, hasFocusOut ? 'focusout' : 'blur', _this._handleEvent, !hasFocusOut));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_4__["default"])(_this.element, 'mouseenter', _this._handleEvent));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_4__["default"])(_this.element, 'mouseleave', _this._handleEvent));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_4__["default"])(_this.element, 'click', _this._handleEvent));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_4__["default"])(_this.element, 'keydown', _this._handleKeyDown));

    return _this;
  }
  /**
   * The map associating DOM element and HeaderSubmenu instance.
   * @member HeaderSubmenu.components
   * @type {WeakMap}
   */


  _createClass(HeaderSubmenu, null, [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor,
     * {@linkcode HeaderSubmenu.create .create()}, or
     * {@linkcode HeaderSubmenu.init .init()},
     * properties in this object are overriden for the instance being create and
     * how {@linkcode HeaderSubmenu.init .init()} works.
     * @member HeaderSubmenu.options
     * @type {object}
     * @property {string} selectorInit The data attribute to find side navs.
     * @property {string} [selectorTrigger] The CSS selector to find the trigger button.
     * @property {string} [selectorItem] The CSS selector to find the menu items.
     * @property {string} [attribExpanded] The attribute that represents the expanded/collapsed state.
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_5__["default"].prefix;
      return {
        selectorInit: '[data-header-submenu]',
        selectorTrigger: ".".concat(prefix, "--header__menu-title"),
        selectorItem: ".".concat(prefix, "--header__menu .").concat(prefix, "--header__menu-item"),
        attribExpanded: 'aria-expanded'
      };
    }
    /**
     * Enum for navigating backward/forward.
     * @readonly
     * @member HeaderSubmenu.NAVIGATE
     * @type {object}
     * @property {number} BACKWARD Navigating backward.
     * @property {number} FORWARD Navigating forward.
     */

  }]);

  HeaderSubmenu.components = new WeakMap();
  HeaderSubmenu.actions = {
    CLOSE_SUBMENU: 'CLOSE_SUBMENU',
    OPEN_SUBMENU: 'OPEN_SUBMENU',
    TOGGLE_SUBMENU_WITH_FOCUS: 'TOGGLE_SUBMENU_WITH_FOCUS',
    DELEGATE_TO_FLYOUT_MENU: 'DELEGATE_TO_FLYOUT_MENU'
  };
  HeaderSubmenu.NAVIGATE = {
    BACKWARD: -1,
    FORWARD: 1
  };
  return HeaderSubmenu;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_0__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_1__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_3__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (HeaderSubmenu);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/ui-shell/navigation-menu-panel.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/ui-shell/navigation-menu-panel.js ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return NavigationMenuPanel; });
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_mixins_init_component_by_launcher__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-launcher */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-launcher.js");
/* harmony import */ var _globals_js_mixins_evented_show_hide_state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/evented-show-hide-state */ "./node_modules/carbon-components/es/globals/js/mixins/evented-show-hide-state.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_mixins_evented_state__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/mixins/evented-state */ "./node_modules/carbon-components/es/globals/js/mixins/evented-state.js");
/* harmony import */ var _globals_js_misc_toggle_attribute__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/toggle-attribute */ "./node_modules/carbon-components/es/globals/js/misc/toggle-attribute.js");
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */











var NavigationMenuPanel = /*#__PURE__*/function (_mixin) {
  _inherits(NavigationMenuPanel, _mixin);

  var _super = _createSuper(NavigationMenuPanel);

  function NavigationMenuPanel() {
    var _this;

    _classCallCheck(this, NavigationMenuPanel);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));

    _this.createdByLauncher = function (event) {
      var isExpanded = !_this.element.hasAttribute('hidden');
      var newState = isExpanded ? 'collapsed' : 'expanded';
      _this.triggerButton = event.delegateTarget;

      _this.changeState(newState);
    };

    _this.shouldStateBeChanged = function (state) {
      return state === 'expanded' === _this.element.hasAttribute('hidden');
    };

    _this._changeState = function (state, callback) {
      Object(_globals_js_misc_toggle_attribute__WEBPACK_IMPORTED_MODULE_6__["default"])(_this.element, 'hidden', state !== 'expanded');

      if (_this.triggerButton) {
        if (state === 'expanded') {
          var focusableMenuItems = _this.element.querySelector(_this.options.selectorFocusableMenuItem);

          if (focusableMenuItems) {
            focusableMenuItems.focus();
          }
        }

        var label = state === 'expanded' ? _this.triggerButton.getAttribute(_this.options.attribLabelCollapse) : _this.triggerButton.getAttribute(_this.options.attribLabelExpand);

        _this.triggerButton.classList.toggle(_this.options.classNavigationMenuPanelHeaderActionActive, state === 'expanded');

        _this.triggerButton.setAttribute('aria-label', label);

        _this.triggerButton.setAttribute('title', label);
      }

      callback();
    };

    return _this;
  }

  _createClass(NavigationMenuPanel, null, [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor,
     * {@linkcode NavigationMenuPanel.create .create()}, or
     * {@linkcode NavigationMenuPanel.init .init()},
     * properties in this object are overriden for the instance being create and
     * how {@linkcode NavigationMenuPanel.init .init()} works.
     * @member NavigationMenuPanel.options
     * @type {object}
     * @property {string} selectorInit The CSS class to find popup navs.
     * @property {string} attribInitTarget The attribute name in the launcher buttons to find target popup nav.
     * @property {string[]} initEventNames The events that the component will handles
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_7__["default"].prefix;
      return {
        initEventNames: ['click'],
        eventBeforeExpanded: 'navigation-menu-being-expanded',
        eventAfterExpanded: 'navigation-menu-expanded',
        eventBeforeCollapsed: 'navigation-menu-being-collapsed',
        eventAfterCollapsed: 'navigation-menu-collapsed',
        selectorFocusableMenuItem: ".".concat(prefix, "--navigation__category-toggle, .").concat(prefix, "--navigation-link"),
        classNavigationMenuPanelHeaderActionActive: "".concat(prefix, "--header__action--active"),
        attribLabelExpand: 'data-navigation-menu-panel-label-expand',
        attribLabelCollapse: 'data-navigation-menu-panel-label-collapse'
      };
    }
  }]);

  NavigationMenuPanel.components = new WeakMap();
  return NavigationMenuPanel;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_0__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_1__["default"], _globals_js_mixins_init_component_by_launcher__WEBPACK_IMPORTED_MODULE_2__["default"], _globals_js_mixins_evented_show_hide_state__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"], _globals_js_mixins_evented_state__WEBPACK_IMPORTED_MODULE_5__["default"]));



/***/ }),

/***/ "./node_modules/carbon-components/es/components/ui-shell/navigation-menu.js":
/*!**********************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/ui-shell/navigation-menu.js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return NavigationMenu; });
/* harmony import */ var _navigation_menu_panel__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./navigation-menu-panel */ "./node_modules/carbon-components/es/components/ui-shell/navigation-menu-panel.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */







var NavigationMenu = /*#__PURE__*/function (_NavigationMenuPanel) {
  _inherits(NavigationMenu, _NavigationMenuPanel);

  var _super = _createSuper(NavigationMenu);
  /**
   * A navigation menu
   * @extends NavigationMenuPanel
   * @param {HTMLElement} element The element working as a selector.
   * @param {object} [options] The component options.
   * @param {string} [options.selectorInit] The CSS class to find navigation
   * menus.
   * @param {string} [options.attribInitTarget] The attribute name in the
   * launcher buttons to find target navigation menu.
   * @param {string} [options.selectorShellNavSubmenu] The CSS selector for a
   * nav submenu
   * @param {string} [options.selectorShellNavLink] The CSS selector for a nav
   * link
   * @param {string} [options.selectorShellNavLinkCurrent] The CSS selector for
   * the current nav link
   * @param {string} [options.selectorShellNavItem] The CSS selector for a nav
   * item
   * @param {string} [options.selectorShellNavCategory] The CSS selector for a
   * nav category
   * @param {string} [options.classShellNavItemActive] The CSS class for the
   * active nav item
   * @param {string} [options.classShellNavLinkCurrent] The CSS class for the
   * current lav link
   * @param {string} [options.classShellNavCategoryExpanded] The CSS class
   * for an expanded nav category
   */


  function NavigationMenu(element, options) {
    var _this;

    _classCallCheck(this, NavigationMenu);

    _this = _super.call(this, element, options);

    _this.getCurrentNavigation = function () {
      return _this.element.ownerDocument.activeElement;
    };

    _this.navigate = function (direction) {
      var items = _toConsumableArray(_this.element.querySelectorAll(_this.options.selectorFocusableNavItems));

      var start = _this.getCurrentNavigation();

      var getNextItem = function getNextItem(old) {
        var handleUnderflow = function handleUnderflow(index, length) {
          return index + (index >= 0 ? 0 : length);
        };

        var handleOverflow = function handleOverflow(index, length) {
          return index - (index < length ? 0 : length);
        }; // `items.indexOf(old)` may be -1 (Scenario of no previous focus)


        var index = Math.max(items.indexOf(old) + direction, -1);
        return items[handleUnderflow(handleOverflow(index, items.length), items.length)];
      };

      getNextItem(start).focus();
    };

    _this._handleKeyDown = function (event) {
      // handle Esc
      var isExpanded = !_this.element.hasAttribute('hidden');

      if (event.which === 27 && isExpanded) {
        _this.changeState('collapsed');

        if (_this.triggerButton) {
          _this.triggerButton.focus();
        }

        return;
      } // handle up/down arrow keys


      var matchesNavSubmenu = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_2__["default"])(event, _this.options.selectorShellNavSubmenu);
      var matchesShellNavLink = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_2__["default"])(event, _this.options.selectorShellNavLink);

      if (!matchesNavSubmenu && !matchesShellNavLink) {
        return;
      }

      var navigationKeyCodes = {
        38: _this.constructor.NAVIGATE.BACKWARD,
        // up arrow
        40: _this.constructor.NAVIGATE.FORWARD // down arrow

      };
      var navigationKeyCodeMatches = navigationKeyCodes[event.which];

      if (navigationKeyCodeMatches) {
        event.preventDefault(); // prevent arrow keys from scrolling

        _this.navigate(navigationKeyCodeMatches);
      }
    };

    _this._handleFocusOut = function (event) {
      var nextTargetIsOfSelf = _this.element.contains(event.relatedTarget) || event.relatedTarget === _this.triggerButton || !event.relatedTarget;

      var oldTargetIsOfSelf = _this.element.contains(event.target);

      if (oldTargetIsOfSelf && !nextTargetIsOfSelf) {
        _this.changeState('collapsed');

        _this.triggerButton.focus();
      }
    };

    _this.changeNavSubmenuState = function (_ref) {
      var matchesNavSubmenu = _ref.matchesNavSubmenu,
          shouldBeCollapsed = _ref.shouldBeCollapsed;
      var shellNavCategory = matchesNavSubmenu.closest(_this.options.selectorShellNavCategory);

      if (!shellNavCategory) {
        return;
      }

      matchesNavSubmenu.setAttribute('aria-expanded', !shouldBeCollapsed);
      shellNavCategory.classList.toggle(_this.options.classShellNavCategoryExpanded);
      Array.prototype.forEach.call(shellNavCategory.querySelectorAll(_this.options.selectorShellNavLink), function (item) {
        item.tabIndex = !shouldBeCollapsed ? 0 : -1;
      });
    };

    _this._handleClick = function (event) {
      var matchesNavSubmenu = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_2__["default"])(event, _this.options.selectorShellNavSubmenu);
      var matchesShellNavLink = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_2__["default"])(event, _this.options.selectorShellNavLink);
      var matchesNestedShellNavLink = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_2__["default"])(event, _this.options.selectorShellNestedNavLink);

      if (!matchesNavSubmenu && !matchesShellNavLink) {
        return;
      }

      if (matchesNestedShellNavLink) {
        _toConsumableArray(_this.element.querySelectorAll(_this.options.selectorShellNavLinkCurrent)).forEach(function (el) {
          el.classList.remove(_this.options.classShellNavItemActive, _this.options.classShellNavLinkCurrent);
        });

        matchesNestedShellNavLink.closest(_this.options.selectorShellNavNestedCategory).classList.add(_this.options.classShellNavItemActive);
        return;
      }

      if (matchesNavSubmenu) {
        var isExpanded = matchesNavSubmenu.getAttribute('aria-expanded') === 'true';

        _this.changeNavSubmenuState({
          matchesNavSubmenu: matchesNavSubmenu,
          isExpanded: isExpanded
        });

        return;
      }

      if (matchesShellNavLink) {
        _toConsumableArray(_this.element.querySelectorAll(_this.options.selectorShellNavLinkCurrent)).forEach(function (el) {
          el.classList.remove(_this.options.classShellNavItemActive, _this.options.classShellNavLinkCurrent);
        });

        matchesShellNavLink.closest(_this.options.selectorShellNavItem).classList.add(_this.options.classShellNavItemActive);
      }
    };

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_1__["default"])(element, 'click', _this._handleClick));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_1__["default"])(element, 'keydown', _this._handleKeyDown));

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_1__["default"])(_this.element.ownerDocument, 'click', function (event) {
      if (!_this.element.hasAttribute('hidden') && !_this.triggerButton.contains(event.target) && !_this.element.contains(event.target)) {
        _this.changeState('collapsed');
      }
    }));

    var hasFocusOut = ('onfocusout' in window);

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_1__["default"])(_this.element, hasFocusOut ? 'focusout' : 'blur', _this._handleFocusOut, !hasFocusOut));

    return _this;
  }
  /**
   * @returns {Element} Currently highlighted element.
   */


  _createClass(NavigationMenu, null, [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor,
     * {@linkcode NavigationMenu.create .create()}, or
     * {@linkcode NavigationMenu.init .init()},
     * properties in this object are overriden for the instance being create and
     * how {@linkcode NavigationMenu.init .init()} works.
     * @member NavigationMenu.options
     * @type {object}
     * @property {string} selectorInit The CSS class to find navigation menus.
     * @property {string} attribInitTarget The attribute name in the
     * launcher buttons to find target navigation menu.
     * @property {string[]} initEventNames The events that the component
     * will handles
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_3__["default"].prefix;
      return Object.assign(Object.create(_navigation_menu_panel__WEBPACK_IMPORTED_MODULE_0__["default"].options), {
        selectorInit: '[data-navigation-menu]',
        attribInitTarget: 'data-navigation-menu-target',
        selectorShellNavSubmenu: ".".concat(prefix, "--navigation__category-toggle"),
        selectorShellNavLink: ".".concat(prefix, "--navigation-link"),
        selectorShellNestedNavLink: ".".concat(prefix, "--navigation__category-item > a.").concat(prefix, "--navigation-link"),
        selectorShellNavLinkCurrent: ".".concat(prefix, "--navigation-item--active,.").concat(prefix, "--navigation__category-item--active"),
        selectorFocusableNavItems: "\n        .".concat(prefix, "--navigation__category-toggle,\n        .").concat(prefix, "--navigation-item > .").concat(prefix, "--navigation-link,\n        .").concat(prefix, "--navigation-link[tabindex=\"0\"]\n      "),
        selectorShellNavItem: ".".concat(prefix, "--navigation-item"),
        selectorShellNavCategory: ".".concat(prefix, "--navigation__category"),
        selectorShellNavNestedCategory: ".".concat(prefix, "--navigation__category-item"),
        classShellNavItemActive: "".concat(prefix, "--navigation-item--active"),
        classShellNavLinkCurrent: "".concat(prefix, "--navigation__category-item--active"),
        classShellNavCategoryExpanded: "".concat(prefix, "--navigation__category--expanded")
      });
    }
    /**
     * Enum for navigating backward/forward.
     * @readonly
     * @member NavigationMenuPanel.NAVIGATE
     * @type {object}
     * @property {number} BACKWARD Navigating backward.
     * @property {number} FORWARD Navigating forward.
     */

  }]);

  NavigationMenu.components = new WeakMap();
  NavigationMenu.NAVIGATE = {
    BACKWARD: -1,
    FORWARD: 1
  };
  return NavigationMenu;
}(_navigation_menu_panel__WEBPACK_IMPORTED_MODULE_0__["default"]);



/***/ }),

/***/ "./node_modules/carbon-components/es/components/ui-shell/product-switcher.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/ui-shell/product-switcher.js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _navigation_menu_panel__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./navigation-menu-panel */ "./node_modules/carbon-components/es/components/ui-shell/navigation-menu-panel.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_misc_on_focus_by_keyboard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/misc/on-focus-by-keyboard */ "./node_modules/carbon-components/es/globals/js/misc/on-focus-by-keyboard.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _get(target, property, receiver) {
  if (typeof Reflect !== "undefined" && Reflect.get) {
    _get = Reflect.get;
  } else {
    _get = function _get(target, property, receiver) {
      var base = _superPropBase(target, property);

      if (!base) return;
      var desc = Object.getOwnPropertyDescriptor(base, property);

      if (desc.get) {
        return desc.get.call(receiver);
      }

      return desc.value;
    };
  }

  return _get(target, property, receiver || target);
}

function _superPropBase(object, property) {
  while (!Object.prototype.hasOwnProperty.call(object, property)) {
    object = _getPrototypeOf(object);
    if (object === null) break;
  }

  return object;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}





var seq = 0;

var ProductSwitcher = /*#__PURE__*/function (_NavigationMenuPanel) {
  _inherits(ProductSwitcher, _NavigationMenuPanel);

  var _super = _createSuper(ProductSwitcher);
  /**
   * A navigation menu.
   * @extends NavigationMenuPanel
   * @param {HTMLElement} element The element working as a selector.
   * @param {object} [options] The component options.
   * @param {string} [options.selectorInit] The CSS class to find product
   * switchers
   * @param {string} [options.attribInitTarget] The attribute name in the
   * launcher buttons to find target product switcher
   * @param {string} [options.classProductSwitcherExpanded] The CSS class
   * for an expanded product switcher
   */


  function ProductSwitcher(element, options) {
    var _this;

    _classCallCheck(this, ProductSwitcher);

    _this = _super.call(this, element, options);
    _this.current = '';
    _this.triggerButtonIds = new Set();

    _this._handleFocusOut = function (event) {
      if (_this.element.contains(event.relatedTarget)) {
        return;
      }

      var currentTriggerButton = _this.element.ownerDocument.getElementById(_this.current);

      if (currentTriggerButton && event.relatedTarget && !event.relatedTarget.matches(_this.options.selectorFloatingMenus)) {
        currentTriggerButton.focus();
      }
    };

    _this._handleKeyDown = function (event) {
      var isExpanded = !_this.element.hasAttribute('hidden');

      if (event.which === 27 && isExpanded) {
        var triggerButton = _this.current;

        _this.changeState(_this.constructor.SELECT_NONE);

        _this.element.ownerDocument.getElementById(triggerButton).focus();
      }
    };

    _this.createdByLauncher = function (event) {
      var isExpanded = _this.element.classList.contains(_this.options.classProductSwitcherExpanded);

      var launcher = event.delegateTarget;

      if (!launcher.id) {
        launcher.id = "__carbon-product-switcher-launcher-".concat(seq++);
      }

      var current = launcher.id;

      _this.changeState(isExpanded && _this.current === current ? _this.constructor.SELECT_NONE : current);
    };

    _this.shouldStateBeChanged = function (current) {
      return _this.current !== current;
    };

    _this._changeState = function (state, callback) {
      _this.element.classList.toggle(_this.options.classProductSwitcherExpanded, state !== _this.constructor.SELECT_NONE);

      _this.current = state;

      if (_this.current !== _this.constructor.SELECT_NONE) {
        _this.triggerButtonIds.add(_this.current);
      } // deactivate all other trigger buttons


      _this.triggerButtonIds.forEach(function (id) {
        var button = _this.element.ownerDocument.getElementById(id);

        var label = button.getAttribute(_this.options.attribLabelExpand);
        button.classList.remove(_this.options.classNavigationMenuPanelHeaderActionActive);
        button.setAttribute('aria-label', label);
        button.setAttribute('title', label);
      }); // set active trigger button attributes


      var currentTriggerButton = _this.element.ownerDocument.getElementById(_this.current);

      if (currentTriggerButton) {
        var label = currentTriggerButton.getAttribute(_this.options.attribLabelCollapse);
        currentTriggerButton.classList.toggle(_this.options.classNavigationMenuPanelHeaderActionActive);
        currentTriggerButton.setAttribute('aria-label', label);
        currentTriggerButton.setAttribute('title', label);
      }

      if (state !== _this.constructor.SELECT_NONE) {
        _this.element.setAttribute('tabindex', '0');

        _this.element.focus();
      } else {
        _this.element.setAttribute('tabindex', '-1');
      }

      callback();
    };

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_1__["default"])(element, 'keydown', _this._handleKeyDown));

    _this.manage(Object(_globals_js_misc_on_focus_by_keyboard__WEBPACK_IMPORTED_MODULE_3__["default"])(element, 'blur', _this._handleFocusOut));

    return _this;
  }
  /**
   * id of currently active trigger button
   * @type {string}
   */


  _createClass(ProductSwitcher, [{
    key: "release",
    value: function release() {
      this.triggerButtonIds.clear();
      return _get(_getPrototypeOf(ProductSwitcher.prototype), "release", this).call(this);
    }
    /**
     * The map associating DOM element and ProductSwitcher instance.
     * @member ProductSwitcher.components
     * @type {WeakMap}
     */

  }], [{
    key: "options",

    /**
     * The component options.
     * If `options` is specified in the constructor,
     * {@linkcode ProductSwitcher.create .create()}, or
     * {@linkcode ProductSwitcher.init .init()},
     * properties in this object are overriden for the instance being create and
     * how {@linkcode ProductSwitcher.init .init()} works.
     * @member ProductSwitcher.options
     * @type {object}
     * @property {string} selectorInit The CSS class to find popup navs.
     * @property {string} attribInitTarget The attribute name in the
     * launcher buttons to find target popup nav.
     * @property {string[]} initEventNames The events that the component
     * will handles
     */
    get: function get() {
      var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_2__["default"].prefix;
      return Object.assign(Object.create(_navigation_menu_panel__WEBPACK_IMPORTED_MODULE_0__["default"].options), {
        selectorInit: '[data-product-switcher]',
        selectorFloatingMenus: "\n        .".concat(prefix, "--overflow-menu-options,\n        .").concat(prefix, "--overflow-menu-options *,\n        .").concat(prefix, "--tooltip,\n        .").concat(prefix, "--tooltip *,\n        .flatpicker-calendar,\n        .flatpicker-calendar *\n        "),
        attribInitTarget: 'data-product-switcher-target',
        classProductSwitcherExpanded: "".concat(prefix, "--panel--expanded")
      });
    }
  }]);

  ProductSwitcher.SELECT_NONE = '__carbon-product-switcher-launcher-NONE';
  ProductSwitcher.components = new WeakMap();
  return ProductSwitcher;
}(_navigation_menu_panel__WEBPACK_IMPORTED_MODULE_0__["default"]);

/* harmony default export */ __webpack_exports__["default"] = (ProductSwitcher);

/***/ }),

/***/ "./node_modules/carbon-components/es/components/ui-shell/side-nav.js":
/*!***************************************************************************!*\
  !*** ./node_modules/carbon-components/es/components/ui-shell/side-nav.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../globals/js/misc/mixin */ "./node_modules/carbon-components/es/globals/js/misc/mixin.js");
/* harmony import */ var _globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../globals/js/mixins/create-component */ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js");
/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony import */ var _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../globals/js/mixins/init-component-by-search */ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js");
/* harmony import */ var _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../globals/js/mixins/handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
/* harmony import */ var _globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../globals/js/misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
/* harmony import */ var _globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../globals/js/misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */









var prefix = _globals_js_settings__WEBPACK_IMPORTED_MODULE_2__["default"].prefix;

var SideNav = /*#__PURE__*/function (_mixin) {
  _inherits(SideNav, _mixin);

  var _super = _createSuper(SideNav);
  /**
   * The map associating DOM element and copy button UI instance.
   * @member SideNav.components
   * @type {WeakMap}
   */

  /**
   * Side nav.
   * @extends CreateComponent
   * @extends InitComponentBySearch
   * @extends Handles
   * @param {HTMLElement} element The element working as a side nav.
   * @param {object} [options] The component options.
   * @param {string} [options.selectorSideNavToggle]
   *   The CSS selector to find the toggle button.
   * @param {string} [options.selectorSideNavSubmenu] The CSS selector to find the trigger buttons for sub nav items.
   * @param {string} [options.selectorSideNavItem] The CSS selector to find the nav items.
   * @param {string} [options.selectorSideNavLink] The CSS selector to find the interactive potions in non-nested nav items.
   * @param {string} [options.selectorSideNavLinkCurrent]
   *   The CSS selector to find the interactive potion in active non-nested nav item.
   * @param {string} [options.classSideNavExpanded] The CSS class for the expanded state.
   * @param {string} [options.classSideNavItemActive]
   *   The CSS class for the active/inactive state for nav items.
   * @param {string} [options.classSideNavLinkCurrent]
   *   The CSS class for the active/inactive state of the interactive potion in non-nested nav items.
   */


  function SideNav(element, options) {
    var _this;

    _classCallCheck(this, SideNav);

    _this = _super.call(this, element, options);

    _this._handleClick = function (evt) {
      var matchesToggle = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__["default"])(evt, _this.options.selectorSideNavToggle);
      var matchesNavSubmenu = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__["default"])(evt, _this.options.selectorSideNavSubmenu);
      var matchesSideNavLink = Object(_globals_js_misc_event_matches__WEBPACK_IMPORTED_MODULE_6__["default"])(evt, _this.options.selectorSideNavLink);

      if (!matchesToggle && !matchesNavSubmenu && !matchesSideNavLink) {
        return;
      }

      if (matchesToggle) {
        _this.changeState(!_this.isNavExpanded() ? _this.constructor.state.EXPANDED : _this.constructor.state.COLLAPSED);

        return;
      }

      if (matchesNavSubmenu) {
        var isSubmenuExpanded = matchesNavSubmenu.getAttribute('aria-expanded') === 'true';
        matchesNavSubmenu.setAttribute('aria-expanded', "".concat(!isSubmenuExpanded));
        return;
      }

      if (matchesSideNavLink) {
        _toConsumableArray(_this.element.querySelectorAll(_this.options.selectorSideNavLinkCurrent)).forEach(function (el) {
          el.classList.remove(_this.options.classSideNavItemActive, _this.options.classSideNavLinkCurrent);
          el.removeAttribute('aria-current');
        });

        matchesSideNavLink.classList.add(_this.options.classSideNavLinkCurrent);
        var closestSideNavItem = matchesSideNavLink.closest(_this.options.selectorSideNavItem);

        if (closestSideNavItem) {
          closestSideNavItem.classList.add(_this.options.classSideNavItemActive);
        }
      }
    };

    _this.manage(Object(_globals_js_misc_on__WEBPACK_IMPORTED_MODULE_5__["default"])(element, 'click', _this._handleClick));

    return _this;
  }
  /**
   * Enum for toggling side nav visibility
   * @readonly
   * @member SideNav.state
   * @type {object}
   * @property {string} EXPANDED Opening/visible
   * @property {string} COLLAPSED Closing/hidden
   */


  _createClass(SideNav, [{
    key: "isNavExpanded",

    /**
     * @returns {boolean} `true` if the nav is expanded.
     */
    value: function isNavExpanded() {
      return this.element.classList.contains(this.options.classSideNavExpanded);
    }
    /**
     * Changes the expanded/collapsed state.
     */

  }, {
    key: "changeState",
    value: function changeState(state) {
      this.element.classList.toggle(this.options.classSideNavExpanded, state === this.constructor.state.EXPANDED);
    }
  }]);

  SideNav.components = new WeakMap();
  SideNav.state = {
    EXPANDED: 'expanded',
    COLLAPSED: 'collapsed'
  };
  SideNav.options = {
    selectorInit: '[data-side-nav]',
    selectorSideNavToggle: ".".concat(prefix, "--side-nav__toggle"),
    selectorSideNavSubmenu: ".".concat(prefix, "--side-nav__submenu"),
    selectorSideNavItem: ".".concat(prefix, "--side-nav__item"),
    selectorSideNavLink: ".".concat(prefix, "--side-nav__link"),
    selectorSideNavLinkCurrent: "[aria-current=\"page\"],.".concat(prefix, "--side-nav__link--current,.").concat(prefix, "--side-nav__item--active"),
    classSideNavExpanded: "".concat(prefix, "--side-nav--expanded"),
    classSideNavItemActive: "".concat(prefix, "--side-nav__item--active"),
    classSideNavLinkCurrent: "".concat(prefix, "--side-nav__link--current")
  };
  return SideNav;
}(Object(_globals_js_misc_mixin__WEBPACK_IMPORTED_MODULE_0__["default"])(_globals_js_mixins_create_component__WEBPACK_IMPORTED_MODULE_1__["default"], _globals_js_mixins_init_component_by_search__WEBPACK_IMPORTED_MODULE_3__["default"], _globals_js_mixins_handles__WEBPACK_IMPORTED_MODULE_4__["default"]));

/* harmony default export */ __webpack_exports__["default"] = (SideNav);

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/components.js":
/*!********************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/components.js ***!
  \********************************************************************/
/*! exports provided: Checkbox, FileUploader, ContentSwitcher, Tab, OverflowMenu, Modal, Loading, InlineLoading, Dropdown, NumberInput, DataTableV2, DataTable, DatePicker, Pagination, Search, Accordion, CopyButton, Notification, Toolbar, Tooltip, TooltipSimple, ProgressIndicator, FloatingMenu, StructuredList, Slider, Tile, CodeSnippet, TextInput, SideNav, HeaderSubmenu, HeaderNav, NavigationMenu, ProductSwitcher, PaginationNav */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _components_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../components/checkbox/checkbox */ "./node_modules/carbon-components/es/components/checkbox/checkbox.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Checkbox", function() { return _components_checkbox_checkbox__WEBPACK_IMPORTED_MODULE_0__["default"]; });

/* harmony import */ var _components_file_uploader_file_uploader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../components/file-uploader/file-uploader */ "./node_modules/carbon-components/es/components/file-uploader/file-uploader.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "FileUploader", function() { return _components_file_uploader_file_uploader__WEBPACK_IMPORTED_MODULE_1__["default"]; });

/* harmony import */ var _components_content_switcher_content_switcher__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/content-switcher/content-switcher */ "./node_modules/carbon-components/es/components/content-switcher/content-switcher.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ContentSwitcher", function() { return _components_content_switcher_content_switcher__WEBPACK_IMPORTED_MODULE_2__["default"]; });

/* harmony import */ var _components_tabs_tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../components/tabs/tabs */ "./node_modules/carbon-components/es/components/tabs/tabs.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Tab", function() { return _components_tabs_tabs__WEBPACK_IMPORTED_MODULE_3__["default"]; });

/* harmony import */ var _components_overflow_menu_overflow_menu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/overflow-menu/overflow-menu */ "./node_modules/carbon-components/es/components/overflow-menu/overflow-menu.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "OverflowMenu", function() { return _components_overflow_menu_overflow_menu__WEBPACK_IMPORTED_MODULE_4__["default"]; });

/* harmony import */ var _components_modal_modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/modal/modal */ "./node_modules/carbon-components/es/components/modal/modal.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Modal", function() { return _components_modal_modal__WEBPACK_IMPORTED_MODULE_5__["default"]; });

/* harmony import */ var _components_loading_loading__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/loading/loading */ "./node_modules/carbon-components/es/components/loading/loading.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Loading", function() { return _components_loading_loading__WEBPACK_IMPORTED_MODULE_6__["default"]; });

/* harmony import */ var _components_inline_loading_inline_loading__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/inline-loading/inline-loading */ "./node_modules/carbon-components/es/components/inline-loading/inline-loading.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InlineLoading", function() { return _components_inline_loading_inline_loading__WEBPACK_IMPORTED_MODULE_7__["default"]; });

/* harmony import */ var _components_dropdown_dropdown__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/dropdown/dropdown */ "./node_modules/carbon-components/es/components/dropdown/dropdown.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Dropdown", function() { return _components_dropdown_dropdown__WEBPACK_IMPORTED_MODULE_8__["default"]; });

/* harmony import */ var _components_number_input_number_input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../components/number-input/number-input */ "./node_modules/carbon-components/es/components/number-input/number-input.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "NumberInput", function() { return _components_number_input_number_input__WEBPACK_IMPORTED_MODULE_9__["default"]; });

/* harmony import */ var _components_data_table_v2_data_table_v2__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../components/data-table-v2/data-table-v2 */ "./node_modules/carbon-components/es/components/data-table-v2/data-table-v2.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DataTableV2", function() { return _components_data_table_v2_data_table_v2__WEBPACK_IMPORTED_MODULE_10__["default"]; });

/* harmony import */ var _components_data_table_data_table__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../components/data-table/data-table */ "./node_modules/carbon-components/es/components/data-table/data-table.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DataTable", function() { return _components_data_table_data_table__WEBPACK_IMPORTED_MODULE_11__["default"]; });

/* harmony import */ var _components_date_picker_date_picker__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../components/date-picker/date-picker */ "./node_modules/carbon-components/es/components/date-picker/date-picker.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DatePicker", function() { return _components_date_picker_date_picker__WEBPACK_IMPORTED_MODULE_12__["default"]; });

/* harmony import */ var _components_pagination_pagination__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../components/pagination/pagination */ "./node_modules/carbon-components/es/components/pagination/pagination.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Pagination", function() { return _components_pagination_pagination__WEBPACK_IMPORTED_MODULE_13__["default"]; });

/* harmony import */ var _components_search_search__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../components/search/search */ "./node_modules/carbon-components/es/components/search/search.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Search", function() { return _components_search_search__WEBPACK_IMPORTED_MODULE_14__["default"]; });

/* harmony import */ var _components_accordion_accordion__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../components/accordion/accordion */ "./node_modules/carbon-components/es/components/accordion/accordion.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Accordion", function() { return _components_accordion_accordion__WEBPACK_IMPORTED_MODULE_15__["default"]; });

/* harmony import */ var _components_copy_button_copy_button__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../../components/copy-button/copy-button */ "./node_modules/carbon-components/es/components/copy-button/copy-button.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CopyButton", function() { return _components_copy_button_copy_button__WEBPACK_IMPORTED_MODULE_16__["default"]; });

/* harmony import */ var _components_notification_notification__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../../components/notification/notification */ "./node_modules/carbon-components/es/components/notification/notification.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Notification", function() { return _components_notification_notification__WEBPACK_IMPORTED_MODULE_17__["default"]; });

/* harmony import */ var _components_toolbar_toolbar__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../../components/toolbar/toolbar */ "./node_modules/carbon-components/es/components/toolbar/toolbar.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Toolbar", function() { return _components_toolbar_toolbar__WEBPACK_IMPORTED_MODULE_18__["default"]; });

/* harmony import */ var _components_tooltip_tooltip__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../components/tooltip/tooltip */ "./node_modules/carbon-components/es/components/tooltip/tooltip.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Tooltip", function() { return _components_tooltip_tooltip__WEBPACK_IMPORTED_MODULE_19__["default"]; });

/* harmony import */ var _components_tooltip_tooltip_simple__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../components/tooltip/tooltip--simple */ "./node_modules/carbon-components/es/components/tooltip/tooltip--simple.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TooltipSimple", function() { return _components_tooltip_tooltip_simple__WEBPACK_IMPORTED_MODULE_20__["default"]; });

/* harmony import */ var _components_progress_indicator_progress_indicator__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../components/progress-indicator/progress-indicator */ "./node_modules/carbon-components/es/components/progress-indicator/progress-indicator.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ProgressIndicator", function() { return _components_progress_indicator_progress_indicator__WEBPACK_IMPORTED_MODULE_21__["default"]; });

/* harmony import */ var _components_floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../../components/floating-menu/floating-menu */ "./node_modules/carbon-components/es/components/floating-menu/floating-menu.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "FloatingMenu", function() { return _components_floating_menu_floating_menu__WEBPACK_IMPORTED_MODULE_22__["default"]; });

/* harmony import */ var _components_structured_list_structured_list__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../../components/structured-list/structured-list */ "./node_modules/carbon-components/es/components/structured-list/structured-list.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "StructuredList", function() { return _components_structured_list_structured_list__WEBPACK_IMPORTED_MODULE_23__["default"]; });

/* harmony import */ var _components_slider_slider__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../../components/slider/slider */ "./node_modules/carbon-components/es/components/slider/slider.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Slider", function() { return _components_slider_slider__WEBPACK_IMPORTED_MODULE_24__["default"]; });

/* harmony import */ var _components_tile_tile__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../../components/tile/tile */ "./node_modules/carbon-components/es/components/tile/tile.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Tile", function() { return _components_tile_tile__WEBPACK_IMPORTED_MODULE_25__["default"]; });

/* harmony import */ var _components_code_snippet_code_snippet__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../../components/code-snippet/code-snippet */ "./node_modules/carbon-components/es/components/code-snippet/code-snippet.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CodeSnippet", function() { return _components_code_snippet_code_snippet__WEBPACK_IMPORTED_MODULE_26__["default"]; });

/* harmony import */ var _components_text_input_text_input__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ../../components/text-input/text-input */ "./node_modules/carbon-components/es/components/text-input/text-input.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TextInput", function() { return _components_text_input_text_input__WEBPACK_IMPORTED_MODULE_27__["default"]; });

/* harmony import */ var _components_ui_shell_side_nav__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ../../components/ui-shell/side-nav */ "./node_modules/carbon-components/es/components/ui-shell/side-nav.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SideNav", function() { return _components_ui_shell_side_nav__WEBPACK_IMPORTED_MODULE_28__["default"]; });

/* harmony import */ var _components_ui_shell_header_submenu__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ../../components/ui-shell/header-submenu */ "./node_modules/carbon-components/es/components/ui-shell/header-submenu.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "HeaderSubmenu", function() { return _components_ui_shell_header_submenu__WEBPACK_IMPORTED_MODULE_29__["default"]; });

/* harmony import */ var _components_ui_shell_header_nav__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ../../components/ui-shell/header-nav */ "./node_modules/carbon-components/es/components/ui-shell/header-nav.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "HeaderNav", function() { return _components_ui_shell_header_nav__WEBPACK_IMPORTED_MODULE_30__["default"]; });

/* harmony import */ var _components_ui_shell_navigation_menu__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ../../components/ui-shell/navigation-menu */ "./node_modules/carbon-components/es/components/ui-shell/navigation-menu.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "NavigationMenu", function() { return _components_ui_shell_navigation_menu__WEBPACK_IMPORTED_MODULE_31__["default"]; });

/* harmony import */ var _components_ui_shell_product_switcher__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ../../components/ui-shell/product-switcher */ "./node_modules/carbon-components/es/components/ui-shell/product-switcher.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ProductSwitcher", function() { return _components_ui_shell_product_switcher__WEBPACK_IMPORTED_MODULE_32__["default"]; });

/* harmony import */ var _components_pagination_nav_pagination_nav__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ../../components/pagination-nav/pagination-nav */ "./node_modules/carbon-components/es/components/pagination-nav/pagination-nav.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "PaginationNav", function() { return _components_pagination_nav_pagination_nav__WEBPACK_IMPORTED_MODULE_33__["default"]; });

/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */



































/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js":
/*!****************************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/misc/event-matches.js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return eventMatches; });
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

/**
 * @param {Event} event The event.
 * @param {string} selector The selector.
 * @returns {Element}
 *   The closest ancestor of the event target (or the event target itself) which matches the selectors given in parameter.
 */
function eventMatches(event, selector) {
  // <svg> in IE does not have `Element#msMatchesSelector()` (that should be copied to `Element#matches()` by a polyfill).
  // Also a weird behavior is seen in IE where DOM tree seems broken when `event.target` is on <svg>.
  // Therefore this function simply returns `undefined` when `event.target` is on <svg>.
  var target = event.target,
      currentTarget = event.currentTarget;

  if (typeof target.matches === 'function') {
    if (target.matches(selector)) {
      // If event target itself matches the given selector, return it
      return target;
    }

    if (target.matches("".concat(selector, " *"))) {
      var closest = target.closest(selector);

      if ((currentTarget.nodeType === Node.DOCUMENT_NODE ? currentTarget.documentElement : currentTarget).contains(closest)) {
        return closest;
      }
    }
  }

  return undefined;
}

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/misc/get-launching-details.js":
/*!************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/misc/get-launching-details.js ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return getLaunchingDetails; });
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
function getLaunchingDetails(evt) {
  if (!evt || typeof evt === 'function') {
    return {
      launchingElement: null,
      launchingEvent: null
    };
  }

  var launchingElement = evt.delegateTarget || evt.currentTarget || evt;
  var launchingEvent = evt.currentTarget && evt;

  if (launchingElement && !launchingElement.nodeType) {
    throw new TypeError('DOM Node should be given for launching element.');
  }

  if (launchingEvent && !launchingEvent.type) {
    throw new TypeError('DOM event should be given for launching event.');
  }

  return {
    launchingElement: launchingElement,
    launchingEvent: launchingEvent
  };
}

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/misc/mixin.js":
/*!********************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/misc/mixin.js ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return mixin; });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

/**
 * @param {Array} a An array.
 * @returns {Array} The flattened version of the given array.
 */


function flatten(a) {
  return a.reduce(function (result, item) {
    if (Array.isArray(item)) {
      result.push.apply(result, _toConsumableArray(flatten(item)));
    } else {
      result.push(item);
    }

    return result;
  }, []);
}
/**
 * An interface for defining mix-in classes. Used with {@link mixin}.
 * @function mixinfn
 * @param {Class} ToMix The class to mix.
 * @returns {Class} The class mixed-in with the given ToMix class.
 */

/**
 * @function mixin
 * @param {...mixinfn} mixinfns The functions generating mix-ins.
 * @returns {Class} The class generated with the given mix-ins.
 */


function mixin() {
  for (var _len = arguments.length, mixinfns = new Array(_len), _key = 0; _key < _len; _key++) {
    mixinfns[_key] = arguments[_key];
  }

  return flatten(mixinfns).reduce(function (Class, mixinfn) {
    return mixinfn(Class);
  }, /*#__PURE__*/function () {
    function _class() {
      _classCallCheck(this, _class);
    }

    return _class;
  }());
}

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/misc/on-focus-by-keyboard.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/misc/on-focus-by-keyboard.js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return onFocusByKeyboard; });
/**
 * Differentiate between keyboard and mouse-triggered focusout/blur events
 * @param {Element} node  The element to attach event listeners to
 * @param {string} name The event name to listen to
 * @param {Function} callback The callback function to invoke
 * @returns {Handle} The handle to release the attached event handler
 */
function onFocusByKeyboard(node, name, callback) {
  var hasFocusout = ('onfocusout' in window);
  var focusinEventName = hasFocusout ? 'focusin' : 'focus';
  var focusoutEventName = hasFocusout ? 'focusout' : 'blur';
  /**
   * Event types supported by this function
   * @type {object<string, string>}
   */

  var supportedEvents = {
    focus: focusinEventName,
    blur: focusoutEventName
  };
  var eventName = supportedEvents[name];

  if (!eventName) {
    throw new Error('Unsupported event!');
  }

  var clicked;

  var handleMousedown = function handleMousedown() {
    clicked = true;
    requestAnimationFrame(function () {
      clicked = false;
    });
  };

  var handleFocusin = function handleFocusin(evt) {
    if (!clicked) {
      callback(evt);
    }
  };

  node.ownerDocument.addEventListener('mousedown', handleMousedown);
  node.addEventListener(eventName, handleFocusin, !hasFocusout);
  return {
    release: function release() {
      if (handleFocusin) {
        node.removeEventListener(eventName, handleFocusin, !hasFocusout);
        handleFocusin = null;
      }

      if (handleMousedown) {
        node.ownerDocument.removeEventListener('mousedown', handleMousedown);
        handleMousedown = null;
      }

      return null;
    }
  };
}

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/misc/on.js":
/*!*****************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/misc/on.js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return on; });
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
function on(element) {
  for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    args[_key - 1] = arguments[_key];
  }

  element.addEventListener.apply(element, args);
  return {
    release: function release() {
      element.removeEventListener.apply(element, args);
      return null;
    }
  };
}

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/misc/resize.js":
/*!*********************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/misc/resize.js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
// mdn resize function
var optimizedResize = /* #__PURE__ */function optimizedResize() {
  var callbacks = [];
  var running = false; // run the actual callbacks

  function runCallbacks() {
    callbacks.forEach(function (callback) {
      callback();
    });
    running = false;
  } // fired on resize event


  function resize() {
    if (!running) {
      running = true;
      window.requestAnimationFrame(runCallbacks);
    }
  } // adds callback to loop


  function addCallback(callback) {
    if (callback) {
      var index = callbacks.indexOf(callback);

      if (index < 0) {
        callbacks.push(callback);
      }
    }
  }

  return {
    // public method to add additional callback
    add: function add(callback) {
      if (!callbacks.length) {
        window.addEventListener('resize', resize);
      }

      addCallback(callback);
      return {
        release: function release() {
          var index = callbacks.indexOf(callback);

          if (index >= 0) {
            callbacks.splice(index, 1);
          }
        }
      };
    }
  };
}();

/* harmony default export */ __webpack_exports__["default"] = (optimizedResize);

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/misc/svg-toggle-class.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/misc/svg-toggle-class.js ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */


function svgToggleClass(svg, name, forceAdd) {
  var list = svg.getAttribute('class').trim().split(/\s+/);
  var uniqueList = Object.keys(list.reduce(function (o, item) {
    return Object.assign(o, _defineProperty({}, item, 1));
  }, {}));
  var index = uniqueList.indexOf(name);
  var found = index >= 0;
  var add = forceAdd === undefined ? !found : forceAdd;

  if (found === !add) {
    if (add) {
      uniqueList.push(name);
    } else {
      uniqueList.splice(index, 1);
    }

    svg.setAttribute('class', uniqueList.join(' '));
  }
}

/* harmony default export */ __webpack_exports__["default"] = (svgToggleClass);

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/misc/toggle-attribute.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/misc/toggle-attribute.js ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return toggleAttribute; });
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

/**
 * Toggles the given attribute of the given element.
 * @param {Element} elem The element.
 * @param {string} name The attribute name.
 * @param {boolean} add `true` to set the attribute.
 */
function toggleAttribute(elem, name, add) {
  if (add) {
    elem.setAttribute(name, '');
  } else {
    elem.removeAttribute(name);
  }
}

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/mixins/create-component.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/mixins/create-component.js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */


/* harmony default export */ __webpack_exports__["default"] = (function (ToMix) {
  var CreateComponent = /*#__PURE__*/function (_ToMix) {
    _inherits(CreateComponent, _ToMix);

    var _super = _createSuper(CreateComponent);
    /**
     * The component instances managed by this component.
     * Releasing this component also releases the components in `this.children`.
     * @type {Component[]}
     */

    /**
     * Mix-in class to manage lifecycle of component.
     * The constructor sets up this component's effective options,
     * and registers this component't instance associated to an element.
     * @implements Handle
     * @param {HTMLElement} element The element working as this component.
     * @param {object} [options] The component options.
     */


    function CreateComponent(element) {
      var _this;

      var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

      _classCallCheck(this, CreateComponent);

      _this = _super.call(this, element, options);
      _this.children = [];

      if (!element || element.nodeType !== Node.ELEMENT_NODE) {
        throw new TypeError('DOM element should be given to initialize this widget.');
      }
      /**
       * The element the component is of.
       * @type {Element}
       */


      _this.element = element;
      /**
       * The component options.
       * @type {object}
       */

      _this.options = Object.assign(Object.create(_this.constructor.options), options);

      _this.constructor.components.set(_this.element, _assertThisInitialized(_this));

      return _this;
    }
    /**
     * Instantiates this component of the given element.
     * @param {HTMLElement} element The element.
     */


    _createClass(CreateComponent, [{
      key: "release",

      /**
       * Releases this component's instance from the associated element.
       */
      value: function release() {
        for (var child = this.children.pop(); child; child = this.children.pop()) {
          child.release();
        }

        this.constructor.components.delete(this.element);
        return null;
      }
    }], [{
      key: "create",
      value: function create(element, options) {
        return this.components.get(element) || new this(element, options);
      }
    }]);

    return CreateComponent;
  }(ToMix);

  return CreateComponent;
});

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/mixins/evented-show-hide-state.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/mixins/evented-show-hide-state.js ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _evented_state__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./evented-state */ "./node_modules/carbon-components/es/globals/js/mixins/evented-state.js");
/* harmony import */ var _misc_get_launching_details__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../misc/get-launching-details */ "./node_modules/carbon-components/es/globals/js/misc/get-launching-details.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */





function eventedShowHideState(ToMix) {
  /**
   * Mix-in class to launch a floating menu.
   * @class EventedShowHideState
   */
  var EventedShowHideState = /*#__PURE__*/function (_ToMix) {
    _inherits(EventedShowHideState, _ToMix);

    var _super = _createSuper(EventedShowHideState);

    function EventedShowHideState() {
      _classCallCheck(this, EventedShowHideState);

      return _super.apply(this, arguments);
    }

    _createClass(EventedShowHideState, [{
      key: "show",

      /**
       */

      /**
       * Switch to 'shown' state.
       * @param [evtOrElem] The launching event or element.
       * @param {EventedState~changeStateCallback} [callback] The callback.
       */
      value: function show(evtOrElem, callback) {
        if (!evtOrElem || typeof evtOrElem === 'function') {
          callback = evtOrElem; // eslint-disable-line no-param-reassign
        }

        this.changeState('shown', Object(_misc_get_launching_details__WEBPACK_IMPORTED_MODULE_1__["default"])(evtOrElem), callback);
      }
      /**
       * Switch to 'hidden' state.
       * @param [evtOrElem] The launching event or element.
       * @param {EventedState~changeStateCallback} [callback] The callback.
       */

    }, {
      key: "hide",
      value: function hide(evtOrElem, callback) {
        if (!evtOrElem || typeof evtOrElem === 'function') {
          callback = evtOrElem; // eslint-disable-line no-param-reassign
        }

        this.changeState('hidden', Object(_misc_get_launching_details__WEBPACK_IMPORTED_MODULE_1__["default"])(evtOrElem), callback);
      }
    }]);

    return EventedShowHideState;
  }(ToMix);

  return EventedShowHideState;
}

var exports = [_evented_state__WEBPACK_IMPORTED_MODULE_0__["default"], eventedShowHideState];
/* harmony default export */ __webpack_exports__["default"] = (exports);

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/mixins/evented-state.js":
/*!******************************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/mixins/evented-state.js ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */


/* harmony default export */ __webpack_exports__["default"] = (function (ToMix) {
  /**
   * Mix-in class to manage events associated with states.
   * @class EventedState
   */
  var EventedState = /*#__PURE__*/function (_ToMix) {
    _inherits(EventedState, _ToMix);

    var _super = _createSuper(EventedState);

    function EventedState() {
      _classCallCheck(this, EventedState);

      return _super.apply(this, arguments);
    }

    _createClass(EventedState, [{
      key: "_changeState",

      /* eslint-disable jsdoc/check-param-names */

      /**
       * The internal implementation for {@link EventedState#changeState `.changeState()`}, performing actual change in state.
       * @param {string} [state] The new state. Can be an omitted, which means toggling.
       * @param {object} [detail]
       *   The object that should be put to event details that is fired before/after changing state.
       *   Can have a `group` property, which specifies what state to be changed.
       * @param {EventedState~changeStateCallback} callback The callback called once changing state is finished or is canceled.
       * @private
       */
      value: function _changeState() {
        throw new Error('_changeState() should be overriden to perform actual change in state.');
      }
      /**
       * Changes the state of this component.
       * @param {string} [state] The new state. Can be an omitted, which means toggling.
       * @param {object} [detail]
       *   The object that should be put to event details that is fired before/after changing state.
       *   Can have a `group` property, which specifies what state to be changed.
       * @param {EventedState~changeStateCallback} [callback] The callback called once changing state is finished or is canceled.
       */

    }, {
      key: "changeState",
      value: function changeState() {
        var _this = this;

        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }

        var state = typeof args[0] === 'string' ? args.shift() : undefined;
        var detail = Object(args[0]) === args[0] && typeof args[0] !== 'function' ? args.shift() : undefined;
        var callback = typeof args[0] === 'function' ? args.shift() : undefined;

        if (typeof this.shouldStateBeChanged === 'function' && !this.shouldStateBeChanged(state, detail)) {
          if (callback) {
            callback(null, true);
          }

          return;
        }

        var data = {
          group: detail && detail.group,
          state: state
        };
        var eventNameSuffix = [data.group, state].filter(Boolean).join('-').split('-') // Group or state may contain hyphen
        .map(function (item) {
          return item[0].toUpperCase() + item.substr(1);
        }).join('');
        var eventStart = new CustomEvent(this.options["eventBefore".concat(eventNameSuffix)], {
          bubbles: true,
          cancelable: true,
          detail: detail
        });
        var fireOnNode = detail && detail.delegatorNode || this.element;
        var canceled = !fireOnNode.dispatchEvent(eventStart);

        if (canceled) {
          if (callback) {
            var error = new Error("Changing state (".concat(JSON.stringify(data), ") has been canceled."));
            error.canceled = true;
            callback(error);
          }
        } else {
          var changeStateArgs = [state, detail].filter(Boolean);

          this._changeState.apply(this, _toConsumableArray(changeStateArgs).concat([function () {
            fireOnNode.dispatchEvent(new CustomEvent(_this.options["eventAfter".concat(eventNameSuffix)], {
              bubbles: true,
              cancelable: true,
              detail: detail
            }));

            if (callback) {
              callback();
            }
          }]));
        }
      }
      /* eslint-enable jsdoc/check-param-names */

      /**
       * Tests if change in state should happen or not.
       * Classes inheriting {@link EventedState `EventedState`} should override this function.
       * @function EventedState#shouldStateBeChanged
       * @param {string} [state] The new state. Can be an omitted, which means toggling.
       * @param {object} [detail]
       *   The object that should be put to event details that is fired before/after changing state.
       *   Can have a `group` property, which specifies what state to be changed.
       * @returns {boolean}
       *   `false` if change in state shouldn't happen, e.g. when the given new state is the same as the current one.
       */

    }]);

    return EventedState;
  }(ToMix);
  /**
   * The callback called once changing state is finished or is canceled.
   * @callback EventedState~changeStateCallback
   * @param {Error} error
   *   An error object with `true` in its `canceled` property if changing state is canceled.
   *   Cancellation happens if the handler of a custom event, that is fired before changing state happens,
   *   calls `.preventDefault()` against the event.
   * @param {boolean} keptState
   *   `true` if the call to {@link EventedState#changeState `.changeState()`} didn't cause actual change in state.
   */


  return EventedState;
});

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/mixins/handles.js":
/*!************************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/mixins/handles.js ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _get(target, property, receiver) {
  if (typeof Reflect !== "undefined" && Reflect.get) {
    _get = Reflect.get;
  } else {
    _get = function _get(target, property, receiver) {
      var base = _superPropBase(target, property);

      if (!base) return;
      var desc = Object.getOwnPropertyDescriptor(base, property);

      if (desc.get) {
        return desc.get.call(receiver);
      }

      return desc.value;
    };
  }

  return _get(target, property, receiver || target);
}

function _superPropBase(object, property) {
  while (!Object.prototype.hasOwnProperty.call(object, property)) {
    object = _getPrototypeOf(object);
    if (object === null) break;
  }

  return object;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */


/* harmony default export */ __webpack_exports__["default"] = (function (ToMix) {
  /**
   * Mix-in class to manage handles in component.
   * Managed handles are automatically released when the component with this class mixed in is released.
   * @class Handles
   * @implements Handle
   */
  var Handles = /*#__PURE__*/function (_ToMix) {
    _inherits(Handles, _ToMix);

    var _super = _createSuper(Handles);

    function Handles() {
      var _this;

      _classCallCheck(this, Handles);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = _super.call.apply(_super, [this].concat(args));
      _this.handles = new Set();
      return _this;
    }

    _createClass(Handles, [{
      key: "manage",

      /**
       * Manages the given handle.
       * @param {Handle} handle The handle to manage.
       * @returns {Handle} The given handle.
       */
      value: function manage(handle) {
        this.handles.add(handle);
        return handle;
      }
      /**
       * Stop managing the given handle.
       * @param {Handle} handle The handle to stop managing.
       * @returns {Handle} The given handle.
       */

    }, {
      key: "unmanage",
      value: function unmanage(handle) {
        this.handles.delete(handle);
        return handle;
      }
    }, {
      key: "release",
      value: function release() {
        var _this2 = this;

        this.handles.forEach(function (handle) {
          handle.release();

          _this2.handles.delete(handle);
        });
        return _get(_getPrototypeOf(Handles.prototype), "release", this).call(this);
      }
    }]);

    return Handles;
  }(ToMix);

  return Handles;
});

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-event.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/mixins/init-component-by-event.js ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _misc_event_matches__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _misc_on__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */




/* harmony default export */ __webpack_exports__["default"] = (function (ToMix) {
  /**
   * Mix-in class to instantiate components upon events.
   * @class InitComponentByEvent
   */
  var InitComponentByEvent = /*#__PURE__*/function (_ToMix) {
    _inherits(InitComponentByEvent, _ToMix);

    var _super = _createSuper(InitComponentByEvent);

    function InitComponentByEvent() {
      _classCallCheck(this, InitComponentByEvent);

      return _super.apply(this, arguments);
    }

    _createClass(InitComponentByEvent, null, [{
      key: "init",

      /**
       * `true` suggests that this component is lazily initialized upon an action/event, etc.
       * @type {boolean}
       */

      /**
       * Instantiates this component in the given element.
       * If the given element indicates that it's an component of this class, instantiates it.
       * Otherwise, instantiates this component by clicking on this component in the given node.
       * @param {Node} target The DOM node to instantiate this component in. Should be a document or an element.
       * @param {object} [options] The component options.
       * @param {string} [options.selectorInit] The CSS selector to find this component.
       * @returns {Handle} The handle to remove the event listener to handle clicking.
       */
      value: function init() {
        var _this = this;

        var target = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : document;
        var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
        var effectiveOptions = Object.assign(Object.create(this.options), options);

        if (!target || target.nodeType !== Node.ELEMENT_NODE && target.nodeType !== Node.DOCUMENT_NODE) {
          throw new TypeError('DOM document or DOM element should be given to search for and initialize this widget.');
        }

        if (target.nodeType === Node.ELEMENT_NODE && target.matches(effectiveOptions.selectorInit)) {
          this.create(target, options);
        } else {
          // To work around non-bubbling `focus` event, use `focusin` event instead of it's available, and "capture mode" otherwise
          var hasFocusin = ('onfocusin' in (target.nodeType === Node.ELEMENT_NODE ? target.ownerDocument : target).defaultView);
          var handles = effectiveOptions.initEventNames.map(function (name) {
            var eventName = name === 'focus' && hasFocusin ? 'focusin' : name;
            return Object(_misc_on__WEBPACK_IMPORTED_MODULE_1__["default"])(target, eventName, function (event) {
              var element = Object(_misc_event_matches__WEBPACK_IMPORTED_MODULE_0__["default"])(event, effectiveOptions.selectorInit); // Instantiated components handles events by themselves

              if (element && !_this.components.has(element)) {
                var component = _this.create(element, options);

                if (typeof component.createdByEvent === 'function') {
                  component.createdByEvent(event);
                }
              }
            }, name === 'focus' && !hasFocusin);
          });
          return {
            release: function release() {
              for (var handle = handles.pop(); handle; handle = handles.pop()) {
                handle.release();
              }
            }
          };
        }

        return '';
      }
    }]);

    InitComponentByEvent.forLazyInit = true;
    return InitComponentByEvent;
  }(ToMix);

  return InitComponentByEvent;
});

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-launcher.js":
/*!*******************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/mixins/init-component-by-launcher.js ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _misc_event_matches__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../misc/event-matches */ "./node_modules/carbon-components/es/globals/js/misc/event-matches.js");
/* harmony import */ var _misc_on__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */




/* harmony default export */ __webpack_exports__["default"] = (function (ToMix) {
  /**
   * Mix-in class to instantiate components events on launcher button.
   * @class InitComponentByLauncher
   */
  var InitComponentByLauncher = /*#__PURE__*/function (_ToMix) {
    _inherits(InitComponentByLauncher, _ToMix);

    var _super = _createSuper(InitComponentByLauncher);

    function InitComponentByLauncher() {
      _classCallCheck(this, InitComponentByLauncher);

      return _super.apply(this, arguments);
    }

    _createClass(InitComponentByLauncher, null, [{
      key: "init",

      /**
       * `true` suggests that this component is lazily initialized upon an action/event, etc.
       * @type {boolean}
       */

      /**
       * Instantiates this component in the given element.
       * If the given element indicates that it's an component of this class, instantiates it.
       * Otherwise, instantiates this component by clicking on launcher buttons
       * (buttons with attribute that `options.attribInitTarget` points to) of this component in the given node.
       * @param {Node} target The DOM node to instantiate this component in. Should be a document or an element.
       * @param {object} [options] The component options.
       * @param {string} [options.selectorInit] The CSS selector to find this component.
       * @param {string} [options.attribInitTarget] The attribute name in the launcher buttons to find target component.
       * @returns {Handle} The handle to remove the event listener to handle clicking.
       */
      value: function init() {
        var _this = this;

        var target = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : document;
        var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
        var effectiveOptions = Object.assign(Object.create(this.options), options);

        if (!target || target.nodeType !== Node.ELEMENT_NODE && target.nodeType !== Node.DOCUMENT_NODE) {
          throw new TypeError('DOM document or DOM element should be given to search for and initialize this widget.');
        }

        if (target.nodeType === Node.ELEMENT_NODE && target.matches(effectiveOptions.selectorInit)) {
          this.create(target, options);
        } else {
          var handles = effectiveOptions.initEventNames.map(function (name) {
            return Object(_misc_on__WEBPACK_IMPORTED_MODULE_1__["default"])(target, name, function (event) {
              var launcher = Object(_misc_event_matches__WEBPACK_IMPORTED_MODULE_0__["default"])(event, "[".concat(effectiveOptions.attribInitTarget, "]"));

              if (launcher) {
                event.delegateTarget = launcher; // eslint-disable-line no-param-reassign

                var elements = launcher.ownerDocument.querySelectorAll(launcher.getAttribute(effectiveOptions.attribInitTarget));

                if (elements.length > 1) {
                  throw new Error('Target widget must be unique.');
                }

                if (elements.length === 1) {
                  if (launcher.tagName === 'A') {
                    event.preventDefault();
                  }

                  var component = _this.create(elements[0], options);

                  if (typeof component.createdByLauncher === 'function') {
                    component.createdByLauncher(event);
                  }
                }
              }
            });
          });
          return {
            release: function release() {
              for (var handle = handles.pop(); handle; handle = handles.pop()) {
                handle.release();
              }
            }
          };
        }

        return '';
      }
    }]);

    InitComponentByLauncher.forLazyInit = true;
    return InitComponentByLauncher;
  }(ToMix);

  return InitComponentByLauncher;
});

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js":
/*!*****************************************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/mixins/init-component-by-search.js ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */


/* harmony default export */ __webpack_exports__["default"] = (function (ToMix) {
  /**
   * Mix-in class to instantiate components by searching for their root elements.
   * @class InitComponentBySearch
   */
  var InitComponentBySearch = /*#__PURE__*/function (_ToMix) {
    _inherits(InitComponentBySearch, _ToMix);

    var _super = _createSuper(InitComponentBySearch);

    function InitComponentBySearch() {
      _classCallCheck(this, InitComponentBySearch);

      return _super.apply(this, arguments);
    }

    _createClass(InitComponentBySearch, null, [{
      key: "init",

      /**
       * Instantiates component in the given node.
       * If the given element indicates that it's an component of this class, instantiates it.
       * Otherwise, instantiates components by searching for components in the given node.
       * @param {Node} target The DOM node to instantiate components in. Should be a document or an element.
       * @param {object} [options] The component options.
       * @param {boolean} [options.selectorInit] The CSS selector to find components.
       */
      value: function init() {
        var _this = this;

        var target = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : document;
        var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
        var effectiveOptions = Object.assign(Object.create(this.options), options);

        if (!target || target.nodeType !== Node.ELEMENT_NODE && target.nodeType !== Node.DOCUMENT_NODE) {
          throw new TypeError('DOM document or DOM element should be given to search for and initialize this widget.');
        }

        if (target.nodeType === Node.ELEMENT_NODE && target.matches(effectiveOptions.selectorInit)) {
          this.create(target, options);
        } else {
          Array.prototype.forEach.call(target.querySelectorAll(effectiveOptions.selectorInit), function (element) {
            return _this.create(element, options);
          });
        }
      }
    }]);

    return InitComponentBySearch;
  }(ToMix);

  return InitComponentBySearch;
});

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/mixins/track-blur.js":
/*!***************************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/mixins/track-blur.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _misc_on__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../misc/on */ "./node_modules/carbon-components/es/globals/js/misc/on.js");
/* harmony import */ var _handles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./handles */ "./node_modules/carbon-components/es/globals/js/mixins/handles.js");
function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */





function trackBlur(ToMix) {
  var TrackBlur = /*#__PURE__*/function (_ToMix) {
    _inherits(TrackBlur, _ToMix);

    var _super = _createSuper(TrackBlur);
    /**
     * Mix-in class to add an handler for losing focus.
     * @extends Handles
     * @param {HTMLElement} element The element working as this component.
     * @param {object} [options] The component options.
     */


    function TrackBlur(element, options) {
      var _this;

      _classCallCheck(this, TrackBlur);

      _this = _super.call(this, element, options);
      var hasFocusin = ('onfocusin' in window);
      var focusinEventName = hasFocusin ? 'focusin' : 'focus';
      var focusoutEventName = hasFocusin ? 'focusout' : 'blur';

      _this.manage(Object(_misc_on__WEBPACK_IMPORTED_MODULE_0__["default"])(_this.element.ownerDocument, focusinEventName, function (event) {
        if (!(_this.options.contentNode || _this.element).contains(event.target)) {
          _this.handleBlur(event);
        }
      }, !hasFocusin));

      _this.manage(Object(_misc_on__WEBPACK_IMPORTED_MODULE_0__["default"])(_this.element.ownerDocument, focusoutEventName, function (event) {
        if (!event.relatedTarget) {
          _this.handleBlur(event);
        }
      }, !hasFocusin));

      return _this;
    }
    /**
     * The method called when this component loses focus.
     * @abstract
     */


    _createClass(TrackBlur, [{
      key: "handleBlur",
      value: function handleBlur() {
        throw new Error('Components inheriting TrackBlur mix-in must implement handleBlur() method.');
      }
    }]);

    return TrackBlur;
  }(ToMix);

  return TrackBlur;
}

var exports = [_handles__WEBPACK_IMPORTED_MODULE_1__["default"], trackBlur];
/* harmony default export */ __webpack_exports__["default"] = (exports);

/***/ }),

/***/ "./node_modules/carbon-components/es/globals/js/settings.js":
/*!******************************************************************!*\
  !*** ./node_modules/carbon-components/es/globals/js/settings.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */

/**
 * Settings.
 * @exports CarbonComponents.settings
 * @type Object
 * @property {boolean} [disableAutoInit]
 *   Disables automatic instantiation of components.
 *   By default (`CarbonComponents.disableAutoInit` is `false`),
 *   carbon-components attempts to instantiate components automatically
 *   by searching for elements with `data-component-name` (e.g. `data-loading`) attribute
 *   or upon DOM events (e.g. clicking) on such elements.
 *   See each components' static `.init()` methods for details.
 * @property {string} [prefix=bx]
 *   Brand prefix. Should be in sync with `$prefix` Sass variable in carbon-components/src/globals/scss/_vars.scss.
 * // @todo given that the default value is so long, is it appropriate to put in the JSDoc?
 * @property {string} [selectorTabbable]
 *   A selector selecting tabbable/focusable nodes.
 *   By default selectorTabbable references links, areas, inputs, buttons, selects, textareas,
 *   iframes, objects, embeds, or elements explicitly using tabindex or contenteditable attributes
 *   as long as the element is not `disabled` or the `tabindex="-1"`.
 * @property {string} [selectorFocusable]
 *   CSS selector that selects major nodes that are click focusable
 *   This property is identical to selectorTabbable with the exception of
 *   the `:not([tabindex='-1'])` pseudo class
 */
var settings = {
  prefix: 'bx',
  selectorTabbable: "\n    a[href], area[href], input:not([disabled]):not([tabindex='-1']),\n    button:not([disabled]):not([tabindex='-1']),select:not([disabled]):not([tabindex='-1']),\n    textarea:not([disabled]):not([tabindex='-1']),\n    iframe, object, embed, *[tabindex]:not([tabindex='-1']), *[contenteditable=true]\n  ",
  selectorFocusable: "\n    a[href], area[href], input:not([disabled]),\n    button:not([disabled]),select:not([disabled]),\n    textarea:not([disabled]),\n    iframe, object, embed, *[tabindex], *[contenteditable=true]\n  "
};
var settings_1 = settings;
/* harmony default export */ __webpack_exports__["default"] = (settings_1);

/***/ }),

/***/ "./node_modules/carbon-components/es/index.js":
/*!****************************************************!*\
  !*** ./node_modules/carbon-components/es/index.js ***!
  \****************************************************/
/*! exports provided: Checkbox, FileUploader, ContentSwitcher, Tab, OverflowMenu, Modal, Loading, InlineLoading, Dropdown, NumberInput, DataTableV2, DataTable, DatePicker, Pagination, Search, Accordion, CopyButton, Notification, Toolbar, Tooltip, TooltipSimple, ProgressIndicator, FloatingMenu, StructuredList, Slider, Tile, CodeSnippet, TextInput, SideNav, HeaderSubmenu, HeaderNav, NavigationMenu, ProductSwitcher, PaginationNav, settings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _globals_js_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./globals/js/components */ "./node_modules/carbon-components/es/globals/js/components.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Checkbox", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["Checkbox"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "FileUploader", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["FileUploader"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ContentSwitcher", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["ContentSwitcher"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Tab", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["Tab"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "OverflowMenu", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["OverflowMenu"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Modal", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["Modal"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Loading", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["Loading"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InlineLoading", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["InlineLoading"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Dropdown", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["Dropdown"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "NumberInput", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["NumberInput"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DataTableV2", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["DataTableV2"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DataTable", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["DataTable"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DatePicker", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["DatePicker"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Pagination", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["Pagination"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Search", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["Search"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Accordion", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["Accordion"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CopyButton", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["CopyButton"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Notification", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["Notification"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Toolbar", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["Toolbar"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Tooltip", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["Tooltip"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TooltipSimple", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["TooltipSimple"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ProgressIndicator", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["ProgressIndicator"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "FloatingMenu", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["FloatingMenu"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "StructuredList", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["StructuredList"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Slider", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["Slider"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Tile", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["Tile"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CodeSnippet", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["CodeSnippet"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "TextInput", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["TextInput"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SideNav", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["SideNav"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "HeaderSubmenu", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["HeaderSubmenu"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "HeaderNav", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["HeaderNav"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "NavigationMenu", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["NavigationMenu"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ProductSwitcher", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["ProductSwitcher"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "PaginationNav", function() { return _globals_js_components__WEBPACK_IMPORTED_MODULE_0__["PaginationNav"]; });

/* harmony import */ var _globals_js_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./globals/js/settings */ "./node_modules/carbon-components/es/globals/js/settings.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "settings", function() { return _globals_js_settings__WEBPACK_IMPORTED_MODULE_1__["default"]; });

/**
 * Copyright IBM Corp. 2016, 2018
 *
 * This source code is licensed under the Apache-2.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
// ====================//
// Imports and Exports //
// ====================//
// Base Elements & Components
// -------------
// - JavaScript classes for use with components and base-elements.
// - The following statements import classes from actual locations to
//   be consumed from this file instead of their actual locations.



/***/ }),

/***/ "./node_modules/color-convert/conversions.js":
/*!***************************************************!*\
  !*** ./node_modules/color-convert/conversions.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* MIT license */
var cssKeywords = __webpack_require__(/*! color-name */ "./node_modules/color-name/index.js");

// NOTE: conversions should only return primitive values (i.e. arrays, or
//       values that give correct `typeof` results).
//       do not use box values types (i.e. Number(), String(), etc.)

var reverseKeywords = {};
for (var key in cssKeywords) {
	if (cssKeywords.hasOwnProperty(key)) {
		reverseKeywords[cssKeywords[key]] = key;
	}
}

var convert = module.exports = {
	rgb: {channels: 3, labels: 'rgb'},
	hsl: {channels: 3, labels: 'hsl'},
	hsv: {channels: 3, labels: 'hsv'},
	hwb: {channels: 3, labels: 'hwb'},
	cmyk: {channels: 4, labels: 'cmyk'},
	xyz: {channels: 3, labels: 'xyz'},
	lab: {channels: 3, labels: 'lab'},
	lch: {channels: 3, labels: 'lch'},
	hex: {channels: 1, labels: ['hex']},
	keyword: {channels: 1, labels: ['keyword']},
	ansi16: {channels: 1, labels: ['ansi16']},
	ansi256: {channels: 1, labels: ['ansi256']},
	hcg: {channels: 3, labels: ['h', 'c', 'g']},
	apple: {channels: 3, labels: ['r16', 'g16', 'b16']},
	gray: {channels: 1, labels: ['gray']}
};

// hide .channels and .labels properties
for (var model in convert) {
	if (convert.hasOwnProperty(model)) {
		if (!('channels' in convert[model])) {
			throw new Error('missing channels property: ' + model);
		}

		if (!('labels' in convert[model])) {
			throw new Error('missing channel labels property: ' + model);
		}

		if (convert[model].labels.length !== convert[model].channels) {
			throw new Error('channel and label counts mismatch: ' + model);
		}

		var channels = convert[model].channels;
		var labels = convert[model].labels;
		delete convert[model].channels;
		delete convert[model].labels;
		Object.defineProperty(convert[model], 'channels', {value: channels});
		Object.defineProperty(convert[model], 'labels', {value: labels});
	}
}

convert.rgb.hsl = function (rgb) {
	var r = rgb[0] / 255;
	var g = rgb[1] / 255;
	var b = rgb[2] / 255;
	var min = Math.min(r, g, b);
	var max = Math.max(r, g, b);
	var delta = max - min;
	var h;
	var s;
	var l;

	if (max === min) {
		h = 0;
	} else if (r === max) {
		h = (g - b) / delta;
	} else if (g === max) {
		h = 2 + (b - r) / delta;
	} else if (b === max) {
		h = 4 + (r - g) / delta;
	}

	h = Math.min(h * 60, 360);

	if (h < 0) {
		h += 360;
	}

	l = (min + max) / 2;

	if (max === min) {
		s = 0;
	} else if (l <= 0.5) {
		s = delta / (max + min);
	} else {
		s = delta / (2 - max - min);
	}

	return [h, s * 100, l * 100];
};

convert.rgb.hsv = function (rgb) {
	var rdif;
	var gdif;
	var bdif;
	var h;
	var s;

	var r = rgb[0] / 255;
	var g = rgb[1] / 255;
	var b = rgb[2] / 255;
	var v = Math.max(r, g, b);
	var diff = v - Math.min(r, g, b);
	var diffc = function (c) {
		return (v - c) / 6 / diff + 1 / 2;
	};

	if (diff === 0) {
		h = s = 0;
	} else {
		s = diff / v;
		rdif = diffc(r);
		gdif = diffc(g);
		bdif = diffc(b);

		if (r === v) {
			h = bdif - gdif;
		} else if (g === v) {
			h = (1 / 3) + rdif - bdif;
		} else if (b === v) {
			h = (2 / 3) + gdif - rdif;
		}
		if (h < 0) {
			h += 1;
		} else if (h > 1) {
			h -= 1;
		}
	}

	return [
		h * 360,
		s * 100,
		v * 100
	];
};

convert.rgb.hwb = function (rgb) {
	var r = rgb[0];
	var g = rgb[1];
	var b = rgb[2];
	var h = convert.rgb.hsl(rgb)[0];
	var w = 1 / 255 * Math.min(r, Math.min(g, b));

	b = 1 - 1 / 255 * Math.max(r, Math.max(g, b));

	return [h, w * 100, b * 100];
};

convert.rgb.cmyk = function (rgb) {
	var r = rgb[0] / 255;
	var g = rgb[1] / 255;
	var b = rgb[2] / 255;
	var c;
	var m;
	var y;
	var k;

	k = Math.min(1 - r, 1 - g, 1 - b);
	c = (1 - r - k) / (1 - k) || 0;
	m = (1 - g - k) / (1 - k) || 0;
	y = (1 - b - k) / (1 - k) || 0;

	return [c * 100, m * 100, y * 100, k * 100];
};

/**
 * See https://en.m.wikipedia.org/wiki/Euclidean_distance#Squared_Euclidean_distance
 * */
function comparativeDistance(x, y) {
	return (
		Math.pow(x[0] - y[0], 2) +
		Math.pow(x[1] - y[1], 2) +
		Math.pow(x[2] - y[2], 2)
	);
}

convert.rgb.keyword = function (rgb) {
	var reversed = reverseKeywords[rgb];
	if (reversed) {
		return reversed;
	}

	var currentClosestDistance = Infinity;
	var currentClosestKeyword;

	for (var keyword in cssKeywords) {
		if (cssKeywords.hasOwnProperty(keyword)) {
			var value = cssKeywords[keyword];

			// Compute comparative distance
			var distance = comparativeDistance(rgb, value);

			// Check if its less, if so set as closest
			if (distance < currentClosestDistance) {
				currentClosestDistance = distance;
				currentClosestKeyword = keyword;
			}
		}
	}

	return currentClosestKeyword;
};

convert.keyword.rgb = function (keyword) {
	return cssKeywords[keyword];
};

convert.rgb.xyz = function (rgb) {
	var r = rgb[0] / 255;
	var g = rgb[1] / 255;
	var b = rgb[2] / 255;

	// assume sRGB
	r = r > 0.04045 ? Math.pow(((r + 0.055) / 1.055), 2.4) : (r / 12.92);
	g = g > 0.04045 ? Math.pow(((g + 0.055) / 1.055), 2.4) : (g / 12.92);
	b = b > 0.04045 ? Math.pow(((b + 0.055) / 1.055), 2.4) : (b / 12.92);

	var x = (r * 0.4124) + (g * 0.3576) + (b * 0.1805);
	var y = (r * 0.2126) + (g * 0.7152) + (b * 0.0722);
	var z = (r * 0.0193) + (g * 0.1192) + (b * 0.9505);

	return [x * 100, y * 100, z * 100];
};

convert.rgb.lab = function (rgb) {
	var xyz = convert.rgb.xyz(rgb);
	var x = xyz[0];
	var y = xyz[1];
	var z = xyz[2];
	var l;
	var a;
	var b;

	x /= 95.047;
	y /= 100;
	z /= 108.883;

	x = x > 0.008856 ? Math.pow(x, 1 / 3) : (7.787 * x) + (16 / 116);
	y = y > 0.008856 ? Math.pow(y, 1 / 3) : (7.787 * y) + (16 / 116);
	z = z > 0.008856 ? Math.pow(z, 1 / 3) : (7.787 * z) + (16 / 116);

	l = (116 * y) - 16;
	a = 500 * (x - y);
	b = 200 * (y - z);

	return [l, a, b];
};

convert.hsl.rgb = function (hsl) {
	var h = hsl[0] / 360;
	var s = hsl[1] / 100;
	var l = hsl[2] / 100;
	var t1;
	var t2;
	var t3;
	var rgb;
	var val;

	if (s === 0) {
		val = l * 255;
		return [val, val, val];
	}

	if (l < 0.5) {
		t2 = l * (1 + s);
	} else {
		t2 = l + s - l * s;
	}

	t1 = 2 * l - t2;

	rgb = [0, 0, 0];
	for (var i = 0; i < 3; i++) {
		t3 = h + 1 / 3 * -(i - 1);
		if (t3 < 0) {
			t3++;
		}
		if (t3 > 1) {
			t3--;
		}

		if (6 * t3 < 1) {
			val = t1 + (t2 - t1) * 6 * t3;
		} else if (2 * t3 < 1) {
			val = t2;
		} else if (3 * t3 < 2) {
			val = t1 + (t2 - t1) * (2 / 3 - t3) * 6;
		} else {
			val = t1;
		}

		rgb[i] = val * 255;
	}

	return rgb;
};

convert.hsl.hsv = function (hsl) {
	var h = hsl[0];
	var s = hsl[1] / 100;
	var l = hsl[2] / 100;
	var smin = s;
	var lmin = Math.max(l, 0.01);
	var sv;
	var v;

	l *= 2;
	s *= (l <= 1) ? l : 2 - l;
	smin *= lmin <= 1 ? lmin : 2 - lmin;
	v = (l + s) / 2;
	sv = l === 0 ? (2 * smin) / (lmin + smin) : (2 * s) / (l + s);

	return [h, sv * 100, v * 100];
};

convert.hsv.rgb = function (hsv) {
	var h = hsv[0] / 60;
	var s = hsv[1] / 100;
	var v = hsv[2] / 100;
	var hi = Math.floor(h) % 6;

	var f = h - Math.floor(h);
	var p = 255 * v * (1 - s);
	var q = 255 * v * (1 - (s * f));
	var t = 255 * v * (1 - (s * (1 - f)));
	v *= 255;

	switch (hi) {
		case 0:
			return [v, t, p];
		case 1:
			return [q, v, p];
		case 2:
			return [p, v, t];
		case 3:
			return [p, q, v];
		case 4:
			return [t, p, v];
		case 5:
			return [v, p, q];
	}
};

convert.hsv.hsl = function (hsv) {
	var h = hsv[0];
	var s = hsv[1] / 100;
	var v = hsv[2] / 100;
	var vmin = Math.max(v, 0.01);
	var lmin;
	var sl;
	var l;

	l = (2 - s) * v;
	lmin = (2 - s) * vmin;
	sl = s * vmin;
	sl /= (lmin <= 1) ? lmin : 2 - lmin;
	sl = sl || 0;
	l /= 2;

	return [h, sl * 100, l * 100];
};

// http://dev.w3.org/csswg/css-color/#hwb-to-rgb
convert.hwb.rgb = function (hwb) {
	var h = hwb[0] / 360;
	var wh = hwb[1] / 100;
	var bl = hwb[2] / 100;
	var ratio = wh + bl;
	var i;
	var v;
	var f;
	var n;

	// wh + bl cant be > 1
	if (ratio > 1) {
		wh /= ratio;
		bl /= ratio;
	}

	i = Math.floor(6 * h);
	v = 1 - bl;
	f = 6 * h - i;

	if ((i & 0x01) !== 0) {
		f = 1 - f;
	}

	n = wh + f * (v - wh); // linear interpolation

	var r;
	var g;
	var b;
	switch (i) {
		default:
		case 6:
		case 0: r = v; g = n; b = wh; break;
		case 1: r = n; g = v; b = wh; break;
		case 2: r = wh; g = v; b = n; break;
		case 3: r = wh; g = n; b = v; break;
		case 4: r = n; g = wh; b = v; break;
		case 5: r = v; g = wh; b = n; break;
	}

	return [r * 255, g * 255, b * 255];
};

convert.cmyk.rgb = function (cmyk) {
	var c = cmyk[0] / 100;
	var m = cmyk[1] / 100;
	var y = cmyk[2] / 100;
	var k = cmyk[3] / 100;
	var r;
	var g;
	var b;

	r = 1 - Math.min(1, c * (1 - k) + k);
	g = 1 - Math.min(1, m * (1 - k) + k);
	b = 1 - Math.min(1, y * (1 - k) + k);

	return [r * 255, g * 255, b * 255];
};

convert.xyz.rgb = function (xyz) {
	var x = xyz[0] / 100;
	var y = xyz[1] / 100;
	var z = xyz[2] / 100;
	var r;
	var g;
	var b;

	r = (x * 3.2406) + (y * -1.5372) + (z * -0.4986);
	g = (x * -0.9689) + (y * 1.8758) + (z * 0.0415);
	b = (x * 0.0557) + (y * -0.2040) + (z * 1.0570);

	// assume sRGB
	r = r > 0.0031308
		? ((1.055 * Math.pow(r, 1.0 / 2.4)) - 0.055)
		: r * 12.92;

	g = g > 0.0031308
		? ((1.055 * Math.pow(g, 1.0 / 2.4)) - 0.055)
		: g * 12.92;

	b = b > 0.0031308
		? ((1.055 * Math.pow(b, 1.0 / 2.4)) - 0.055)
		: b * 12.92;

	r = Math.min(Math.max(0, r), 1);
	g = Math.min(Math.max(0, g), 1);
	b = Math.min(Math.max(0, b), 1);

	return [r * 255, g * 255, b * 255];
};

convert.xyz.lab = function (xyz) {
	var x = xyz[0];
	var y = xyz[1];
	var z = xyz[2];
	var l;
	var a;
	var b;

	x /= 95.047;
	y /= 100;
	z /= 108.883;

	x = x > 0.008856 ? Math.pow(x, 1 / 3) : (7.787 * x) + (16 / 116);
	y = y > 0.008856 ? Math.pow(y, 1 / 3) : (7.787 * y) + (16 / 116);
	z = z > 0.008856 ? Math.pow(z, 1 / 3) : (7.787 * z) + (16 / 116);

	l = (116 * y) - 16;
	a = 500 * (x - y);
	b = 200 * (y - z);

	return [l, a, b];
};

convert.lab.xyz = function (lab) {
	var l = lab[0];
	var a = lab[1];
	var b = lab[2];
	var x;
	var y;
	var z;

	y = (l + 16) / 116;
	x = a / 500 + y;
	z = y - b / 200;

	var y2 = Math.pow(y, 3);
	var x2 = Math.pow(x, 3);
	var z2 = Math.pow(z, 3);
	y = y2 > 0.008856 ? y2 : (y - 16 / 116) / 7.787;
	x = x2 > 0.008856 ? x2 : (x - 16 / 116) / 7.787;
	z = z2 > 0.008856 ? z2 : (z - 16 / 116) / 7.787;

	x *= 95.047;
	y *= 100;
	z *= 108.883;

	return [x, y, z];
};

convert.lab.lch = function (lab) {
	var l = lab[0];
	var a = lab[1];
	var b = lab[2];
	var hr;
	var h;
	var c;

	hr = Math.atan2(b, a);
	h = hr * 360 / 2 / Math.PI;

	if (h < 0) {
		h += 360;
	}

	c = Math.sqrt(a * a + b * b);

	return [l, c, h];
};

convert.lch.lab = function (lch) {
	var l = lch[0];
	var c = lch[1];
	var h = lch[2];
	var a;
	var b;
	var hr;

	hr = h / 360 * 2 * Math.PI;
	a = c * Math.cos(hr);
	b = c * Math.sin(hr);

	return [l, a, b];
};

convert.rgb.ansi16 = function (args) {
	var r = args[0];
	var g = args[1];
	var b = args[2];
	var value = 1 in arguments ? arguments[1] : convert.rgb.hsv(args)[2]; // hsv -> ansi16 optimization

	value = Math.round(value / 50);

	if (value === 0) {
		return 30;
	}

	var ansi = 30
		+ ((Math.round(b / 255) << 2)
		| (Math.round(g / 255) << 1)
		| Math.round(r / 255));

	if (value === 2) {
		ansi += 60;
	}

	return ansi;
};

convert.hsv.ansi16 = function (args) {
	// optimization here; we already know the value and don't need to get
	// it converted for us.
	return convert.rgb.ansi16(convert.hsv.rgb(args), args[2]);
};

convert.rgb.ansi256 = function (args) {
	var r = args[0];
	var g = args[1];
	var b = args[2];

	// we use the extended greyscale palette here, with the exception of
	// black and white. normal palette only has 4 greyscale shades.
	if (r === g && g === b) {
		if (r < 8) {
			return 16;
		}

		if (r > 248) {
			return 231;
		}

		return Math.round(((r - 8) / 247) * 24) + 232;
	}

	var ansi = 16
		+ (36 * Math.round(r / 255 * 5))
		+ (6 * Math.round(g / 255 * 5))
		+ Math.round(b / 255 * 5);

	return ansi;
};

convert.ansi16.rgb = function (args) {
	var color = args % 10;

	// handle greyscale
	if (color === 0 || color === 7) {
		if (args > 50) {
			color += 3.5;
		}

		color = color / 10.5 * 255;

		return [color, color, color];
	}

	var mult = (~~(args > 50) + 1) * 0.5;
	var r = ((color & 1) * mult) * 255;
	var g = (((color >> 1) & 1) * mult) * 255;
	var b = (((color >> 2) & 1) * mult) * 255;

	return [r, g, b];
};

convert.ansi256.rgb = function (args) {
	// handle greyscale
	if (args >= 232) {
		var c = (args - 232) * 10 + 8;
		return [c, c, c];
	}

	args -= 16;

	var rem;
	var r = Math.floor(args / 36) / 5 * 255;
	var g = Math.floor((rem = args % 36) / 6) / 5 * 255;
	var b = (rem % 6) / 5 * 255;

	return [r, g, b];
};

convert.rgb.hex = function (args) {
	var integer = ((Math.round(args[0]) & 0xFF) << 16)
		+ ((Math.round(args[1]) & 0xFF) << 8)
		+ (Math.round(args[2]) & 0xFF);

	var string = integer.toString(16).toUpperCase();
	return '000000'.substring(string.length) + string;
};

convert.hex.rgb = function (args) {
	var match = args.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);
	if (!match) {
		return [0, 0, 0];
	}

	var colorString = match[0];

	if (match[0].length === 3) {
		colorString = colorString.split('').map(function (char) {
			return char + char;
		}).join('');
	}

	var integer = parseInt(colorString, 16);
	var r = (integer >> 16) & 0xFF;
	var g = (integer >> 8) & 0xFF;
	var b = integer & 0xFF;

	return [r, g, b];
};

convert.rgb.hcg = function (rgb) {
	var r = rgb[0] / 255;
	var g = rgb[1] / 255;
	var b = rgb[2] / 255;
	var max = Math.max(Math.max(r, g), b);
	var min = Math.min(Math.min(r, g), b);
	var chroma = (max - min);
	var grayscale;
	var hue;

	if (chroma < 1) {
		grayscale = min / (1 - chroma);
	} else {
		grayscale = 0;
	}

	if (chroma <= 0) {
		hue = 0;
	} else
	if (max === r) {
		hue = ((g - b) / chroma) % 6;
	} else
	if (max === g) {
		hue = 2 + (b - r) / chroma;
	} else {
		hue = 4 + (r - g) / chroma + 4;
	}

	hue /= 6;
	hue %= 1;

	return [hue * 360, chroma * 100, grayscale * 100];
};

convert.hsl.hcg = function (hsl) {
	var s = hsl[1] / 100;
	var l = hsl[2] / 100;
	var c = 1;
	var f = 0;

	if (l < 0.5) {
		c = 2.0 * s * l;
	} else {
		c = 2.0 * s * (1.0 - l);
	}

	if (c < 1.0) {
		f = (l - 0.5 * c) / (1.0 - c);
	}

	return [hsl[0], c * 100, f * 100];
};

convert.hsv.hcg = function (hsv) {
	var s = hsv[1] / 100;
	var v = hsv[2] / 100;

	var c = s * v;
	var f = 0;

	if (c < 1.0) {
		f = (v - c) / (1 - c);
	}

	return [hsv[0], c * 100, f * 100];
};

convert.hcg.rgb = function (hcg) {
	var h = hcg[0] / 360;
	var c = hcg[1] / 100;
	var g = hcg[2] / 100;

	if (c === 0.0) {
		return [g * 255, g * 255, g * 255];
	}

	var pure = [0, 0, 0];
	var hi = (h % 1) * 6;
	var v = hi % 1;
	var w = 1 - v;
	var mg = 0;

	switch (Math.floor(hi)) {
		case 0:
			pure[0] = 1; pure[1] = v; pure[2] = 0; break;
		case 1:
			pure[0] = w; pure[1] = 1; pure[2] = 0; break;
		case 2:
			pure[0] = 0; pure[1] = 1; pure[2] = v; break;
		case 3:
			pure[0] = 0; pure[1] = w; pure[2] = 1; break;
		case 4:
			pure[0] = v; pure[1] = 0; pure[2] = 1; break;
		default:
			pure[0] = 1; pure[1] = 0; pure[2] = w;
	}

	mg = (1.0 - c) * g;

	return [
		(c * pure[0] + mg) * 255,
		(c * pure[1] + mg) * 255,
		(c * pure[2] + mg) * 255
	];
};

convert.hcg.hsv = function (hcg) {
	var c = hcg[1] / 100;
	var g = hcg[2] / 100;

	var v = c + g * (1.0 - c);
	var f = 0;

	if (v > 0.0) {
		f = c / v;
	}

	return [hcg[0], f * 100, v * 100];
};

convert.hcg.hsl = function (hcg) {
	var c = hcg[1] / 100;
	var g = hcg[2] / 100;

	var l = g * (1.0 - c) + 0.5 * c;
	var s = 0;

	if (l > 0.0 && l < 0.5) {
		s = c / (2 * l);
	} else
	if (l >= 0.5 && l < 1.0) {
		s = c / (2 * (1 - l));
	}

	return [hcg[0], s * 100, l * 100];
};

convert.hcg.hwb = function (hcg) {
	var c = hcg[1] / 100;
	var g = hcg[2] / 100;
	var v = c + g * (1.0 - c);
	return [hcg[0], (v - c) * 100, (1 - v) * 100];
};

convert.hwb.hcg = function (hwb) {
	var w = hwb[1] / 100;
	var b = hwb[2] / 100;
	var v = 1 - b;
	var c = v - w;
	var g = 0;

	if (c < 1) {
		g = (v - c) / (1 - c);
	}

	return [hwb[0], c * 100, g * 100];
};

convert.apple.rgb = function (apple) {
	return [(apple[0] / 65535) * 255, (apple[1] / 65535) * 255, (apple[2] / 65535) * 255];
};

convert.rgb.apple = function (rgb) {
	return [(rgb[0] / 255) * 65535, (rgb[1] / 255) * 65535, (rgb[2] / 255) * 65535];
};

convert.gray.rgb = function (args) {
	return [args[0] / 100 * 255, args[0] / 100 * 255, args[0] / 100 * 255];
};

convert.gray.hsl = convert.gray.hsv = function (args) {
	return [0, 0, args[0]];
};

convert.gray.hwb = function (gray) {
	return [0, 100, gray[0]];
};

convert.gray.cmyk = function (gray) {
	return [0, 0, 0, gray[0]];
};

convert.gray.lab = function (gray) {
	return [gray[0], 0, 0];
};

convert.gray.hex = function (gray) {
	var val = Math.round(gray[0] / 100 * 255) & 0xFF;
	var integer = (val << 16) + (val << 8) + val;

	var string = integer.toString(16).toUpperCase();
	return '000000'.substring(string.length) + string;
};

convert.rgb.gray = function (rgb) {
	var val = (rgb[0] + rgb[1] + rgb[2]) / 3;
	return [val / 255 * 100];
};


/***/ }),

/***/ "./node_modules/color-convert/index.js":
/*!*********************************************!*\
  !*** ./node_modules/color-convert/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var conversions = __webpack_require__(/*! ./conversions */ "./node_modules/color-convert/conversions.js");
var route = __webpack_require__(/*! ./route */ "./node_modules/color-convert/route.js");

var convert = {};

var models = Object.keys(conversions);

function wrapRaw(fn) {
	var wrappedFn = function (args) {
		if (args === undefined || args === null) {
			return args;
		}

		if (arguments.length > 1) {
			args = Array.prototype.slice.call(arguments);
		}

		return fn(args);
	};

	// preserve .conversion property if there is one
	if ('conversion' in fn) {
		wrappedFn.conversion = fn.conversion;
	}

	return wrappedFn;
}

function wrapRounded(fn) {
	var wrappedFn = function (args) {
		if (args === undefined || args === null) {
			return args;
		}

		if (arguments.length > 1) {
			args = Array.prototype.slice.call(arguments);
		}

		var result = fn(args);

		// we're assuming the result is an array here.
		// see notice in conversions.js; don't use box types
		// in conversion functions.
		if (typeof result === 'object') {
			for (var len = result.length, i = 0; i < len; i++) {
				result[i] = Math.round(result[i]);
			}
		}

		return result;
	};

	// preserve .conversion property if there is one
	if ('conversion' in fn) {
		wrappedFn.conversion = fn.conversion;
	}

	return wrappedFn;
}

models.forEach(function (fromModel) {
	convert[fromModel] = {};

	Object.defineProperty(convert[fromModel], 'channels', {value: conversions[fromModel].channels});
	Object.defineProperty(convert[fromModel], 'labels', {value: conversions[fromModel].labels});

	var routes = route(fromModel);
	var routeModels = Object.keys(routes);

	routeModels.forEach(function (toModel) {
		var fn = routes[toModel];

		convert[fromModel][toModel] = wrapRounded(fn);
		convert[fromModel][toModel].raw = wrapRaw(fn);
	});
});

module.exports = convert;


/***/ }),

/***/ "./node_modules/color-convert/route.js":
/*!*********************************************!*\
  !*** ./node_modules/color-convert/route.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var conversions = __webpack_require__(/*! ./conversions */ "./node_modules/color-convert/conversions.js");

/*
	this function routes a model to all other models.

	all functions that are routed have a property `.conversion` attached
	to the returned synthetic function. This property is an array
	of strings, each with the steps in between the 'from' and 'to'
	color models (inclusive).

	conversions that are not possible simply are not included.
*/

function buildGraph() {
	var graph = {};
	// https://jsperf.com/object-keys-vs-for-in-with-closure/3
	var models = Object.keys(conversions);

	for (var len = models.length, i = 0; i < len; i++) {
		graph[models[i]] = {
			// http://jsperf.com/1-vs-infinity
			// micro-opt, but this is simple.
			distance: -1,
			parent: null
		};
	}

	return graph;
}

// https://en.wikipedia.org/wiki/Breadth-first_search
function deriveBFS(fromModel) {
	var graph = buildGraph();
	var queue = [fromModel]; // unshift -> queue -> pop

	graph[fromModel].distance = 0;

	while (queue.length) {
		var current = queue.pop();
		var adjacents = Object.keys(conversions[current]);

		for (var len = adjacents.length, i = 0; i < len; i++) {
			var adjacent = adjacents[i];
			var node = graph[adjacent];

			if (node.distance === -1) {
				node.distance = graph[current].distance + 1;
				node.parent = current;
				queue.unshift(adjacent);
			}
		}
	}

	return graph;
}

function link(from, to) {
	return function (args) {
		return to(from(args));
	};
}

function wrapConversion(toModel, graph) {
	var path = [graph[toModel].parent, toModel];
	var fn = conversions[graph[toModel].parent][toModel];

	var cur = graph[toModel].parent;
	while (graph[cur].parent) {
		path.unshift(graph[cur].parent);
		fn = link(conversions[graph[cur].parent][cur], fn);
		cur = graph[cur].parent;
	}

	fn.conversion = path;
	return fn;
}

module.exports = function (fromModel) {
	var graph = deriveBFS(fromModel);
	var conversion = {};

	var models = Object.keys(graph);
	for (var len = models.length, i = 0; i < len; i++) {
		var toModel = models[i];
		var node = graph[toModel];

		if (node.parent === null) {
			// no possible conversion, or this node is the source model.
			continue;
		}

		conversion[toModel] = wrapConversion(toModel, graph);
	}

	return conversion;
};



/***/ }),

/***/ "./node_modules/color-name/index.js":
/*!******************************************!*\
  !*** ./node_modules/color-name/index.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = {
	"aliceblue": [240, 248, 255],
	"antiquewhite": [250, 235, 215],
	"aqua": [0, 255, 255],
	"aquamarine": [127, 255, 212],
	"azure": [240, 255, 255],
	"beige": [245, 245, 220],
	"bisque": [255, 228, 196],
	"black": [0, 0, 0],
	"blanchedalmond": [255, 235, 205],
	"blue": [0, 0, 255],
	"blueviolet": [138, 43, 226],
	"brown": [165, 42, 42],
	"burlywood": [222, 184, 135],
	"cadetblue": [95, 158, 160],
	"chartreuse": [127, 255, 0],
	"chocolate": [210, 105, 30],
	"coral": [255, 127, 80],
	"cornflowerblue": [100, 149, 237],
	"cornsilk": [255, 248, 220],
	"crimson": [220, 20, 60],
	"cyan": [0, 255, 255],
	"darkblue": [0, 0, 139],
	"darkcyan": [0, 139, 139],
	"darkgoldenrod": [184, 134, 11],
	"darkgray": [169, 169, 169],
	"darkgreen": [0, 100, 0],
	"darkgrey": [169, 169, 169],
	"darkkhaki": [189, 183, 107],
	"darkmagenta": [139, 0, 139],
	"darkolivegreen": [85, 107, 47],
	"darkorange": [255, 140, 0],
	"darkorchid": [153, 50, 204],
	"darkred": [139, 0, 0],
	"darksalmon": [233, 150, 122],
	"darkseagreen": [143, 188, 143],
	"darkslateblue": [72, 61, 139],
	"darkslategray": [47, 79, 79],
	"darkslategrey": [47, 79, 79],
	"darkturquoise": [0, 206, 209],
	"darkviolet": [148, 0, 211],
	"deeppink": [255, 20, 147],
	"deepskyblue": [0, 191, 255],
	"dimgray": [105, 105, 105],
	"dimgrey": [105, 105, 105],
	"dodgerblue": [30, 144, 255],
	"firebrick": [178, 34, 34],
	"floralwhite": [255, 250, 240],
	"forestgreen": [34, 139, 34],
	"fuchsia": [255, 0, 255],
	"gainsboro": [220, 220, 220],
	"ghostwhite": [248, 248, 255],
	"gold": [255, 215, 0],
	"goldenrod": [218, 165, 32],
	"gray": [128, 128, 128],
	"green": [0, 128, 0],
	"greenyellow": [173, 255, 47],
	"grey": [128, 128, 128],
	"honeydew": [240, 255, 240],
	"hotpink": [255, 105, 180],
	"indianred": [205, 92, 92],
	"indigo": [75, 0, 130],
	"ivory": [255, 255, 240],
	"khaki": [240, 230, 140],
	"lavender": [230, 230, 250],
	"lavenderblush": [255, 240, 245],
	"lawngreen": [124, 252, 0],
	"lemonchiffon": [255, 250, 205],
	"lightblue": [173, 216, 230],
	"lightcoral": [240, 128, 128],
	"lightcyan": [224, 255, 255],
	"lightgoldenrodyellow": [250, 250, 210],
	"lightgray": [211, 211, 211],
	"lightgreen": [144, 238, 144],
	"lightgrey": [211, 211, 211],
	"lightpink": [255, 182, 193],
	"lightsalmon": [255, 160, 122],
	"lightseagreen": [32, 178, 170],
	"lightskyblue": [135, 206, 250],
	"lightslategray": [119, 136, 153],
	"lightslategrey": [119, 136, 153],
	"lightsteelblue": [176, 196, 222],
	"lightyellow": [255, 255, 224],
	"lime": [0, 255, 0],
	"limegreen": [50, 205, 50],
	"linen": [250, 240, 230],
	"magenta": [255, 0, 255],
	"maroon": [128, 0, 0],
	"mediumaquamarine": [102, 205, 170],
	"mediumblue": [0, 0, 205],
	"mediumorchid": [186, 85, 211],
	"mediumpurple": [147, 112, 219],
	"mediumseagreen": [60, 179, 113],
	"mediumslateblue": [123, 104, 238],
	"mediumspringgreen": [0, 250, 154],
	"mediumturquoise": [72, 209, 204],
	"mediumvioletred": [199, 21, 133],
	"midnightblue": [25, 25, 112],
	"mintcream": [245, 255, 250],
	"mistyrose": [255, 228, 225],
	"moccasin": [255, 228, 181],
	"navajowhite": [255, 222, 173],
	"navy": [0, 0, 128],
	"oldlace": [253, 245, 230],
	"olive": [128, 128, 0],
	"olivedrab": [107, 142, 35],
	"orange": [255, 165, 0],
	"orangered": [255, 69, 0],
	"orchid": [218, 112, 214],
	"palegoldenrod": [238, 232, 170],
	"palegreen": [152, 251, 152],
	"paleturquoise": [175, 238, 238],
	"palevioletred": [219, 112, 147],
	"papayawhip": [255, 239, 213],
	"peachpuff": [255, 218, 185],
	"peru": [205, 133, 63],
	"pink": [255, 192, 203],
	"plum": [221, 160, 221],
	"powderblue": [176, 224, 230],
	"purple": [128, 0, 128],
	"rebeccapurple": [102, 51, 153],
	"red": [255, 0, 0],
	"rosybrown": [188, 143, 143],
	"royalblue": [65, 105, 225],
	"saddlebrown": [139, 69, 19],
	"salmon": [250, 128, 114],
	"sandybrown": [244, 164, 96],
	"seagreen": [46, 139, 87],
	"seashell": [255, 245, 238],
	"sienna": [160, 82, 45],
	"silver": [192, 192, 192],
	"skyblue": [135, 206, 235],
	"slateblue": [106, 90, 205],
	"slategray": [112, 128, 144],
	"slategrey": [112, 128, 144],
	"snow": [255, 250, 250],
	"springgreen": [0, 255, 127],
	"steelblue": [70, 130, 180],
	"tan": [210, 180, 140],
	"teal": [0, 128, 128],
	"thistle": [216, 191, 216],
	"tomato": [255, 99, 71],
	"turquoise": [64, 224, 208],
	"violet": [238, 130, 238],
	"wheat": [245, 222, 179],
	"white": [255, 255, 255],
	"whitesmoke": [245, 245, 245],
	"yellow": [255, 255, 0],
	"yellowgreen": [154, 205, 50]
};


/***/ }),

/***/ "./node_modules/color-string/index.js":
/*!********************************************!*\
  !*** ./node_modules/color-string/index.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* MIT license */
var colorNames = __webpack_require__(/*! color-name */ "./node_modules/color-string/node_modules/color-name/index.js");
var swizzle = __webpack_require__(/*! simple-swizzle */ "./node_modules/simple-swizzle/index.js");

var reverseNames = {};

// create a list of reverse color names
for (var name in colorNames) {
	if (colorNames.hasOwnProperty(name)) {
		reverseNames[colorNames[name]] = name;
	}
}

var cs = module.exports = {
	to: {},
	get: {}
};

cs.get = function (string) {
	var prefix = string.substring(0, 3).toLowerCase();
	var val;
	var model;
	switch (prefix) {
		case 'hsl':
			val = cs.get.hsl(string);
			model = 'hsl';
			break;
		case 'hwb':
			val = cs.get.hwb(string);
			model = 'hwb';
			break;
		default:
			val = cs.get.rgb(string);
			model = 'rgb';
			break;
	}

	if (!val) {
		return null;
	}

	return {model: model, value: val};
};

cs.get.rgb = function (string) {
	if (!string) {
		return null;
	}

	var abbr = /^#([a-f0-9]{3,4})$/i;
	var hex = /^#([a-f0-9]{6})([a-f0-9]{2})?$/i;
	var rgba = /^rgba?\(\s*([+-]?\d+)\s*,\s*([+-]?\d+)\s*,\s*([+-]?\d+)\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)$/;
	var per = /^rgba?\(\s*([+-]?[\d\.]+)\%\s*,\s*([+-]?[\d\.]+)\%\s*,\s*([+-]?[\d\.]+)\%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)$/;
	var keyword = /(\D+)/;

	var rgb = [0, 0, 0, 1];
	var match;
	var i;
	var hexAlpha;

	if (match = string.match(hex)) {
		hexAlpha = match[2];
		match = match[1];

		for (i = 0; i < 3; i++) {
			// https://jsperf.com/slice-vs-substr-vs-substring-methods-long-string/19
			var i2 = i * 2;
			rgb[i] = parseInt(match.slice(i2, i2 + 2), 16);
		}

		if (hexAlpha) {
			rgb[3] = Math.round((parseInt(hexAlpha, 16) / 255) * 100) / 100;
		}
	} else if (match = string.match(abbr)) {
		match = match[1];
		hexAlpha = match[3];

		for (i = 0; i < 3; i++) {
			rgb[i] = parseInt(match[i] + match[i], 16);
		}

		if (hexAlpha) {
			rgb[3] = Math.round((parseInt(hexAlpha + hexAlpha, 16) / 255) * 100) / 100;
		}
	} else if (match = string.match(rgba)) {
		for (i = 0; i < 3; i++) {
			rgb[i] = parseInt(match[i + 1], 0);
		}

		if (match[4]) {
			rgb[3] = parseFloat(match[4]);
		}
	} else if (match = string.match(per)) {
		for (i = 0; i < 3; i++) {
			rgb[i] = Math.round(parseFloat(match[i + 1]) * 2.55);
		}

		if (match[4]) {
			rgb[3] = parseFloat(match[4]);
		}
	} else if (match = string.match(keyword)) {
		if (match[1] === 'transparent') {
			return [0, 0, 0, 0];
		}

		rgb = colorNames[match[1]];

		if (!rgb) {
			return null;
		}

		rgb[3] = 1;

		return rgb;
	} else {
		return null;
	}

	for (i = 0; i < 3; i++) {
		rgb[i] = clamp(rgb[i], 0, 255);
	}
	rgb[3] = clamp(rgb[3], 0, 1);

	return rgb;
};

cs.get.hsl = function (string) {
	if (!string) {
		return null;
	}

	var hsl = /^hsla?\(\s*([+-]?(?:\d*\.)?\d+)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)$/;
	var match = string.match(hsl);

	if (match) {
		var alpha = parseFloat(match[4]);
		var h = (parseFloat(match[1]) + 360) % 360;
		var s = clamp(parseFloat(match[2]), 0, 100);
		var l = clamp(parseFloat(match[3]), 0, 100);
		var a = clamp(isNaN(alpha) ? 1 : alpha, 0, 1);

		return [h, s, l, a];
	}

	return null;
};

cs.get.hwb = function (string) {
	if (!string) {
		return null;
	}

	var hwb = /^hwb\(\s*([+-]?\d*[\.]?\d+)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)$/;
	var match = string.match(hwb);

	if (match) {
		var alpha = parseFloat(match[4]);
		var h = ((parseFloat(match[1]) % 360) + 360) % 360;
		var w = clamp(parseFloat(match[2]), 0, 100);
		var b = clamp(parseFloat(match[3]), 0, 100);
		var a = clamp(isNaN(alpha) ? 1 : alpha, 0, 1);
		return [h, w, b, a];
	}

	return null;
};

cs.to.hex = function () {
	var rgba = swizzle(arguments);

	return (
		'#' +
		hexDouble(rgba[0]) +
		hexDouble(rgba[1]) +
		hexDouble(rgba[2]) +
		(rgba[3] < 1
			? (hexDouble(Math.round(rgba[3] * 255)))
			: '')
	);
};

cs.to.rgb = function () {
	var rgba = swizzle(arguments);

	return rgba.length < 4 || rgba[3] === 1
		? 'rgb(' + Math.round(rgba[0]) + ', ' + Math.round(rgba[1]) + ', ' + Math.round(rgba[2]) + ')'
		: 'rgba(' + Math.round(rgba[0]) + ', ' + Math.round(rgba[1]) + ', ' + Math.round(rgba[2]) + ', ' + rgba[3] + ')';
};

cs.to.rgb.percent = function () {
	var rgba = swizzle(arguments);

	var r = Math.round(rgba[0] / 255 * 100);
	var g = Math.round(rgba[1] / 255 * 100);
	var b = Math.round(rgba[2] / 255 * 100);

	return rgba.length < 4 || rgba[3] === 1
		? 'rgb(' + r + '%, ' + g + '%, ' + b + '%)'
		: 'rgba(' + r + '%, ' + g + '%, ' + b + '%, ' + rgba[3] + ')';
};

cs.to.hsl = function () {
	var hsla = swizzle(arguments);
	return hsla.length < 4 || hsla[3] === 1
		? 'hsl(' + hsla[0] + ', ' + hsla[1] + '%, ' + hsla[2] + '%)'
		: 'hsla(' + hsla[0] + ', ' + hsla[1] + '%, ' + hsla[2] + '%, ' + hsla[3] + ')';
};

// hwb is a bit different than rgb(a) & hsl(a) since there is no alpha specific syntax
// (hwb have alpha optional & 1 is default value)
cs.to.hwb = function () {
	var hwba = swizzle(arguments);

	var a = '';
	if (hwba.length >= 4 && hwba[3] !== 1) {
		a = ', ' + hwba[3];
	}

	return 'hwb(' + hwba[0] + ', ' + hwba[1] + '%, ' + hwba[2] + '%' + a + ')';
};

cs.to.keyword = function (rgb) {
	return reverseNames[rgb.slice(0, 3)];
};

// helpers
function clamp(num, min, max) {
	return Math.min(Math.max(min, num), max);
}

function hexDouble(num) {
	var str = num.toString(16).toUpperCase();
	return (str.length < 2) ? '0' + str : str;
}


/***/ }),

/***/ "./node_modules/color-string/node_modules/color-name/index.js":
/*!********************************************************************!*\
  !*** ./node_modules/color-string/node_modules/color-name/index.js ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = {
	"aliceblue": [240, 248, 255],
	"antiquewhite": [250, 235, 215],
	"aqua": [0, 255, 255],
	"aquamarine": [127, 255, 212],
	"azure": [240, 255, 255],
	"beige": [245, 245, 220],
	"bisque": [255, 228, 196],
	"black": [0, 0, 0],
	"blanchedalmond": [255, 235, 205],
	"blue": [0, 0, 255],
	"blueviolet": [138, 43, 226],
	"brown": [165, 42, 42],
	"burlywood": [222, 184, 135],
	"cadetblue": [95, 158, 160],
	"chartreuse": [127, 255, 0],
	"chocolate": [210, 105, 30],
	"coral": [255, 127, 80],
	"cornflowerblue": [100, 149, 237],
	"cornsilk": [255, 248, 220],
	"crimson": [220, 20, 60],
	"cyan": [0, 255, 255],
	"darkblue": [0, 0, 139],
	"darkcyan": [0, 139, 139],
	"darkgoldenrod": [184, 134, 11],
	"darkgray": [169, 169, 169],
	"darkgreen": [0, 100, 0],
	"darkgrey": [169, 169, 169],
	"darkkhaki": [189, 183, 107],
	"darkmagenta": [139, 0, 139],
	"darkolivegreen": [85, 107, 47],
	"darkorange": [255, 140, 0],
	"darkorchid": [153, 50, 204],
	"darkred": [139, 0, 0],
	"darksalmon": [233, 150, 122],
	"darkseagreen": [143, 188, 143],
	"darkslateblue": [72, 61, 139],
	"darkslategray": [47, 79, 79],
	"darkslategrey": [47, 79, 79],
	"darkturquoise": [0, 206, 209],
	"darkviolet": [148, 0, 211],
	"deeppink": [255, 20, 147],
	"deepskyblue": [0, 191, 255],
	"dimgray": [105, 105, 105],
	"dimgrey": [105, 105, 105],
	"dodgerblue": [30, 144, 255],
	"firebrick": [178, 34, 34],
	"floralwhite": [255, 250, 240],
	"forestgreen": [34, 139, 34],
	"fuchsia": [255, 0, 255],
	"gainsboro": [220, 220, 220],
	"ghostwhite": [248, 248, 255],
	"gold": [255, 215, 0],
	"goldenrod": [218, 165, 32],
	"gray": [128, 128, 128],
	"green": [0, 128, 0],
	"greenyellow": [173, 255, 47],
	"grey": [128, 128, 128],
	"honeydew": [240, 255, 240],
	"hotpink": [255, 105, 180],
	"indianred": [205, 92, 92],
	"indigo": [75, 0, 130],
	"ivory": [255, 255, 240],
	"khaki": [240, 230, 140],
	"lavender": [230, 230, 250],
	"lavenderblush": [255, 240, 245],
	"lawngreen": [124, 252, 0],
	"lemonchiffon": [255, 250, 205],
	"lightblue": [173, 216, 230],
	"lightcoral": [240, 128, 128],
	"lightcyan": [224, 255, 255],
	"lightgoldenrodyellow": [250, 250, 210],
	"lightgray": [211, 211, 211],
	"lightgreen": [144, 238, 144],
	"lightgrey": [211, 211, 211],
	"lightpink": [255, 182, 193],
	"lightsalmon": [255, 160, 122],
	"lightseagreen": [32, 178, 170],
	"lightskyblue": [135, 206, 250],
	"lightslategray": [119, 136, 153],
	"lightslategrey": [119, 136, 153],
	"lightsteelblue": [176, 196, 222],
	"lightyellow": [255, 255, 224],
	"lime": [0, 255, 0],
	"limegreen": [50, 205, 50],
	"linen": [250, 240, 230],
	"magenta": [255, 0, 255],
	"maroon": [128, 0, 0],
	"mediumaquamarine": [102, 205, 170],
	"mediumblue": [0, 0, 205],
	"mediumorchid": [186, 85, 211],
	"mediumpurple": [147, 112, 219],
	"mediumseagreen": [60, 179, 113],
	"mediumslateblue": [123, 104, 238],
	"mediumspringgreen": [0, 250, 154],
	"mediumturquoise": [72, 209, 204],
	"mediumvioletred": [199, 21, 133],
	"midnightblue": [25, 25, 112],
	"mintcream": [245, 255, 250],
	"mistyrose": [255, 228, 225],
	"moccasin": [255, 228, 181],
	"navajowhite": [255, 222, 173],
	"navy": [0, 0, 128],
	"oldlace": [253, 245, 230],
	"olive": [128, 128, 0],
	"olivedrab": [107, 142, 35],
	"orange": [255, 165, 0],
	"orangered": [255, 69, 0],
	"orchid": [218, 112, 214],
	"palegoldenrod": [238, 232, 170],
	"palegreen": [152, 251, 152],
	"paleturquoise": [175, 238, 238],
	"palevioletred": [219, 112, 147],
	"papayawhip": [255, 239, 213],
	"peachpuff": [255, 218, 185],
	"peru": [205, 133, 63],
	"pink": [255, 192, 203],
	"plum": [221, 160, 221],
	"powderblue": [176, 224, 230],
	"purple": [128, 0, 128],
	"rebeccapurple": [102, 51, 153],
	"red": [255, 0, 0],
	"rosybrown": [188, 143, 143],
	"royalblue": [65, 105, 225],
	"saddlebrown": [139, 69, 19],
	"salmon": [250, 128, 114],
	"sandybrown": [244, 164, 96],
	"seagreen": [46, 139, 87],
	"seashell": [255, 245, 238],
	"sienna": [160, 82, 45],
	"silver": [192, 192, 192],
	"skyblue": [135, 206, 235],
	"slateblue": [106, 90, 205],
	"slategray": [112, 128, 144],
	"slategrey": [112, 128, 144],
	"snow": [255, 250, 250],
	"springgreen": [0, 255, 127],
	"steelblue": [70, 130, 180],
	"tan": [210, 180, 140],
	"teal": [0, 128, 128],
	"thistle": [216, 191, 216],
	"tomato": [255, 99, 71],
	"turquoise": [64, 224, 208],
	"violet": [238, 130, 238],
	"wheat": [245, 222, 179],
	"white": [255, 255, 255],
	"whitesmoke": [245, 245, 245],
	"yellow": [255, 255, 0],
	"yellowgreen": [154, 205, 50]
};


/***/ }),

/***/ "./node_modules/color/index.js":
/*!*************************************!*\
  !*** ./node_modules/color/index.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var colorString = __webpack_require__(/*! color-string */ "./node_modules/color-string/index.js");
var convert = __webpack_require__(/*! color-convert */ "./node_modules/color-convert/index.js");

var _slice = [].slice;

var skippedModels = [
	// to be honest, I don't really feel like keyword belongs in color convert, but eh.
	'keyword',

	// gray conflicts with some method names, and has its own method defined.
	'gray',

	// shouldn't really be in color-convert either...
	'hex'
];

var hashedModelKeys = {};
Object.keys(convert).forEach(function (model) {
	hashedModelKeys[_slice.call(convert[model].labels).sort().join('')] = model;
});

var limiters = {};

function Color(obj, model) {
	if (!(this instanceof Color)) {
		return new Color(obj, model);
	}

	if (model && model in skippedModels) {
		model = null;
	}

	if (model && !(model in convert)) {
		throw new Error('Unknown model: ' + model);
	}

	var i;
	var channels;

	if (obj == null) { // eslint-disable-line no-eq-null,eqeqeq
		this.model = 'rgb';
		this.color = [0, 0, 0];
		this.valpha = 1;
	} else if (obj instanceof Color) {
		this.model = obj.model;
		this.color = obj.color.slice();
		this.valpha = obj.valpha;
	} else if (typeof obj === 'string') {
		var result = colorString.get(obj);
		if (result === null) {
			throw new Error('Unable to parse color from string: ' + obj);
		}

		this.model = result.model;
		channels = convert[this.model].channels;
		this.color = result.value.slice(0, channels);
		this.valpha = typeof result.value[channels] === 'number' ? result.value[channels] : 1;
	} else if (obj.length) {
		this.model = model || 'rgb';
		channels = convert[this.model].channels;
		var newArr = _slice.call(obj, 0, channels);
		this.color = zeroArray(newArr, channels);
		this.valpha = typeof obj[channels] === 'number' ? obj[channels] : 1;
	} else if (typeof obj === 'number') {
		// this is always RGB - can be converted later on.
		obj &= 0xFFFFFF;
		this.model = 'rgb';
		this.color = [
			(obj >> 16) & 0xFF,
			(obj >> 8) & 0xFF,
			obj & 0xFF
		];
		this.valpha = 1;
	} else {
		this.valpha = 1;

		var keys = Object.keys(obj);
		if ('alpha' in obj) {
			keys.splice(keys.indexOf('alpha'), 1);
			this.valpha = typeof obj.alpha === 'number' ? obj.alpha : 0;
		}

		var hashedKeys = keys.sort().join('');
		if (!(hashedKeys in hashedModelKeys)) {
			throw new Error('Unable to parse color from object: ' + JSON.stringify(obj));
		}

		this.model = hashedModelKeys[hashedKeys];

		var labels = convert[this.model].labels;
		var color = [];
		for (i = 0; i < labels.length; i++) {
			color.push(obj[labels[i]]);
		}

		this.color = zeroArray(color);
	}

	// perform limitations (clamping, etc.)
	if (limiters[this.model]) {
		channels = convert[this.model].channels;
		for (i = 0; i < channels; i++) {
			var limit = limiters[this.model][i];
			if (limit) {
				this.color[i] = limit(this.color[i]);
			}
		}
	}

	this.valpha = Math.max(0, Math.min(1, this.valpha));

	if (Object.freeze) {
		Object.freeze(this);
	}
}

Color.prototype = {
	toString: function () {
		return this.string();
	},

	toJSON: function () {
		return this[this.model]();
	},

	string: function (places) {
		var self = this.model in colorString.to ? this : this.rgb();
		self = self.round(typeof places === 'number' ? places : 1);
		var args = self.valpha === 1 ? self.color : self.color.concat(this.valpha);
		return colorString.to[self.model](args);
	},

	percentString: function (places) {
		var self = this.rgb().round(typeof places === 'number' ? places : 1);
		var args = self.valpha === 1 ? self.color : self.color.concat(this.valpha);
		return colorString.to.rgb.percent(args);
	},

	array: function () {
		return this.valpha === 1 ? this.color.slice() : this.color.concat(this.valpha);
	},

	object: function () {
		var result = {};
		var channels = convert[this.model].channels;
		var labels = convert[this.model].labels;

		for (var i = 0; i < channels; i++) {
			result[labels[i]] = this.color[i];
		}

		if (this.valpha !== 1) {
			result.alpha = this.valpha;
		}

		return result;
	},

	unitArray: function () {
		var rgb = this.rgb().color;
		rgb[0] /= 255;
		rgb[1] /= 255;
		rgb[2] /= 255;

		if (this.valpha !== 1) {
			rgb.push(this.valpha);
		}

		return rgb;
	},

	unitObject: function () {
		var rgb = this.rgb().object();
		rgb.r /= 255;
		rgb.g /= 255;
		rgb.b /= 255;

		if (this.valpha !== 1) {
			rgb.alpha = this.valpha;
		}

		return rgb;
	},

	round: function (places) {
		places = Math.max(places || 0, 0);
		return new Color(this.color.map(roundToPlace(places)).concat(this.valpha), this.model);
	},

	alpha: function (val) {
		if (arguments.length) {
			return new Color(this.color.concat(Math.max(0, Math.min(1, val))), this.model);
		}

		return this.valpha;
	},

	// rgb
	red: getset('rgb', 0, maxfn(255)),
	green: getset('rgb', 1, maxfn(255)),
	blue: getset('rgb', 2, maxfn(255)),

	hue: getset(['hsl', 'hsv', 'hsl', 'hwb', 'hcg'], 0, function (val) { return ((val % 360) + 360) % 360; }), // eslint-disable-line brace-style

	saturationl: getset('hsl', 1, maxfn(100)),
	lightness: getset('hsl', 2, maxfn(100)),

	saturationv: getset('hsv', 1, maxfn(100)),
	value: getset('hsv', 2, maxfn(100)),

	chroma: getset('hcg', 1, maxfn(100)),
	gray: getset('hcg', 2, maxfn(100)),

	white: getset('hwb', 1, maxfn(100)),
	wblack: getset('hwb', 2, maxfn(100)),

	cyan: getset('cmyk', 0, maxfn(100)),
	magenta: getset('cmyk', 1, maxfn(100)),
	yellow: getset('cmyk', 2, maxfn(100)),
	black: getset('cmyk', 3, maxfn(100)),

	x: getset('xyz', 0, maxfn(100)),
	y: getset('xyz', 1, maxfn(100)),
	z: getset('xyz', 2, maxfn(100)),

	l: getset('lab', 0, maxfn(100)),
	a: getset('lab', 1),
	b: getset('lab', 2),

	keyword: function (val) {
		if (arguments.length) {
			return new Color(val);
		}

		return convert[this.model].keyword(this.color);
	},

	hex: function (val) {
		if (arguments.length) {
			return new Color(val);
		}

		return colorString.to.hex(this.rgb().round().color);
	},

	rgbNumber: function () {
		var rgb = this.rgb().color;
		return ((rgb[0] & 0xFF) << 16) | ((rgb[1] & 0xFF) << 8) | (rgb[2] & 0xFF);
	},

	luminosity: function () {
		// http://www.w3.org/TR/WCAG20/#relativeluminancedef
		var rgb = this.rgb().color;

		var lum = [];
		for (var i = 0; i < rgb.length; i++) {
			var chan = rgb[i] / 255;
			lum[i] = (chan <= 0.03928) ? chan / 12.92 : Math.pow(((chan + 0.055) / 1.055), 2.4);
		}

		return 0.2126 * lum[0] + 0.7152 * lum[1] + 0.0722 * lum[2];
	},

	contrast: function (color2) {
		// http://www.w3.org/TR/WCAG20/#contrast-ratiodef
		var lum1 = this.luminosity();
		var lum2 = color2.luminosity();

		if (lum1 > lum2) {
			return (lum1 + 0.05) / (lum2 + 0.05);
		}

		return (lum2 + 0.05) / (lum1 + 0.05);
	},

	level: function (color2) {
		var contrastRatio = this.contrast(color2);
		if (contrastRatio >= 7.1) {
			return 'AAA';
		}

		return (contrastRatio >= 4.5) ? 'AA' : '';
	},

	isDark: function () {
		// YIQ equation from http://24ways.org/2010/calculating-color-contrast
		var rgb = this.rgb().color;
		var yiq = (rgb[0] * 299 + rgb[1] * 587 + rgb[2] * 114) / 1000;
		return yiq < 128;
	},

	isLight: function () {
		return !this.isDark();
	},

	negate: function () {
		var rgb = this.rgb();
		for (var i = 0; i < 3; i++) {
			rgb.color[i] = 255 - rgb.color[i];
		}
		return rgb;
	},

	lighten: function (ratio) {
		var hsl = this.hsl();
		hsl.color[2] += hsl.color[2] * ratio;
		return hsl;
	},

	darken: function (ratio) {
		var hsl = this.hsl();
		hsl.color[2] -= hsl.color[2] * ratio;
		return hsl;
	},

	saturate: function (ratio) {
		var hsl = this.hsl();
		hsl.color[1] += hsl.color[1] * ratio;
		return hsl;
	},

	desaturate: function (ratio) {
		var hsl = this.hsl();
		hsl.color[1] -= hsl.color[1] * ratio;
		return hsl;
	},

	whiten: function (ratio) {
		var hwb = this.hwb();
		hwb.color[1] += hwb.color[1] * ratio;
		return hwb;
	},

	blacken: function (ratio) {
		var hwb = this.hwb();
		hwb.color[2] += hwb.color[2] * ratio;
		return hwb;
	},

	grayscale: function () {
		// http://en.wikipedia.org/wiki/Grayscale#Converting_color_to_grayscale
		var rgb = this.rgb().color;
		var val = rgb[0] * 0.3 + rgb[1] * 0.59 + rgb[2] * 0.11;
		return Color.rgb(val, val, val);
	},

	fade: function (ratio) {
		return this.alpha(this.valpha - (this.valpha * ratio));
	},

	opaquer: function (ratio) {
		return this.alpha(this.valpha + (this.valpha * ratio));
	},

	rotate: function (degrees) {
		var hsl = this.hsl();
		var hue = hsl.color[0];
		hue = (hue + degrees) % 360;
		hue = hue < 0 ? 360 + hue : hue;
		hsl.color[0] = hue;
		return hsl;
	},

	mix: function (mixinColor, weight) {
		// ported from sass implementation in C
		// https://github.com/sass/libsass/blob/0e6b4a2850092356aa3ece07c6b249f0221caced/functions.cpp#L209
		if (!mixinColor || !mixinColor.rgb) {
			throw new Error('Argument to "mix" was not a Color instance, but rather an instance of ' + typeof mixinColor);
		}
		var color1 = mixinColor.rgb();
		var color2 = this.rgb();
		var p = weight === undefined ? 0.5 : weight;

		var w = 2 * p - 1;
		var a = color1.alpha() - color2.alpha();

		var w1 = (((w * a === -1) ? w : (w + a) / (1 + w * a)) + 1) / 2.0;
		var w2 = 1 - w1;

		return Color.rgb(
				w1 * color1.red() + w2 * color2.red(),
				w1 * color1.green() + w2 * color2.green(),
				w1 * color1.blue() + w2 * color2.blue(),
				color1.alpha() * p + color2.alpha() * (1 - p));
	}
};

// model conversion methods and static constructors
Object.keys(convert).forEach(function (model) {
	if (skippedModels.indexOf(model) !== -1) {
		return;
	}

	var channels = convert[model].channels;

	// conversion methods
	Color.prototype[model] = function () {
		if (this.model === model) {
			return new Color(this);
		}

		if (arguments.length) {
			return new Color(arguments, model);
		}

		var newAlpha = typeof arguments[channels] === 'number' ? channels : this.valpha;
		return new Color(assertArray(convert[this.model][model].raw(this.color)).concat(newAlpha), model);
	};

	// 'static' construction methods
	Color[model] = function (color) {
		if (typeof color === 'number') {
			color = zeroArray(_slice.call(arguments), channels);
		}
		return new Color(color, model);
	};
});

function roundTo(num, places) {
	return Number(num.toFixed(places));
}

function roundToPlace(places) {
	return function (num) {
		return roundTo(num, places);
	};
}

function getset(model, channel, modifier) {
	model = Array.isArray(model) ? model : [model];

	model.forEach(function (m) {
		(limiters[m] || (limiters[m] = []))[channel] = modifier;
	});

	model = model[0];

	return function (val) {
		var result;

		if (arguments.length) {
			if (modifier) {
				val = modifier(val);
			}

			result = this[model]();
			result.color[channel] = val;
			return result;
		}

		result = this[model]().color[channel];
		if (modifier) {
			result = modifier(result);
		}

		return result;
	};
}

function maxfn(max) {
	return function (v) {
		return Math.max(0, Math.min(max, v));
	};
}

function assertArray(val) {
	return Array.isArray(val) ? val : [val];
}

function zeroArray(arr, length) {
	for (var i = 0; i < length; i++) {
		if (typeof arr[i] !== 'number') {
			arr[i] = 0;
		}
	}

	return arr;
}

module.exports = Color;


/***/ }),

/***/ "./node_modules/flatpickr/dist/flatpickr.js":
/*!**************************************************!*\
  !*** ./node_modules/flatpickr/dist/flatpickr.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* flatpickr v4.6.1, @license MIT */
(function (global, factory) {
     true ? module.exports = factory() :
    undefined;
}(this, function () { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    var HOOKS = [
        "onChange",
        "onClose",
        "onDayCreate",
        "onDestroy",
        "onKeyDown",
        "onMonthChange",
        "onOpen",
        "onParseConfig",
        "onReady",
        "onValueUpdate",
        "onYearChange",
        "onPreCalendarPosition",
    ];
    var defaults = {
        _disable: [],
        _enable: [],
        allowInput: false,
        altFormat: "F j, Y",
        altInput: false,
        altInputClass: "form-control input",
        animate: typeof window === "object" &&
            window.navigator.userAgent.indexOf("MSIE") === -1,
        ariaDateFormat: "F j, Y",
        clickOpens: true,
        closeOnSelect: true,
        conjunction: ", ",
        dateFormat: "Y-m-d",
        defaultHour: 12,
        defaultMinute: 0,
        defaultSeconds: 0,
        disable: [],
        disableMobile: false,
        enable: [],
        enableSeconds: false,
        enableTime: false,
        errorHandler: function (err) {
            return typeof console !== "undefined" && console.warn(err);
        },
        getWeek: function (givenDate) {
            var date = new Date(givenDate.getTime());
            date.setHours(0, 0, 0, 0);
            // Thursday in current week decides the year.
            date.setDate(date.getDate() + 3 - ((date.getDay() + 6) % 7));
            // January 4 is always in week 1.
            var week1 = new Date(date.getFullYear(), 0, 4);
            // Adjust to Thursday in week 1 and count number of weeks from date to week1.
            return (1 +
                Math.round(((date.getTime() - week1.getTime()) / 86400000 -
                    3 +
                    ((week1.getDay() + 6) % 7)) /
                    7));
        },
        hourIncrement: 1,
        ignoredFocusElements: [],
        inline: false,
        locale: "default",
        minuteIncrement: 5,
        mode: "single",
        nextArrow: "<svg version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox='0 0 17 17'><g></g><path d='M13.207 8.472l-7.854 7.854-0.707-0.707 7.146-7.146-7.146-7.148 0.707-0.707 7.854 7.854z' /></svg>",
        noCalendar: false,
        now: new Date(),
        onChange: [],
        onClose: [],
        onDayCreate: [],
        onDestroy: [],
        onKeyDown: [],
        onMonthChange: [],
        onOpen: [],
        onParseConfig: [],
        onReady: [],
        onValueUpdate: [],
        onYearChange: [],
        onPreCalendarPosition: [],
        plugins: [],
        position: "auto",
        positionElement: undefined,
        prevArrow: "<svg version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox='0 0 17 17'><g></g><path d='M5.207 8.471l7.146 7.147-0.707 0.707-7.853-7.854 7.854-7.853 0.707 0.707-7.147 7.146z' /></svg>",
        shorthandCurrentMonth: false,
        showMonths: 1,
        static: false,
        time_24hr: false,
        weekNumbers: false,
        wrap: false
    };

    var english = {
        weekdays: {
            shorthand: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            longhand: [
                "Sunday",
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday",
            ]
        },
        months: {
            shorthand: [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec",
            ],
            longhand: [
                "January",
                "February",
                "March",
                "April",
                "May",
                "June",
                "July",
                "August",
                "September",
                "October",
                "November",
                "December",
            ]
        },
        daysInMonth: [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
        firstDayOfWeek: 0,
        ordinal: function (nth) {
            var s = nth % 100;
            if (s > 3 && s < 21)
                return "th";
            switch (s % 10) {
                case 1:
                    return "st";
                case 2:
                    return "nd";
                case 3:
                    return "rd";
                default:
                    return "th";
            }
        },
        rangeSeparator: " to ",
        weekAbbreviation: "Wk",
        scrollTitle: "Scroll to increment",
        toggleTitle: "Click to toggle",
        amPM: ["AM", "PM"],
        yearAriaLabel: "Year",
        time_24hr: false
    };

    var pad = function (number) { return ("0" + number).slice(-2); };
    var int = function (bool) { return (bool === true ? 1 : 0); };
    /* istanbul ignore next */
    function debounce(func, wait, immediate) {
        if (immediate === void 0) { immediate = false; }
        var timeout;
        return function () {
            var context = this, args = arguments;
            timeout !== null && clearTimeout(timeout);
            timeout = window.setTimeout(function () {
                timeout = null;
                if (!immediate)
                    func.apply(context, args);
            }, wait);
            if (immediate && !timeout)
                func.apply(context, args);
        };
    }
    var arrayify = function (obj) {
        return obj instanceof Array ? obj : [obj];
    };

    function toggleClass(elem, className, bool) {
        if (bool === true)
            return elem.classList.add(className);
        elem.classList.remove(className);
    }
    function createElement(tag, className, content) {
        var e = window.document.createElement(tag);
        className = className || "";
        content = content || "";
        e.className = className;
        if (content !== undefined)
            e.textContent = content;
        return e;
    }
    function clearNode(node) {
        while (node.firstChild)
            node.removeChild(node.firstChild);
    }
    function findParent(node, condition) {
        if (condition(node))
            return node;
        else if (node.parentNode)
            return findParent(node.parentNode, condition);
        return undefined; // nothing found
    }
    function createNumberInput(inputClassName, opts) {
        var wrapper = createElement("div", "numInputWrapper"), numInput = createElement("input", "numInput " + inputClassName), arrowUp = createElement("span", "arrowUp"), arrowDown = createElement("span", "arrowDown");
        if (navigator.userAgent.indexOf("MSIE 9.0") === -1) {
            numInput.type = "number";
        }
        else {
            numInput.type = "text";
            numInput.pattern = "\\d*";
        }
        if (opts !== undefined)
            for (var key in opts)
                numInput.setAttribute(key, opts[key]);
        wrapper.appendChild(numInput);
        wrapper.appendChild(arrowUp);
        wrapper.appendChild(arrowDown);
        return wrapper;
    }
    function getEventTarget(event) {
        if (typeof event.composedPath === "function") {
            var path = event.composedPath();
            return path[0];
        }
        return event.target;
    }

    var doNothing = function () { return undefined; };
    var monthToStr = function (monthNumber, shorthand, locale) { return locale.months[shorthand ? "shorthand" : "longhand"][monthNumber]; };
    var revFormat = {
        D: doNothing,
        F: function (dateObj, monthName, locale) {
            dateObj.setMonth(locale.months.longhand.indexOf(monthName));
        },
        G: function (dateObj, hour) {
            dateObj.setHours(parseFloat(hour));
        },
        H: function (dateObj, hour) {
            dateObj.setHours(parseFloat(hour));
        },
        J: function (dateObj, day) {
            dateObj.setDate(parseFloat(day));
        },
        K: function (dateObj, amPM, locale) {
            dateObj.setHours((dateObj.getHours() % 12) +
                12 * int(new RegExp(locale.amPM[1], "i").test(amPM)));
        },
        M: function (dateObj, shortMonth, locale) {
            dateObj.setMonth(locale.months.shorthand.indexOf(shortMonth));
        },
        S: function (dateObj, seconds) {
            dateObj.setSeconds(parseFloat(seconds));
        },
        U: function (_, unixSeconds) { return new Date(parseFloat(unixSeconds) * 1000); },
        W: function (dateObj, weekNum, locale) {
            var weekNumber = parseInt(weekNum);
            var date = new Date(dateObj.getFullYear(), 0, 2 + (weekNumber - 1) * 7, 0, 0, 0, 0);
            date.setDate(date.getDate() - date.getDay() + locale.firstDayOfWeek);
            return date;
        },
        Y: function (dateObj, year) {
            dateObj.setFullYear(parseFloat(year));
        },
        Z: function (_, ISODate) { return new Date(ISODate); },
        d: function (dateObj, day) {
            dateObj.setDate(parseFloat(day));
        },
        h: function (dateObj, hour) {
            dateObj.setHours(parseFloat(hour));
        },
        i: function (dateObj, minutes) {
            dateObj.setMinutes(parseFloat(minutes));
        },
        j: function (dateObj, day) {
            dateObj.setDate(parseFloat(day));
        },
        l: doNothing,
        m: function (dateObj, month) {
            dateObj.setMonth(parseFloat(month) - 1);
        },
        n: function (dateObj, month) {
            dateObj.setMonth(parseFloat(month) - 1);
        },
        s: function (dateObj, seconds) {
            dateObj.setSeconds(parseFloat(seconds));
        },
        u: function (_, unixMillSeconds) {
            return new Date(parseFloat(unixMillSeconds));
        },
        w: doNothing,
        y: function (dateObj, year) {
            dateObj.setFullYear(2000 + parseFloat(year));
        }
    };
    var tokenRegex = {
        D: "(\\w+)",
        F: "(\\w+)",
        G: "(\\d\\d|\\d)",
        H: "(\\d\\d|\\d)",
        J: "(\\d\\d|\\d)\\w+",
        K: "",
        M: "(\\w+)",
        S: "(\\d\\d|\\d)",
        U: "(.+)",
        W: "(\\d\\d|\\d)",
        Y: "(\\d{4})",
        Z: "(.+)",
        d: "(\\d\\d|\\d)",
        h: "(\\d\\d|\\d)",
        i: "(\\d\\d|\\d)",
        j: "(\\d\\d|\\d)",
        l: "(\\w+)",
        m: "(\\d\\d|\\d)",
        n: "(\\d\\d|\\d)",
        s: "(\\d\\d|\\d)",
        u: "(.+)",
        w: "(\\d\\d|\\d)",
        y: "(\\d{2})"
    };
    var formats = {
        // get the date in UTC
        Z: function (date) { return date.toISOString(); },
        // weekday name, short, e.g. Thu
        D: function (date, locale, options) {
            return locale.weekdays.shorthand[formats.w(date, locale, options)];
        },
        // full month name e.g. January
        F: function (date, locale, options) {
            return monthToStr(formats.n(date, locale, options) - 1, false, locale);
        },
        // padded hour 1-12
        G: function (date, locale, options) {
            return pad(formats.h(date, locale, options));
        },
        // hours with leading zero e.g. 03
        H: function (date) { return pad(date.getHours()); },
        // day (1-30) with ordinal suffix e.g. 1st, 2nd
        J: function (date, locale) {
            return locale.ordinal !== undefined
                ? date.getDate() + locale.ordinal(date.getDate())
                : date.getDate();
        },
        // AM/PM
        K: function (date, locale) { return locale.amPM[int(date.getHours() > 11)]; },
        // shorthand month e.g. Jan, Sep, Oct, etc
        M: function (date, locale) {
            return monthToStr(date.getMonth(), true, locale);
        },
        // seconds 00-59
        S: function (date) { return pad(date.getSeconds()); },
        // unix timestamp
        U: function (date) { return date.getTime() / 1000; },
        W: function (date, _, options) {
            return options.getWeek(date);
        },
        // full year e.g. 2016
        Y: function (date) { return date.getFullYear(); },
        // day in month, padded (01-30)
        d: function (date) { return pad(date.getDate()); },
        // hour from 1-12 (am/pm)
        h: function (date) { return (date.getHours() % 12 ? date.getHours() % 12 : 12); },
        // minutes, padded with leading zero e.g. 09
        i: function (date) { return pad(date.getMinutes()); },
        // day in month (1-30)
        j: function (date) { return date.getDate(); },
        // weekday name, full, e.g. Thursday
        l: function (date, locale) {
            return locale.weekdays.longhand[date.getDay()];
        },
        // padded month number (01-12)
        m: function (date) { return pad(date.getMonth() + 1); },
        // the month number (1-12)
        n: function (date) { return date.getMonth() + 1; },
        // seconds 0-59
        s: function (date) { return date.getSeconds(); },
        // Unix Milliseconds
        u: function (date) { return date.getTime(); },
        // number of the day of the week
        w: function (date) { return date.getDay(); },
        // last two digits of year e.g. 16 for 2016
        y: function (date) { return String(date.getFullYear()).substring(2); }
    };

    var createDateFormatter = function (_a) {
        var _b = _a.config, config = _b === void 0 ? defaults : _b, _c = _a.l10n, l10n = _c === void 0 ? english : _c;
        return function (dateObj, frmt, overrideLocale) {
            var locale = overrideLocale || l10n;
            if (config.formatDate !== undefined) {
                return config.formatDate(dateObj, frmt, locale);
            }
            return frmt
                .split("")
                .map(function (c, i, arr) {
                return formats[c] && arr[i - 1] !== "\\"
                    ? formats[c](dateObj, locale, config)
                    : c !== "\\"
                        ? c
                        : "";
            })
                .join("");
        };
    };
    var createDateParser = function (_a) {
        var _b = _a.config, config = _b === void 0 ? defaults : _b, _c = _a.l10n, l10n = _c === void 0 ? english : _c;
        return function (date, givenFormat, timeless, customLocale) {
            if (date !== 0 && !date)
                return undefined;
            var locale = customLocale || l10n;
            var parsedDate;
            var dateOrig = date;
            if (date instanceof Date)
                parsedDate = new Date(date.getTime());
            else if (typeof date !== "string" &&
                date.toFixed !== undefined // timestamp
            )
                // create a copy
                parsedDate = new Date(date);
            else if (typeof date === "string") {
                // date string
                var format = givenFormat || (config || defaults).dateFormat;
                var datestr = String(date).trim();
                if (datestr === "today") {
                    parsedDate = new Date();
                    timeless = true;
                }
                else if (/Z$/.test(datestr) ||
                    /GMT$/.test(datestr) // datestrings w/ timezone
                )
                    parsedDate = new Date(date);
                else if (config && config.parseDate)
                    parsedDate = config.parseDate(date, format);
                else {
                    parsedDate =
                        !config || !config.noCalendar
                            ? new Date(new Date().getFullYear(), 0, 1, 0, 0, 0, 0)
                            : new Date(new Date().setHours(0, 0, 0, 0));
                    var matched = void 0, ops = [];
                    for (var i = 0, matchIndex = 0, regexStr = ""; i < format.length; i++) {
                        var token_1 = format[i];
                        var isBackSlash = token_1 === "\\";
                        var escaped = format[i - 1] === "\\" || isBackSlash;
                        if (tokenRegex[token_1] && !escaped) {
                            regexStr += tokenRegex[token_1];
                            var match = new RegExp(regexStr).exec(date);
                            if (match && (matched = true)) {
                                ops[token_1 !== "Y" ? "push" : "unshift"]({
                                    fn: revFormat[token_1],
                                    val: match[++matchIndex]
                                });
                            }
                        }
                        else if (!isBackSlash)
                            regexStr += "."; // don't really care
                        ops.forEach(function (_a) {
                            var fn = _a.fn, val = _a.val;
                            return (parsedDate = fn(parsedDate, val, locale) || parsedDate);
                        });
                    }
                    parsedDate = matched ? parsedDate : undefined;
                }
            }
            /* istanbul ignore next */
            if (!(parsedDate instanceof Date && !isNaN(parsedDate.getTime()))) {
                config.errorHandler(new Error("Invalid date provided: " + dateOrig));
                return undefined;
            }
            if (timeless === true)
                parsedDate.setHours(0, 0, 0, 0);
            return parsedDate;
        };
    };
    /**
     * Compute the difference in dates, measured in ms
     */
    function compareDates(date1, date2, timeless) {
        if (timeless === void 0) { timeless = true; }
        if (timeless !== false) {
            return (new Date(date1.getTime()).setHours(0, 0, 0, 0) -
                new Date(date2.getTime()).setHours(0, 0, 0, 0));
        }
        return date1.getTime() - date2.getTime();
    }
    var isBetween = function (ts, ts1, ts2) {
        return ts > Math.min(ts1, ts2) && ts < Math.max(ts1, ts2);
    };
    var duration = {
        DAY: 86400000
    };

    if (typeof Object.assign !== "function") {
        Object.assign = function (target) {
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            if (!target) {
                throw TypeError("Cannot convert undefined or null to object");
            }
            var _loop_1 = function (source) {
                if (source) {
                    Object.keys(source).forEach(function (key) { return (target[key] = source[key]); });
                }
            };
            for (var _a = 0, args_1 = args; _a < args_1.length; _a++) {
                var source = args_1[_a];
                _loop_1(source);
            }
            return target;
        };
    }

    var DEBOUNCED_CHANGE_MS = 300;
    function FlatpickrInstance(element, instanceConfig) {
        var self = {
            config: __assign({}, defaults, flatpickr.defaultConfig),
            l10n: english
        };
        self.parseDate = createDateParser({ config: self.config, l10n: self.l10n });
        self._handlers = [];
        self.pluginElements = [];
        self.loadedPlugins = [];
        self._bind = bind;
        self._setHoursFromDate = setHoursFromDate;
        self._positionCalendar = positionCalendar;
        self.changeMonth = changeMonth;
        self.changeYear = changeYear;
        self.clear = clear;
        self.close = close;
        self._createElement = createElement;
        self.destroy = destroy;
        self.isEnabled = isEnabled;
        self.jumpToDate = jumpToDate;
        self.open = open;
        self.redraw = redraw;
        self.set = set;
        self.setDate = setDate;
        self.toggle = toggle;
        function setupHelperFunctions() {
            self.utils = {
                getDaysInMonth: function (month, yr) {
                    if (month === void 0) { month = self.currentMonth; }
                    if (yr === void 0) { yr = self.currentYear; }
                    if (month === 1 && ((yr % 4 === 0 && yr % 100 !== 0) || yr % 400 === 0))
                        return 29;
                    return self.l10n.daysInMonth[month];
                }
            };
        }
        function init() {
            self.element = self.input = element;
            self.isOpen = false;
            parseConfig();
            setupLocale();
            setupInputs();
            setupDates();
            setupHelperFunctions();
            if (!self.isMobile)
                build();
            bindEvents();
            if (self.selectedDates.length || self.config.noCalendar) {
                if (self.config.enableTime) {
                    setHoursFromDate(self.config.noCalendar
                        ? self.latestSelectedDateObj || self.config.minDate
                        : undefined);
                }
                updateValue(false);
            }
            setCalendarWidth();
            self.showTimeInput =
                self.selectedDates.length > 0 || self.config.noCalendar;
            var isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
            /* TODO: investigate this further
        
              Currently, there is weird positioning behavior in safari causing pages
              to scroll up. https://github.com/chmln/flatpickr/issues/563
        
              However, most browsers are not Safari and positioning is expensive when used
              in scale. https://github.com/chmln/flatpickr/issues/1096
            */
            if (!self.isMobile && isSafari) {
                positionCalendar();
            }
            triggerEvent("onReady");
        }
        function bindToInstance(fn) {
            return fn.bind(self);
        }
        function setCalendarWidth() {
            var config = self.config;
            if (config.weekNumbers === false && config.showMonths === 1)
                return;
            else if (config.noCalendar !== true) {
                window.requestAnimationFrame(function () {
                    if (self.calendarContainer !== undefined) {
                        self.calendarContainer.style.visibility = "hidden";
                        self.calendarContainer.style.display = "block";
                    }
                    if (self.daysContainer !== undefined) {
                        var daysWidth = (self.days.offsetWidth + 1) * config.showMonths;
                        self.daysContainer.style.width = daysWidth + "px";
                        self.calendarContainer.style.width =
                            daysWidth +
                                (self.weekWrapper !== undefined
                                    ? self.weekWrapper.offsetWidth
                                    : 0) +
                                "px";
                        self.calendarContainer.style.removeProperty("visibility");
                        self.calendarContainer.style.removeProperty("display");
                    }
                });
            }
        }
        /**
         * The handler for all events targeting the time inputs
         */
        function updateTime(e) {
            if (self.selectedDates.length === 0) {
                setDefaultTime();
            }
            if (e !== undefined && e.type !== "blur") {
                timeWrapper(e);
            }
            var prevValue = self._input.value;
            setHoursFromInputs();
            updateValue();
            if (self._input.value !== prevValue) {
                self._debouncedChange();
            }
        }
        function ampm2military(hour, amPM) {
            return (hour % 12) + 12 * int(amPM === self.l10n.amPM[1]);
        }
        function military2ampm(hour) {
            switch (hour % 24) {
                case 0:
                case 12:
                    return 12;
                default:
                    return hour % 12;
            }
        }
        /**
         * Syncs the selected date object time with user's time input
         */
        function setHoursFromInputs() {
            if (self.hourElement === undefined || self.minuteElement === undefined)
                return;
            var hours = (parseInt(self.hourElement.value.slice(-2), 10) || 0) % 24, minutes = (parseInt(self.minuteElement.value, 10) || 0) % 60, seconds = self.secondElement !== undefined
                ? (parseInt(self.secondElement.value, 10) || 0) % 60
                : 0;
            if (self.amPM !== undefined) {
                hours = ampm2military(hours, self.amPM.textContent);
            }
            var limitMinHours = self.config.minTime !== undefined ||
                (self.config.minDate &&
                    self.minDateHasTime &&
                    self.latestSelectedDateObj &&
                    compareDates(self.latestSelectedDateObj, self.config.minDate, true) ===
                        0);
            var limitMaxHours = self.config.maxTime !== undefined ||
                (self.config.maxDate &&
                    self.maxDateHasTime &&
                    self.latestSelectedDateObj &&
                    compareDates(self.latestSelectedDateObj, self.config.maxDate, true) ===
                        0);
            if (limitMaxHours) {
                var maxTime = self.config.maxTime !== undefined
                    ? self.config.maxTime
                    : self.config.maxDate;
                hours = Math.min(hours, maxTime.getHours());
                if (hours === maxTime.getHours())
                    minutes = Math.min(minutes, maxTime.getMinutes());
                if (minutes === maxTime.getMinutes())
                    seconds = Math.min(seconds, maxTime.getSeconds());
            }
            if (limitMinHours) {
                var minTime = self.config.minTime !== undefined
                    ? self.config.minTime
                    : self.config.minDate;
                hours = Math.max(hours, minTime.getHours());
                if (hours === minTime.getHours())
                    minutes = Math.max(minutes, minTime.getMinutes());
                if (minutes === minTime.getMinutes())
                    seconds = Math.max(seconds, minTime.getSeconds());
            }
            setHours(hours, minutes, seconds);
        }
        /**
         * Syncs time input values with a date
         */
        function setHoursFromDate(dateObj) {
            var date = dateObj || self.latestSelectedDateObj;
            if (date)
                setHours(date.getHours(), date.getMinutes(), date.getSeconds());
        }
        function setDefaultHours() {
            var hours = self.config.defaultHour;
            var minutes = self.config.defaultMinute;
            var seconds = self.config.defaultSeconds;
            if (self.config.minDate !== undefined) {
                var minHr = self.config.minDate.getHours();
                var minMinutes = self.config.minDate.getMinutes();
                hours = Math.max(hours, minHr);
                if (hours === minHr)
                    minutes = Math.max(minMinutes, minutes);
                if (hours === minHr && minutes === minMinutes)
                    seconds = self.config.minDate.getSeconds();
            }
            if (self.config.maxDate !== undefined) {
                var maxHr = self.config.maxDate.getHours();
                var maxMinutes = self.config.maxDate.getMinutes();
                hours = Math.min(hours, maxHr);
                if (hours === maxHr)
                    minutes = Math.min(maxMinutes, minutes);
                if (hours === maxHr && minutes === maxMinutes)
                    seconds = self.config.maxDate.getSeconds();
            }
            setHours(hours, minutes, seconds);
        }
        /**
         * Sets the hours, minutes, and optionally seconds
         * of the latest selected date object and the
         * corresponding time inputs
         * @param {Number} hours the hour. whether its military
         *                 or am-pm gets inferred from config
         * @param {Number} minutes the minutes
         * @param {Number} seconds the seconds (optional)
         */
        function setHours(hours, minutes, seconds) {
            if (self.latestSelectedDateObj !== undefined) {
                self.latestSelectedDateObj.setHours(hours % 24, minutes, seconds || 0, 0);
            }
            if (!self.hourElement || !self.minuteElement || self.isMobile)
                return;
            self.hourElement.value = pad(!self.config.time_24hr
                ? ((12 + hours) % 12) + 12 * int(hours % 12 === 0)
                : hours);
            self.minuteElement.value = pad(minutes);
            if (self.amPM !== undefined)
                self.amPM.textContent = self.l10n.amPM[int(hours >= 12)];
            if (self.secondElement !== undefined)
                self.secondElement.value = pad(seconds);
        }
        /**
         * Handles the year input and incrementing events
         * @param {Event} event the keyup or increment event
         */
        function onYearInput(event) {
            var year = parseInt(event.target.value) + (event.delta || 0);
            if (year / 1000 > 1 ||
                (event.key === "Enter" && !/[^\d]/.test(year.toString()))) {
                changeYear(year);
            }
        }
        /**
         * Essentially addEventListener + tracking
         * @param {Element} element the element to addEventListener to
         * @param {String} event the event name
         * @param {Function} handler the event handler
         */
        function bind(element, event, handler, options) {
            if (event instanceof Array)
                return event.forEach(function (ev) { return bind(element, ev, handler, options); });
            if (element instanceof Array)
                return element.forEach(function (el) { return bind(el, event, handler, options); });
            element.addEventListener(event, handler, options);
            self._handlers.push({
                element: element,
                event: event,
                handler: handler,
                options: options
            });
        }
        /**
         * A mousedown handler which mimics click.
         * Minimizes latency, since we don't need to wait for mouseup in most cases.
         * Also, avoids handling right clicks.
         *
         * @param {Function} handler the event handler
         */
        function onClick(handler) {
            return function (evt) {
                evt.which === 1 && handler(evt);
            };
        }
        function triggerChange() {
            triggerEvent("onChange");
        }
        /**
         * Adds all the necessary event listeners
         */
        function bindEvents() {
            if (self.config.wrap) {
                ["open", "close", "toggle", "clear"].forEach(function (evt) {
                    Array.prototype.forEach.call(self.element.querySelectorAll("[data-" + evt + "]"), function (el) {
                        return bind(el, "click", self[evt]);
                    });
                });
            }
            if (self.isMobile) {
                setupMobile();
                return;
            }
            var debouncedResize = debounce(onResize, 50);
            self._debouncedChange = debounce(triggerChange, DEBOUNCED_CHANGE_MS);
            if (self.daysContainer && !/iPhone|iPad|iPod/i.test(navigator.userAgent))
                bind(self.daysContainer, "mouseover", function (e) {
                    if (self.config.mode === "range")
                        onMouseOver(e.target);
                });
            bind(window.document.body, "keydown", onKeyDown);
            if (!self.config.inline && !self.config.static)
                bind(window, "resize", debouncedResize);
            if (window.ontouchstart !== undefined)
                bind(window.document, "touchstart", documentClick);
            else
                bind(window.document, "mousedown", onClick(documentClick));
            bind(window.document, "focus", documentClick, { capture: true });
            if (self.config.clickOpens === true) {
                bind(self._input, "focus", self.open);
                bind(self._input, "mousedown", onClick(self.open));
            }
            if (self.daysContainer !== undefined) {
                bind(self.monthNav, "mousedown", onClick(onMonthNavClick));
                bind(self.monthNav, ["keyup", "increment"], onYearInput);
                bind(self.daysContainer, "mousedown", onClick(selectDate));
            }
            if (self.timeContainer !== undefined &&
                self.minuteElement !== undefined &&
                self.hourElement !== undefined) {
                var selText = function (e) {
                    return e.target.select();
                };
                bind(self.timeContainer, ["increment"], updateTime);
                bind(self.timeContainer, "blur", updateTime, { capture: true });
                bind(self.timeContainer, "mousedown", onClick(timeIncrement));
                bind([self.hourElement, self.minuteElement], ["focus", "click"], selText);
                if (self.secondElement !== undefined)
                    bind(self.secondElement, "focus", function () { return self.secondElement && self.secondElement.select(); });
                if (self.amPM !== undefined) {
                    bind(self.amPM, "mousedown", onClick(function (e) {
                        updateTime(e);
                        triggerChange();
                    }));
                }
            }
        }
        /**
         * Set the calendar view to a particular date.
         * @param {Date} jumpDate the date to set the view to
         * @param {boolean} triggerChange if change events should be triggered
         */
        function jumpToDate(jumpDate, triggerChange) {
            var jumpTo = jumpDate !== undefined
                ? self.parseDate(jumpDate)
                : self.latestSelectedDateObj ||
                    (self.config.minDate && self.config.minDate > self.now
                        ? self.config.minDate
                        : self.config.maxDate && self.config.maxDate < self.now
                            ? self.config.maxDate
                            : self.now);
            var oldYear = self.currentYear;
            var oldMonth = self.currentMonth;
            try {
                if (jumpTo !== undefined) {
                    self.currentYear = jumpTo.getFullYear();
                    self.currentMonth = jumpTo.getMonth();
                }
            }
            catch (e) {
                /* istanbul ignore next */
                e.message = "Invalid date supplied: " + jumpTo;
                self.config.errorHandler(e);
            }
            if (triggerChange && self.currentYear !== oldYear) {
                triggerEvent("onYearChange");
                buildMonthSwitch();
            }
            if (triggerChange &&
                (self.currentYear !== oldYear || self.currentMonth !== oldMonth)) {
                triggerEvent("onMonthChange");
            }
            self.redraw();
        }
        /**
         * The up/down arrow handler for time inputs
         * @param {Event} e the click event
         */
        function timeIncrement(e) {
            if (~e.target.className.indexOf("arrow"))
                incrementNumInput(e, e.target.classList.contains("arrowUp") ? 1 : -1);
        }
        /**
         * Increments/decrements the value of input associ-
         * ated with the up/down arrow by dispatching an
         * "increment" event on the input.
         *
         * @param {Event} e the click event
         * @param {Number} delta the diff (usually 1 or -1)
         * @param {Element} inputElem the input element
         */
        function incrementNumInput(e, delta, inputElem) {
            var target = e && e.target;
            var input = inputElem ||
                (target && target.parentNode && target.parentNode.firstChild);
            var event = createEvent("increment");
            event.delta = delta;
            input && input.dispatchEvent(event);
        }
        function build() {
            var fragment = window.document.createDocumentFragment();
            self.calendarContainer = createElement("div", "flatpickr-calendar");
            self.calendarContainer.tabIndex = -1;
            if (!self.config.noCalendar) {
                fragment.appendChild(buildMonthNav());
                self.innerContainer = createElement("div", "flatpickr-innerContainer");
                if (self.config.weekNumbers) {
                    var _a = buildWeeks(), weekWrapper = _a.weekWrapper, weekNumbers = _a.weekNumbers;
                    self.innerContainer.appendChild(weekWrapper);
                    self.weekNumbers = weekNumbers;
                    self.weekWrapper = weekWrapper;
                }
                self.rContainer = createElement("div", "flatpickr-rContainer");
                self.rContainer.appendChild(buildWeekdays());
                if (!self.daysContainer) {
                    self.daysContainer = createElement("div", "flatpickr-days");
                    self.daysContainer.tabIndex = -1;
                }
                buildDays();
                self.rContainer.appendChild(self.daysContainer);
                self.innerContainer.appendChild(self.rContainer);
                fragment.appendChild(self.innerContainer);
            }
            if (self.config.enableTime) {
                fragment.appendChild(buildTime());
            }
            toggleClass(self.calendarContainer, "rangeMode", self.config.mode === "range");
            toggleClass(self.calendarContainer, "animate", self.config.animate === true);
            toggleClass(self.calendarContainer, "multiMonth", self.config.showMonths > 1);
            self.calendarContainer.appendChild(fragment);
            var customAppend = self.config.appendTo !== undefined &&
                self.config.appendTo.nodeType !== undefined;
            if (self.config.inline || self.config.static) {
                self.calendarContainer.classList.add(self.config.inline ? "inline" : "static");
                if (self.config.inline) {
                    if (!customAppend && self.element.parentNode)
                        self.element.parentNode.insertBefore(self.calendarContainer, self._input.nextSibling);
                    else if (self.config.appendTo !== undefined)
                        self.config.appendTo.appendChild(self.calendarContainer);
                }
                if (self.config.static) {
                    var wrapper = createElement("div", "flatpickr-wrapper");
                    if (self.element.parentNode)
                        self.element.parentNode.insertBefore(wrapper, self.element);
                    wrapper.appendChild(self.element);
                    if (self.altInput)
                        wrapper.appendChild(self.altInput);
                    wrapper.appendChild(self.calendarContainer);
                }
            }
            if (!self.config.static && !self.config.inline)
                (self.config.appendTo !== undefined
                    ? self.config.appendTo
                    : window.document.body).appendChild(self.calendarContainer);
        }
        function createDay(className, date, dayNumber, i) {
            var dateIsEnabled = isEnabled(date, true), dayElement = createElement("span", "flatpickr-day " + className, date.getDate().toString());
            dayElement.dateObj = date;
            dayElement.$i = i;
            dayElement.setAttribute("aria-label", self.formatDate(date, self.config.ariaDateFormat));
            if (className.indexOf("hidden") === -1 &&
                compareDates(date, self.now) === 0) {
                self.todayDateElem = dayElement;
                dayElement.classList.add("today");
                dayElement.setAttribute("aria-current", "date");
            }
            if (dateIsEnabled) {
                dayElement.tabIndex = -1;
                if (isDateSelected(date)) {
                    dayElement.classList.add("selected");
                    self.selectedDateElem = dayElement;
                    if (self.config.mode === "range") {
                        toggleClass(dayElement, "startRange", self.selectedDates[0] &&
                            compareDates(date, self.selectedDates[0], true) === 0);
                        toggleClass(dayElement, "endRange", self.selectedDates[1] &&
                            compareDates(date, self.selectedDates[1], true) === 0);
                        if (className === "nextMonthDay")
                            dayElement.classList.add("inRange");
                    }
                }
            }
            else {
                dayElement.classList.add("flatpickr-disabled");
            }
            if (self.config.mode === "range") {
                if (isDateInRange(date) && !isDateSelected(date))
                    dayElement.classList.add("inRange");
            }
            if (self.weekNumbers &&
                self.config.showMonths === 1 &&
                className !== "prevMonthDay" &&
                dayNumber % 7 === 1) {
                self.weekNumbers.insertAdjacentHTML("beforeend", "<span class='flatpickr-day'>" + self.config.getWeek(date) + "</span>");
            }
            triggerEvent("onDayCreate", dayElement);
            return dayElement;
        }
        function focusOnDayElem(targetNode) {
            targetNode.focus();
            if (self.config.mode === "range")
                onMouseOver(targetNode);
        }
        function getFirstAvailableDay(delta) {
            var startMonth = delta > 0 ? 0 : self.config.showMonths - 1;
            var endMonth = delta > 0 ? self.config.showMonths : -1;
            for (var m = startMonth; m != endMonth; m += delta) {
                var month = self.daysContainer.children[m];
                var startIndex = delta > 0 ? 0 : month.children.length - 1;
                var endIndex = delta > 0 ? month.children.length : -1;
                for (var i = startIndex; i != endIndex; i += delta) {
                    var c = month.children[i];
                    if (c.className.indexOf("hidden") === -1 && isEnabled(c.dateObj))
                        return c;
                }
            }
            return undefined;
        }
        function getNextAvailableDay(current, delta) {
            var givenMonth = current.className.indexOf("Month") === -1
                ? current.dateObj.getMonth()
                : self.currentMonth;
            var endMonth = delta > 0 ? self.config.showMonths : -1;
            var loopDelta = delta > 0 ? 1 : -1;
            for (var m = givenMonth - self.currentMonth; m != endMonth; m += loopDelta) {
                var month = self.daysContainer.children[m];
                var startIndex = givenMonth - self.currentMonth === m
                    ? current.$i + delta
                    : delta < 0
                        ? month.children.length - 1
                        : 0;
                var numMonthDays = month.children.length;
                for (var i = startIndex; i >= 0 && i < numMonthDays && i != (delta > 0 ? numMonthDays : -1); i += loopDelta) {
                    var c = month.children[i];
                    if (c.className.indexOf("hidden") === -1 &&
                        isEnabled(c.dateObj) &&
                        Math.abs(current.$i - i) >= Math.abs(delta))
                        return focusOnDayElem(c);
                }
            }
            self.changeMonth(loopDelta);
            focusOnDay(getFirstAvailableDay(loopDelta), 0);
            return undefined;
        }
        function focusOnDay(current, offset) {
            var dayFocused = isInView(document.activeElement || document.body);
            var startElem = current !== undefined
                ? current
                : dayFocused
                    ? document.activeElement
                    : self.selectedDateElem !== undefined && isInView(self.selectedDateElem)
                        ? self.selectedDateElem
                        : self.todayDateElem !== undefined && isInView(self.todayDateElem)
                            ? self.todayDateElem
                            : getFirstAvailableDay(offset > 0 ? 1 : -1);
            if (startElem === undefined)
                return self._input.focus();
            if (!dayFocused)
                return focusOnDayElem(startElem);
            getNextAvailableDay(startElem, offset);
        }
        function buildMonthDays(year, month) {
            var firstOfMonth = (new Date(year, month, 1).getDay() - self.l10n.firstDayOfWeek + 7) % 7;
            var prevMonthDays = self.utils.getDaysInMonth((month - 1 + 12) % 12);
            var daysInMonth = self.utils.getDaysInMonth(month), days = window.document.createDocumentFragment(), isMultiMonth = self.config.showMonths > 1, prevMonthDayClass = isMultiMonth ? "prevMonthDay hidden" : "prevMonthDay", nextMonthDayClass = isMultiMonth ? "nextMonthDay hidden" : "nextMonthDay";
            var dayNumber = prevMonthDays + 1 - firstOfMonth, dayIndex = 0;
            // prepend days from the ending of previous month
            for (; dayNumber <= prevMonthDays; dayNumber++, dayIndex++) {
                days.appendChild(createDay(prevMonthDayClass, new Date(year, month - 1, dayNumber), dayNumber, dayIndex));
            }
            // Start at 1 since there is no 0th day
            for (dayNumber = 1; dayNumber <= daysInMonth; dayNumber++, dayIndex++) {
                days.appendChild(createDay("", new Date(year, month, dayNumber), dayNumber, dayIndex));
            }
            // append days from the next month
            for (var dayNum = daysInMonth + 1; dayNum <= 42 - firstOfMonth &&
                (self.config.showMonths === 1 || dayIndex % 7 !== 0); dayNum++, dayIndex++) {
                days.appendChild(createDay(nextMonthDayClass, new Date(year, month + 1, dayNum % daysInMonth), dayNum, dayIndex));
            }
            //updateNavigationCurrentMonth();
            var dayContainer = createElement("div", "dayContainer");
            dayContainer.appendChild(days);
            return dayContainer;
        }
        function buildDays() {
            if (self.daysContainer === undefined) {
                return;
            }
            clearNode(self.daysContainer);
            // TODO: week numbers for each month
            if (self.weekNumbers)
                clearNode(self.weekNumbers);
            var frag = document.createDocumentFragment();
            for (var i = 0; i < self.config.showMonths; i++) {
                var d = new Date(self.currentYear, self.currentMonth, 1);
                d.setMonth(self.currentMonth + i);
                frag.appendChild(buildMonthDays(d.getFullYear(), d.getMonth()));
            }
            self.daysContainer.appendChild(frag);
            self.days = self.daysContainer.firstChild;
            if (self.config.mode === "range" && self.selectedDates.length === 1) {
                onMouseOver();
            }
        }
        function buildMonthSwitch() {
            if (self.config.showMonths > 1)
                return;
            var shouldBuildMonth = function (month) {
                if (self.config.minDate !== undefined &&
                    self.currentYear === self.config.minDate.getFullYear() &&
                    month < self.config.minDate.getMonth()) {
                    return false;
                }
                return !(self.config.maxDate !== undefined &&
                    self.currentYear === self.config.maxDate.getFullYear() &&
                    month > self.config.maxDate.getMonth());
            };
            self.monthsDropdownContainer.tabIndex = -1;
            self.monthsDropdownContainer.innerHTML = "";
            for (var i = 0; i < 12; i++) {
                if (!shouldBuildMonth(i))
                    continue;
                var month = createElement("option", "flatpickr-monthDropdown-month");
                month.value = new Date(self.currentYear, i).getMonth().toString();
                month.textContent = monthToStr(i, false, self.l10n);
                month.tabIndex = -1;
                if (self.currentMonth === i) {
                    month.selected = true;
                }
                self.monthsDropdownContainer.appendChild(month);
            }
        }
        function buildMonth() {
            var container = createElement("div", "flatpickr-month");
            var monthNavFragment = window.document.createDocumentFragment();
            var monthElement;
            if (self.config.showMonths > 1) {
                monthElement = createElement("span", "cur-month");
            }
            else {
                self.monthsDropdownContainer = createElement("select", "flatpickr-monthDropdown-months");
                bind(self.monthsDropdownContainer, "change", function (e) {
                    var target = e.target;
                    var selectedMonth = parseInt(target.value, 10);
                    self.changeMonth(selectedMonth - self.currentMonth);
                    triggerEvent("onMonthChange");
                });
                buildMonthSwitch();
                monthElement = self.monthsDropdownContainer;
            }
            var yearInput = createNumberInput("cur-year", { tabindex: "-1" });
            var yearElement = yearInput.getElementsByTagName("input")[0];
            yearElement.setAttribute("aria-label", self.l10n.yearAriaLabel);
            if (self.config.minDate) {
                yearElement.setAttribute("min", self.config.minDate.getFullYear().toString());
            }
            if (self.config.maxDate) {
                yearElement.setAttribute("max", self.config.maxDate.getFullYear().toString());
                yearElement.disabled =
                    !!self.config.minDate &&
                        self.config.minDate.getFullYear() === self.config.maxDate.getFullYear();
            }
            var currentMonth = createElement("div", "flatpickr-current-month");
            currentMonth.appendChild(monthElement);
            currentMonth.appendChild(yearInput);
            monthNavFragment.appendChild(currentMonth);
            container.appendChild(monthNavFragment);
            return {
                container: container,
                yearElement: yearElement,
                monthElement: monthElement
            };
        }
        function buildMonths() {
            clearNode(self.monthNav);
            self.monthNav.appendChild(self.prevMonthNav);
            if (self.config.showMonths) {
                self.yearElements = [];
                self.monthElements = [];
            }
            for (var m = self.config.showMonths; m--;) {
                var month = buildMonth();
                self.yearElements.push(month.yearElement);
                self.monthElements.push(month.monthElement);
                self.monthNav.appendChild(month.container);
            }
            self.monthNav.appendChild(self.nextMonthNav);
        }
        function buildMonthNav() {
            self.monthNav = createElement("div", "flatpickr-months");
            self.yearElements = [];
            self.monthElements = [];
            self.prevMonthNav = createElement("span", "flatpickr-prev-month");
            self.prevMonthNav.innerHTML = self.config.prevArrow;
            self.nextMonthNav = createElement("span", "flatpickr-next-month");
            self.nextMonthNav.innerHTML = self.config.nextArrow;
            buildMonths();
            Object.defineProperty(self, "_hidePrevMonthArrow", {
                get: function () { return self.__hidePrevMonthArrow; },
                set: function (bool) {
                    if (self.__hidePrevMonthArrow !== bool) {
                        toggleClass(self.prevMonthNav, "flatpickr-disabled", bool);
                        self.__hidePrevMonthArrow = bool;
                    }
                }
            });
            Object.defineProperty(self, "_hideNextMonthArrow", {
                get: function () { return self.__hideNextMonthArrow; },
                set: function (bool) {
                    if (self.__hideNextMonthArrow !== bool) {
                        toggleClass(self.nextMonthNav, "flatpickr-disabled", bool);
                        self.__hideNextMonthArrow = bool;
                    }
                }
            });
            self.currentYearElement = self.yearElements[0];
            updateNavigationCurrentMonth();
            return self.monthNav;
        }
        function buildTime() {
            self.calendarContainer.classList.add("hasTime");
            if (self.config.noCalendar)
                self.calendarContainer.classList.add("noCalendar");
            self.timeContainer = createElement("div", "flatpickr-time");
            self.timeContainer.tabIndex = -1;
            var separator = createElement("span", "flatpickr-time-separator", ":");
            var hourInput = createNumberInput("flatpickr-hour");
            self.hourElement = hourInput.getElementsByTagName("input")[0];
            var minuteInput = createNumberInput("flatpickr-minute");
            self.minuteElement = minuteInput.getElementsByTagName("input")[0];
            self.hourElement.tabIndex = self.minuteElement.tabIndex = -1;
            self.hourElement.value = pad(self.latestSelectedDateObj
                ? self.latestSelectedDateObj.getHours()
                : self.config.time_24hr
                    ? self.config.defaultHour
                    : military2ampm(self.config.defaultHour));
            self.minuteElement.value = pad(self.latestSelectedDateObj
                ? self.latestSelectedDateObj.getMinutes()
                : self.config.defaultMinute);
            self.hourElement.setAttribute("step", self.config.hourIncrement.toString());
            self.minuteElement.setAttribute("step", self.config.minuteIncrement.toString());
            self.hourElement.setAttribute("min", self.config.time_24hr ? "0" : "1");
            self.hourElement.setAttribute("max", self.config.time_24hr ? "23" : "12");
            self.minuteElement.setAttribute("min", "0");
            self.minuteElement.setAttribute("max", "59");
            self.timeContainer.appendChild(hourInput);
            self.timeContainer.appendChild(separator);
            self.timeContainer.appendChild(minuteInput);
            if (self.config.time_24hr)
                self.timeContainer.classList.add("time24hr");
            if (self.config.enableSeconds) {
                self.timeContainer.classList.add("hasSeconds");
                var secondInput = createNumberInput("flatpickr-second");
                self.secondElement = secondInput.getElementsByTagName("input")[0];
                self.secondElement.value = pad(self.latestSelectedDateObj
                    ? self.latestSelectedDateObj.getSeconds()
                    : self.config.defaultSeconds);
                self.secondElement.setAttribute("step", self.minuteElement.getAttribute("step"));
                self.secondElement.setAttribute("min", "0");
                self.secondElement.setAttribute("max", "59");
                self.timeContainer.appendChild(createElement("span", "flatpickr-time-separator", ":"));
                self.timeContainer.appendChild(secondInput);
            }
            if (!self.config.time_24hr) {
                // add self.amPM if appropriate
                self.amPM = createElement("span", "flatpickr-am-pm", self.l10n.amPM[int((self.latestSelectedDateObj
                    ? self.hourElement.value
                    : self.config.defaultHour) > 11)]);
                self.amPM.title = self.l10n.toggleTitle;
                self.amPM.tabIndex = -1;
                self.timeContainer.appendChild(self.amPM);
            }
            return self.timeContainer;
        }
        function buildWeekdays() {
            if (!self.weekdayContainer)
                self.weekdayContainer = createElement("div", "flatpickr-weekdays");
            else
                clearNode(self.weekdayContainer);
            for (var i = self.config.showMonths; i--;) {
                var container = createElement("div", "flatpickr-weekdaycontainer");
                self.weekdayContainer.appendChild(container);
            }
            updateWeekdays();
            return self.weekdayContainer;
        }
        function updateWeekdays() {
            var firstDayOfWeek = self.l10n.firstDayOfWeek;
            var weekdays = self.l10n.weekdays.shorthand.slice();
            if (firstDayOfWeek > 0 && firstDayOfWeek < weekdays.length) {
                weekdays = weekdays.splice(firstDayOfWeek, weekdays.length).concat(weekdays.splice(0, firstDayOfWeek));
            }
            for (var i = self.config.showMonths; i--;) {
                self.weekdayContainer.children[i].innerHTML = "\n      <span class='flatpickr-weekday'>\n        " + weekdays.join("</span><span class='flatpickr-weekday'>") + "\n      </span>\n      ";
            }
        }
        /* istanbul ignore next */
        function buildWeeks() {
            self.calendarContainer.classList.add("hasWeeks");
            var weekWrapper = createElement("div", "flatpickr-weekwrapper");
            weekWrapper.appendChild(createElement("span", "flatpickr-weekday", self.l10n.weekAbbreviation));
            var weekNumbers = createElement("div", "flatpickr-weeks");
            weekWrapper.appendChild(weekNumbers);
            return {
                weekWrapper: weekWrapper,
                weekNumbers: weekNumbers
            };
        }
        function changeMonth(value, isOffset) {
            if (isOffset === void 0) { isOffset = true; }
            var delta = isOffset ? value : value - self.currentMonth;
            if ((delta < 0 && self._hidePrevMonthArrow === true) ||
                (delta > 0 && self._hideNextMonthArrow === true))
                return;
            self.currentMonth += delta;
            if (self.currentMonth < 0 || self.currentMonth > 11) {
                self.currentYear += self.currentMonth > 11 ? 1 : -1;
                self.currentMonth = (self.currentMonth + 12) % 12;
                triggerEvent("onYearChange");
                buildMonthSwitch();
            }
            buildDays();
            triggerEvent("onMonthChange");
            updateNavigationCurrentMonth();
        }
        function clear(triggerChangeEvent, toInitial) {
            if (triggerChangeEvent === void 0) { triggerChangeEvent = true; }
            if (toInitial === void 0) { toInitial = true; }
            self.input.value = "";
            if (self.altInput !== undefined)
                self.altInput.value = "";
            if (self.mobileInput !== undefined)
                self.mobileInput.value = "";
            self.selectedDates = [];
            self.latestSelectedDateObj = undefined;
            if (toInitial === true) {
                self.currentYear = self._initialDate.getFullYear();
                self.currentMonth = self._initialDate.getMonth();
            }
            self.showTimeInput = false;
            if (self.config.enableTime === true) {
                setDefaultHours();
            }
            self.redraw();
            if (triggerChangeEvent)
                // triggerChangeEvent is true (default) or an Event
                triggerEvent("onChange");
        }
        function close() {
            self.isOpen = false;
            if (!self.isMobile) {
                if (self.calendarContainer !== undefined) {
                    self.calendarContainer.classList.remove("open");
                }
                if (self._input !== undefined) {
                    self._input.classList.remove("active");
                }
            }
            triggerEvent("onClose");
        }
        function destroy() {
            if (self.config !== undefined)
                triggerEvent("onDestroy");
            for (var i = self._handlers.length; i--;) {
                var h = self._handlers[i];
                h.element.removeEventListener(h.event, h.handler, h.options);
            }
            self._handlers = [];
            if (self.mobileInput) {
                if (self.mobileInput.parentNode)
                    self.mobileInput.parentNode.removeChild(self.mobileInput);
                self.mobileInput = undefined;
            }
            else if (self.calendarContainer && self.calendarContainer.parentNode) {
                if (self.config.static && self.calendarContainer.parentNode) {
                    var wrapper = self.calendarContainer.parentNode;
                    wrapper.lastChild && wrapper.removeChild(wrapper.lastChild);
                    if (wrapper.parentNode) {
                        while (wrapper.firstChild)
                            wrapper.parentNode.insertBefore(wrapper.firstChild, wrapper);
                        wrapper.parentNode.removeChild(wrapper);
                    }
                }
                else
                    self.calendarContainer.parentNode.removeChild(self.calendarContainer);
            }
            if (self.altInput) {
                self.input.type = "text";
                if (self.altInput.parentNode)
                    self.altInput.parentNode.removeChild(self.altInput);
                delete self.altInput;
            }
            if (self.input) {
                self.input.type = self.input._type;
                self.input.classList.remove("flatpickr-input");
                self.input.removeAttribute("readonly");
                self.input.value = "";
            }
            [
                "_showTimeInput",
                "latestSelectedDateObj",
                "_hideNextMonthArrow",
                "_hidePrevMonthArrow",
                "__hideNextMonthArrow",
                "__hidePrevMonthArrow",
                "isMobile",
                "isOpen",
                "selectedDateElem",
                "minDateHasTime",
                "maxDateHasTime",
                "days",
                "daysContainer",
                "_input",
                "_positionElement",
                "innerContainer",
                "rContainer",
                "monthNav",
                "todayDateElem",
                "calendarContainer",
                "weekdayContainer",
                "prevMonthNav",
                "nextMonthNav",
                "monthsDropdownContainer",
                "currentMonthElement",
                "currentYearElement",
                "navigationCurrentMonth",
                "selectedDateElem",
                "config",
            ].forEach(function (k) {
                try {
                    delete self[k];
                }
                catch (_) { }
            });
        }
        function isCalendarElem(elem) {
            if (self.config.appendTo && self.config.appendTo.contains(elem))
                return true;
            return self.calendarContainer.contains(elem);
        }
        function documentClick(e) {
            if (self.isOpen && !self.config.inline) {
                var eventTarget_1 = getEventTarget(e);
                var isCalendarElement = isCalendarElem(eventTarget_1);
                var isInput = eventTarget_1 === self.input ||
                    eventTarget_1 === self.altInput ||
                    self.element.contains(eventTarget_1) ||
                    // web components
                    // e.path is not present in all browsers. circumventing typechecks
                    (e.path &&
                        e.path.indexOf &&
                        (~e.path.indexOf(self.input) ||
                            ~e.path.indexOf(self.altInput)));
                var lostFocus = e.type === "blur"
                    ? isInput &&
                        e.relatedTarget &&
                        !isCalendarElem(e.relatedTarget)
                    : !isInput &&
                        !isCalendarElement &&
                        !isCalendarElem(e.relatedTarget);
                var isIgnored = !self.config.ignoredFocusElements.some(function (elem) {
                    return elem.contains(eventTarget_1);
                });
                if (lostFocus && isIgnored) {
                    self.close();
                    if (self.config.mode === "range" && self.selectedDates.length === 1) {
                        self.clear(false);
                        self.redraw();
                    }
                }
            }
        }
        function changeYear(newYear) {
            if (!newYear ||
                (self.config.minDate && newYear < self.config.minDate.getFullYear()) ||
                (self.config.maxDate && newYear > self.config.maxDate.getFullYear()))
                return;
            var newYearNum = newYear, isNewYear = self.currentYear !== newYearNum;
            self.currentYear = newYearNum || self.currentYear;
            if (self.config.maxDate &&
                self.currentYear === self.config.maxDate.getFullYear()) {
                self.currentMonth = Math.min(self.config.maxDate.getMonth(), self.currentMonth);
            }
            else if (self.config.minDate &&
                self.currentYear === self.config.minDate.getFullYear()) {
                self.currentMonth = Math.max(self.config.minDate.getMonth(), self.currentMonth);
            }
            if (isNewYear) {
                self.redraw();
                triggerEvent("onYearChange");
                buildMonthSwitch();
            }
        }
        function isEnabled(date, timeless) {
            if (timeless === void 0) { timeless = true; }
            var dateToCheck = self.parseDate(date, undefined, timeless); // timeless
            if ((self.config.minDate &&
                dateToCheck &&
                compareDates(dateToCheck, self.config.minDate, timeless !== undefined ? timeless : !self.minDateHasTime) < 0) ||
                (self.config.maxDate &&
                    dateToCheck &&
                    compareDates(dateToCheck, self.config.maxDate, timeless !== undefined ? timeless : !self.maxDateHasTime) > 0))
                return false;
            if (self.config.enable.length === 0 && self.config.disable.length === 0)
                return true;
            if (dateToCheck === undefined)
                return false;
            var bool = self.config.enable.length > 0, array = bool ? self.config.enable : self.config.disable;
            for (var i = 0, d = void 0; i < array.length; i++) {
                d = array[i];
                if (typeof d === "function" &&
                    d(dateToCheck) // disabled by function
                )
                    return bool;
                else if (d instanceof Date &&
                    dateToCheck !== undefined &&
                    d.getTime() === dateToCheck.getTime())
                    // disabled by date
                    return bool;
                else if (typeof d === "string" && dateToCheck !== undefined) {
                    // disabled by date string
                    var parsed = self.parseDate(d, undefined, true);
                    return parsed && parsed.getTime() === dateToCheck.getTime()
                        ? bool
                        : !bool;
                }
                else if (
                // disabled by range
                typeof d === "object" &&
                    dateToCheck !== undefined &&
                    d.from &&
                    d.to &&
                    dateToCheck.getTime() >= d.from.getTime() &&
                    dateToCheck.getTime() <= d.to.getTime())
                    return bool;
            }
            return !bool;
        }
        function isInView(elem) {
            if (self.daysContainer !== undefined)
                return (elem.className.indexOf("hidden") === -1 &&
                    self.daysContainer.contains(elem));
            return false;
        }
        function onKeyDown(e) {
            // e.key                      e.keyCode
            // "Backspace"                        8
            // "Tab"                              9
            // "Enter"                           13
            // "Escape"     (IE "Esc")           27
            // "ArrowLeft"  (IE "Left")          37
            // "ArrowUp"    (IE "Up")            38
            // "ArrowRight" (IE "Right")         39
            // "ArrowDown"  (IE "Down")          40
            // "Delete"     (IE "Del")           46
            var isInput = e.target === self._input;
            var allowInput = self.config.allowInput;
            var allowKeydown = self.isOpen && (!allowInput || !isInput);
            var allowInlineKeydown = self.config.inline && isInput && !allowInput;
            if (e.keyCode === 13 && isInput) {
                if (allowInput) {
                    self.setDate(self._input.value, true, e.target === self.altInput
                        ? self.config.altFormat
                        : self.config.dateFormat);
                    return e.target.blur();
                }
                else {
                    self.open();
                }
            }
            else if (isCalendarElem(e.target) ||
                allowKeydown ||
                allowInlineKeydown) {
                var isTimeObj = !!self.timeContainer &&
                    self.timeContainer.contains(e.target);
                switch (e.keyCode) {
                    case 13:
                        if (isTimeObj) {
                            e.preventDefault();
                            updateTime();
                            focusAndClose();
                        }
                        else
                            selectDate(e);
                        break;
                    case 27: // escape
                        e.preventDefault();
                        focusAndClose();
                        break;
                    case 8:
                    case 46:
                        if (isInput && !self.config.allowInput) {
                            e.preventDefault();
                            self.clear();
                        }
                        break;
                    case 37:
                    case 39:
                        if (!isTimeObj && !isInput) {
                            e.preventDefault();
                            if (self.daysContainer !== undefined &&
                                (allowInput === false ||
                                    (document.activeElement && isInView(document.activeElement)))) {
                                var delta_1 = e.keyCode === 39 ? 1 : -1;
                                if (!e.ctrlKey)
                                    focusOnDay(undefined, delta_1);
                                else {
                                    e.stopPropagation();
                                    changeMonth(delta_1);
                                    focusOnDay(getFirstAvailableDay(1), 0);
                                }
                            }
                        }
                        else if (self.hourElement)
                            self.hourElement.focus();
                        break;
                    case 38:
                    case 40:
                        e.preventDefault();
                        var delta = e.keyCode === 40 ? 1 : -1;
                        if ((self.daysContainer && e.target.$i !== undefined) ||
                            e.target === self.input) {
                            if (e.ctrlKey) {
                                e.stopPropagation();
                                changeYear(self.currentYear - delta);
                                focusOnDay(getFirstAvailableDay(1), 0);
                            }
                            else if (!isTimeObj)
                                focusOnDay(undefined, delta * 7);
                        }
                        else if (e.target === self.currentYearElement) {
                            changeYear(self.currentYear - delta);
                        }
                        else if (self.config.enableTime) {
                            if (!isTimeObj && self.hourElement)
                                self.hourElement.focus();
                            updateTime(e);
                            self._debouncedChange();
                        }
                        break;
                    case 9:
                        if (isTimeObj) {
                            var elems = [
                                self.hourElement,
                                self.minuteElement,
                                self.secondElement,
                                self.amPM,
                            ]
                                .concat(self.pluginElements)
                                .filter(function (x) { return x; });
                            var i = elems.indexOf(e.target);
                            if (i !== -1) {
                                var target = elems[i + (e.shiftKey ? -1 : 1)];
                                e.preventDefault();
                                (target || self._input).focus();
                            }
                        }
                        else if (!self.config.noCalendar &&
                            self.daysContainer &&
                            self.daysContainer.contains(e.target) &&
                            e.shiftKey) {
                            e.preventDefault();
                            self._input.focus();
                        }
                        break;
                    default:
                        break;
                }
            }
            if (self.amPM !== undefined && e.target === self.amPM) {
                switch (e.key) {
                    case self.l10n.amPM[0].charAt(0):
                    case self.l10n.amPM[0].charAt(0).toLowerCase():
                        self.amPM.textContent = self.l10n.amPM[0];
                        setHoursFromInputs();
                        updateValue();
                        break;
                    case self.l10n.amPM[1].charAt(0):
                    case self.l10n.amPM[1].charAt(0).toLowerCase():
                        self.amPM.textContent = self.l10n.amPM[1];
                        setHoursFromInputs();
                        updateValue();
                        break;
                }
            }
            if (isInput || isCalendarElem(e.target)) {
                triggerEvent("onKeyDown", e);
            }
        }
        function onMouseOver(elem) {
            if (self.selectedDates.length !== 1 ||
                (elem &&
                    (!elem.classList.contains("flatpickr-day") ||
                        elem.classList.contains("flatpickr-disabled"))))
                return;
            var hoverDate = elem
                ? elem.dateObj.getTime()
                : self.days.firstElementChild.dateObj.getTime(), initialDate = self.parseDate(self.selectedDates[0], undefined, true).getTime(), rangeStartDate = Math.min(hoverDate, self.selectedDates[0].getTime()), rangeEndDate = Math.max(hoverDate, self.selectedDates[0].getTime());
            var containsDisabled = false;
            var minRange = 0, maxRange = 0;
            for (var t = rangeStartDate; t < rangeEndDate; t += duration.DAY) {
                if (!isEnabled(new Date(t), true)) {
                    containsDisabled =
                        containsDisabled || (t > rangeStartDate && t < rangeEndDate);
                    if (t < initialDate && (!minRange || t > minRange))
                        minRange = t;
                    else if (t > initialDate && (!maxRange || t < maxRange))
                        maxRange = t;
                }
            }
            for (var m = 0; m < self.config.showMonths; m++) {
                var month = self.daysContainer.children[m];
                var _loop_1 = function (i, l) {
                    var dayElem = month.children[i], date = dayElem.dateObj;
                    var timestamp = date.getTime();
                    var outOfRange = (minRange > 0 && timestamp < minRange) ||
                        (maxRange > 0 && timestamp > maxRange);
                    if (outOfRange) {
                        dayElem.classList.add("notAllowed");
                        ["inRange", "startRange", "endRange"].forEach(function (c) {
                            dayElem.classList.remove(c);
                        });
                        return "continue";
                    }
                    else if (containsDisabled && !outOfRange)
                        return "continue";
                    ["startRange", "inRange", "endRange", "notAllowed"].forEach(function (c) {
                        dayElem.classList.remove(c);
                    });
                    if (elem !== undefined) {
                        elem.classList.add(hoverDate <= self.selectedDates[0].getTime()
                            ? "startRange"
                            : "endRange");
                        if (initialDate < hoverDate && timestamp === initialDate)
                            dayElem.classList.add("startRange");
                        else if (initialDate > hoverDate && timestamp === initialDate)
                            dayElem.classList.add("endRange");
                        if (timestamp >= minRange &&
                            (maxRange === 0 || timestamp <= maxRange) &&
                            isBetween(timestamp, initialDate, hoverDate))
                            dayElem.classList.add("inRange");
                    }
                };
                for (var i = 0, l = month.children.length; i < l; i++) {
                    _loop_1(i, l);
                }
            }
        }
        function onResize() {
            if (self.isOpen && !self.config.static && !self.config.inline)
                positionCalendar();
        }
        function setDefaultTime() {
            self.setDate(self.config.minDate !== undefined
                ? new Date(self.config.minDate.getTime())
                : new Date(), true);
            setDefaultHours();
            updateValue();
        }
        function open(e, positionElement) {
            if (positionElement === void 0) { positionElement = self._positionElement; }
            if (self.isMobile === true) {
                if (e) {
                    e.preventDefault();
                    e.target && e.target.blur();
                }
                if (self.mobileInput !== undefined) {
                    self.mobileInput.focus();
                    self.mobileInput.click();
                }
                triggerEvent("onOpen");
                return;
            }
            if (self._input.disabled || self.config.inline)
                return;
            var wasOpen = self.isOpen;
            self.isOpen = true;
            if (!wasOpen) {
                self.calendarContainer.classList.add("open");
                self._input.classList.add("active");
                triggerEvent("onOpen");
                positionCalendar(positionElement);
            }
            if (self.config.enableTime === true && self.config.noCalendar === true) {
                if (self.selectedDates.length === 0) {
                    setDefaultTime();
                }
                if (self.config.allowInput === false &&
                    (e === undefined ||
                        !self.timeContainer.contains(e.relatedTarget))) {
                    setTimeout(function () { return self.hourElement.select(); }, 50);
                }
            }
        }
        function minMaxDateSetter(type) {
            return function (date) {
                var dateObj = (self.config["_" + type + "Date"] = self.parseDate(date, self.config.dateFormat));
                var inverseDateObj = self.config["_" + (type === "min" ? "max" : "min") + "Date"];
                if (dateObj !== undefined) {
                    self[type === "min" ? "minDateHasTime" : "maxDateHasTime"] =
                        dateObj.getHours() > 0 ||
                            dateObj.getMinutes() > 0 ||
                            dateObj.getSeconds() > 0;
                }
                if (self.selectedDates) {
                    self.selectedDates = self.selectedDates.filter(function (d) { return isEnabled(d); });
                    if (!self.selectedDates.length && type === "min")
                        setHoursFromDate(dateObj);
                    updateValue();
                }
                if (self.daysContainer) {
                    redraw();
                    if (dateObj !== undefined)
                        self.currentYearElement[type] = dateObj.getFullYear().toString();
                    else
                        self.currentYearElement.removeAttribute(type);
                    self.currentYearElement.disabled =
                        !!inverseDateObj &&
                            dateObj !== undefined &&
                            inverseDateObj.getFullYear() === dateObj.getFullYear();
                }
            };
        }
        function parseConfig() {
            var boolOpts = [
                "wrap",
                "weekNumbers",
                "allowInput",
                "clickOpens",
                "time_24hr",
                "enableTime",
                "noCalendar",
                "altInput",
                "shorthandCurrentMonth",
                "inline",
                "static",
                "enableSeconds",
                "disableMobile",
            ];
            var userConfig = __assign({}, instanceConfig, JSON.parse(JSON.stringify(element.dataset || {})));
            var formats = {};
            self.config.parseDate = userConfig.parseDate;
            self.config.formatDate = userConfig.formatDate;
            Object.defineProperty(self.config, "enable", {
                get: function () { return self.config._enable; },
                set: function (dates) {
                    self.config._enable = parseDateRules(dates);
                }
            });
            Object.defineProperty(self.config, "disable", {
                get: function () { return self.config._disable; },
                set: function (dates) {
                    self.config._disable = parseDateRules(dates);
                }
            });
            var timeMode = userConfig.mode === "time";
            if (!userConfig.dateFormat && (userConfig.enableTime || timeMode)) {
                var defaultDateFormat = flatpickr.defaultConfig.dateFormat || defaults.dateFormat;
                formats.dateFormat =
                    userConfig.noCalendar || timeMode
                        ? "H:i" + (userConfig.enableSeconds ? ":S" : "")
                        : defaultDateFormat + " H:i" + (userConfig.enableSeconds ? ":S" : "");
            }
            if (userConfig.altInput &&
                (userConfig.enableTime || timeMode) &&
                !userConfig.altFormat) {
                var defaultAltFormat = flatpickr.defaultConfig.altFormat || defaults.altFormat;
                formats.altFormat =
                    userConfig.noCalendar || timeMode
                        ? "h:i" + (userConfig.enableSeconds ? ":S K" : " K")
                        : defaultAltFormat + (" h:i" + (userConfig.enableSeconds ? ":S" : "") + " K");
            }
            if (!userConfig.altInputClass) {
                self.config.altInputClass =
                    self.input.className + " " + self.config.altInputClass;
            }
            Object.defineProperty(self.config, "minDate", {
                get: function () { return self.config._minDate; },
                set: minMaxDateSetter("min")
            });
            Object.defineProperty(self.config, "maxDate", {
                get: function () { return self.config._maxDate; },
                set: minMaxDateSetter("max")
            });
            var minMaxTimeSetter = function (type) { return function (val) {
                self.config[type === "min" ? "_minTime" : "_maxTime"] = self.parseDate(val, "H:i");
            }; };
            Object.defineProperty(self.config, "minTime", {
                get: function () { return self.config._minTime; },
                set: minMaxTimeSetter("min")
            });
            Object.defineProperty(self.config, "maxTime", {
                get: function () { return self.config._maxTime; },
                set: minMaxTimeSetter("max")
            });
            if (userConfig.mode === "time") {
                self.config.noCalendar = true;
                self.config.enableTime = true;
            }
            Object.assign(self.config, formats, userConfig);
            for (var i = 0; i < boolOpts.length; i++)
                self.config[boolOpts[i]] =
                    self.config[boolOpts[i]] === true ||
                        self.config[boolOpts[i]] === "true";
            HOOKS.filter(function (hook) { return self.config[hook] !== undefined; }).forEach(function (hook) {
                self.config[hook] = arrayify(self.config[hook] || []).map(bindToInstance);
            });
            self.isMobile =
                !self.config.disableMobile &&
                    !self.config.inline &&
                    self.config.mode === "single" &&
                    !self.config.disable.length &&
                    !self.config.enable.length &&
                    !self.config.weekNumbers &&
                    /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
            for (var i = 0; i < self.config.plugins.length; i++) {
                var pluginConf = self.config.plugins[i](self) || {};
                for (var key in pluginConf) {
                    if (HOOKS.indexOf(key) > -1) {
                        self.config[key] = arrayify(pluginConf[key])
                            .map(bindToInstance)
                            .concat(self.config[key]);
                    }
                    else if (typeof userConfig[key] === "undefined")
                        self.config[key] = pluginConf[key];
                }
            }
            triggerEvent("onParseConfig");
        }
        function setupLocale() {
            if (typeof self.config.locale !== "object" &&
                typeof flatpickr.l10ns[self.config.locale] === "undefined")
                self.config.errorHandler(new Error("flatpickr: invalid locale " + self.config.locale));
            self.l10n = __assign({}, flatpickr.l10ns["default"], (typeof self.config.locale === "object"
                ? self.config.locale
                : self.config.locale !== "default"
                    ? flatpickr.l10ns[self.config.locale]
                    : undefined));
            tokenRegex.K = "(" + self.l10n.amPM[0] + "|" + self.l10n.amPM[1] + "|" + self.l10n.amPM[0].toLowerCase() + "|" + self.l10n.amPM[1].toLowerCase() + ")";
            var userConfig = __assign({}, instanceConfig, JSON.parse(JSON.stringify(element.dataset || {})));
            if (userConfig.time_24hr === undefined &&
                flatpickr.defaultConfig.time_24hr === undefined) {
                self.config.time_24hr = self.l10n.time_24hr;
            }
            self.formatDate = createDateFormatter(self);
            self.parseDate = createDateParser({ config: self.config, l10n: self.l10n });
        }
        function positionCalendar(customPositionElement) {
            if (self.calendarContainer === undefined)
                return;
            triggerEvent("onPreCalendarPosition");
            var positionElement = customPositionElement || self._positionElement;
            var calendarHeight = Array.prototype.reduce.call(self.calendarContainer.children, (function (acc, child) { return acc + child.offsetHeight; }), 0), calendarWidth = self.calendarContainer.offsetWidth, configPos = self.config.position.split(" "), configPosVertical = configPos[0], configPosHorizontal = configPos.length > 1 ? configPos[1] : null, inputBounds = positionElement.getBoundingClientRect(), distanceFromBottom = window.innerHeight - inputBounds.bottom, showOnTop = configPosVertical === "above" ||
                (configPosVertical !== "below" &&
                    distanceFromBottom < calendarHeight &&
                    inputBounds.top > calendarHeight);
            var top = window.pageYOffset +
                inputBounds.top +
                (!showOnTop ? positionElement.offsetHeight + 2 : -calendarHeight - 2);
            toggleClass(self.calendarContainer, "arrowTop", !showOnTop);
            toggleClass(self.calendarContainer, "arrowBottom", showOnTop);
            if (self.config.inline)
                return;
            var left = window.pageXOffset +
                inputBounds.left -
                (configPosHorizontal != null && configPosHorizontal === "center"
                    ? (calendarWidth - inputBounds.width) / 2
                    : 0);
            var right = window.document.body.offsetWidth - inputBounds.right;
            var rightMost = left + calendarWidth > window.document.body.offsetWidth;
            var centerMost = right + calendarWidth > window.document.body.offsetWidth;
            toggleClass(self.calendarContainer, "rightMost", rightMost);
            if (self.config.static)
                return;
            self.calendarContainer.style.top = top + "px";
            if (!rightMost) {
                self.calendarContainer.style.left = left + "px";
                self.calendarContainer.style.right = "auto";
            }
            else if (!centerMost) {
                self.calendarContainer.style.left = "auto";
                self.calendarContainer.style.right = right + "px";
            }
            else {
                var doc = document.styleSheets[0];
                // some testing environments don't have css support
                if (doc === undefined)
                    return;
                var bodyWidth = window.document.body.offsetWidth;
                var centerLeft = Math.max(0, bodyWidth / 2 - calendarWidth / 2);
                var centerBefore = ".flatpickr-calendar.centerMost:before";
                var centerAfter = ".flatpickr-calendar.centerMost:after";
                var centerIndex = doc.cssRules.length;
                var centerStyle = "{left:" + inputBounds.left + "px;right:auto;}";
                toggleClass(self.calendarContainer, "rightMost", false);
                toggleClass(self.calendarContainer, "centerMost", true);
                doc.insertRule(centerBefore + "," + centerAfter + centerStyle, centerIndex);
                self.calendarContainer.style.left = centerLeft + "px";
                self.calendarContainer.style.right = "auto";
            }
        }
        function redraw() {
            if (self.config.noCalendar || self.isMobile)
                return;
            updateNavigationCurrentMonth();
            buildDays();
        }
        function focusAndClose() {
            self._input.focus();
            if (window.navigator.userAgent.indexOf("MSIE") !== -1 ||
                navigator.msMaxTouchPoints !== undefined) {
                // hack - bugs in the way IE handles focus keeps the calendar open
                setTimeout(self.close, 0);
            }
            else {
                self.close();
            }
        }
        function selectDate(e) {
            e.preventDefault();
            e.stopPropagation();
            var isSelectable = function (day) {
                return day.classList &&
                    day.classList.contains("flatpickr-day") &&
                    !day.classList.contains("flatpickr-disabled") &&
                    !day.classList.contains("notAllowed");
            };
            var t = findParent(e.target, isSelectable);
            if (t === undefined)
                return;
            var target = t;
            var selectedDate = (self.latestSelectedDateObj = new Date(target.dateObj.getTime()));
            var shouldChangeMonth = (selectedDate.getMonth() < self.currentMonth ||
                selectedDate.getMonth() >
                    self.currentMonth + self.config.showMonths - 1) &&
                self.config.mode !== "range";
            self.selectedDateElem = target;
            if (self.config.mode === "single")
                self.selectedDates = [selectedDate];
            else if (self.config.mode === "multiple") {
                var selectedIndex = isDateSelected(selectedDate);
                if (selectedIndex)
                    self.selectedDates.splice(parseInt(selectedIndex), 1);
                else
                    self.selectedDates.push(selectedDate);
            }
            else if (self.config.mode === "range") {
                if (self.selectedDates.length === 2) {
                    self.clear(false, false);
                }
                self.latestSelectedDateObj = selectedDate;
                self.selectedDates.push(selectedDate);
                // unless selecting same date twice, sort ascendingly
                if (compareDates(selectedDate, self.selectedDates[0], true) !== 0)
                    self.selectedDates.sort(function (a, b) { return a.getTime() - b.getTime(); });
            }
            setHoursFromInputs();
            if (shouldChangeMonth) {
                var isNewYear = self.currentYear !== selectedDate.getFullYear();
                self.currentYear = selectedDate.getFullYear();
                self.currentMonth = selectedDate.getMonth();
                if (isNewYear) {
                    triggerEvent("onYearChange");
                    buildMonthSwitch();
                }
                triggerEvent("onMonthChange");
            }
            updateNavigationCurrentMonth();
            buildDays();
            updateValue();
            if (self.config.enableTime)
                setTimeout(function () { return (self.showTimeInput = true); }, 50);
            // maintain focus
            if (!shouldChangeMonth &&
                self.config.mode !== "range" &&
                self.config.showMonths === 1)
                focusOnDayElem(target);
            else if (self.selectedDateElem !== undefined &&
                self.hourElement === undefined) {
                self.selectedDateElem && self.selectedDateElem.focus();
            }
            if (self.hourElement !== undefined)
                self.hourElement !== undefined && self.hourElement.focus();
            if (self.config.closeOnSelect) {
                var single = self.config.mode === "single" && !self.config.enableTime;
                var range = self.config.mode === "range" &&
                    self.selectedDates.length === 2 &&
                    !self.config.enableTime;
                if (single || range) {
                    focusAndClose();
                }
            }
            triggerChange();
        }
        var CALLBACKS = {
            locale: [setupLocale, updateWeekdays],
            showMonths: [buildMonths, setCalendarWidth, buildWeekdays],
            minDate: [jumpToDate],
            maxDate: [jumpToDate]
        };
        function set(option, value) {
            if (option !== null && typeof option === "object") {
                Object.assign(self.config, option);
                for (var key in option) {
                    if (CALLBACKS[key] !== undefined)
                        CALLBACKS[key].forEach(function (x) { return x(); });
                }
            }
            else {
                self.config[option] = value;
                if (CALLBACKS[option] !== undefined)
                    CALLBACKS[option].forEach(function (x) { return x(); });
                else if (HOOKS.indexOf(option) > -1)
                    self.config[option] = arrayify(value);
            }
            self.redraw();
            updateValue(false);
        }
        function setSelectedDate(inputDate, format) {
            var dates = [];
            if (inputDate instanceof Array)
                dates = inputDate.map(function (d) { return self.parseDate(d, format); });
            else if (inputDate instanceof Date || typeof inputDate === "number")
                dates = [self.parseDate(inputDate, format)];
            else if (typeof inputDate === "string") {
                switch (self.config.mode) {
                    case "single":
                    case "time":
                        dates = [self.parseDate(inputDate, format)];
                        break;
                    case "multiple":
                        dates = inputDate
                            .split(self.config.conjunction)
                            .map(function (date) { return self.parseDate(date, format); });
                        break;
                    case "range":
                        dates = inputDate
                            .split(self.l10n.rangeSeparator)
                            .map(function (date) { return self.parseDate(date, format); });
                        break;
                    default:
                        break;
                }
            }
            else
                self.config.errorHandler(new Error("Invalid date supplied: " + JSON.stringify(inputDate)));
            self.selectedDates = dates.filter(function (d) { return d instanceof Date && isEnabled(d, false); });
            if (self.config.mode === "range")
                self.selectedDates.sort(function (a, b) { return a.getTime() - b.getTime(); });
        }
        function setDate(date, triggerChange, format) {
            if (triggerChange === void 0) { triggerChange = false; }
            if (format === void 0) { format = self.config.dateFormat; }
            if ((date !== 0 && !date) || (date instanceof Array && date.length === 0))
                return self.clear(triggerChange);
            setSelectedDate(date, format);
            self.showTimeInput = self.selectedDates.length > 0;
            self.latestSelectedDateObj = self.selectedDates[self.selectedDates.length - 1];
            self.redraw();
            jumpToDate();
            setHoursFromDate();
            if (self.selectedDates.length === 0) {
                self.clear(false);
            }
            updateValue(triggerChange);
            if (triggerChange)
                triggerEvent("onChange");
        }
        function parseDateRules(arr) {
            return arr
                .slice()
                .map(function (rule) {
                if (typeof rule === "string" ||
                    typeof rule === "number" ||
                    rule instanceof Date) {
                    return self.parseDate(rule, undefined, true);
                }
                else if (rule &&
                    typeof rule === "object" &&
                    rule.from &&
                    rule.to)
                    return {
                        from: self.parseDate(rule.from, undefined),
                        to: self.parseDate(rule.to, undefined)
                    };
                return rule;
            })
                .filter(function (x) { return x; }); // remove falsy values
        }
        function setupDates() {
            self.selectedDates = [];
            self.now = self.parseDate(self.config.now) || new Date();
            // Workaround IE11 setting placeholder as the input's value
            var preloadedDate = self.config.defaultDate ||
                ((self.input.nodeName === "INPUT" ||
                    self.input.nodeName === "TEXTAREA") &&
                    self.input.placeholder &&
                    self.input.value === self.input.placeholder
                    ? null
                    : self.input.value);
            if (preloadedDate)
                setSelectedDate(preloadedDate, self.config.dateFormat);
            self._initialDate =
                self.selectedDates.length > 0
                    ? self.selectedDates[0]
                    : self.config.minDate &&
                        self.config.minDate.getTime() > self.now.getTime()
                        ? self.config.minDate
                        : self.config.maxDate &&
                            self.config.maxDate.getTime() < self.now.getTime()
                            ? self.config.maxDate
                            : self.now;
            self.currentYear = self._initialDate.getFullYear();
            self.currentMonth = self._initialDate.getMonth();
            if (self.selectedDates.length > 0)
                self.latestSelectedDateObj = self.selectedDates[0];
            if (self.config.minTime !== undefined)
                self.config.minTime = self.parseDate(self.config.minTime, "H:i");
            if (self.config.maxTime !== undefined)
                self.config.maxTime = self.parseDate(self.config.maxTime, "H:i");
            self.minDateHasTime =
                !!self.config.minDate &&
                    (self.config.minDate.getHours() > 0 ||
                        self.config.minDate.getMinutes() > 0 ||
                        self.config.minDate.getSeconds() > 0);
            self.maxDateHasTime =
                !!self.config.maxDate &&
                    (self.config.maxDate.getHours() > 0 ||
                        self.config.maxDate.getMinutes() > 0 ||
                        self.config.maxDate.getSeconds() > 0);
            Object.defineProperty(self, "showTimeInput", {
                get: function () { return self._showTimeInput; },
                set: function (bool) {
                    self._showTimeInput = bool;
                    if (self.calendarContainer)
                        toggleClass(self.calendarContainer, "showTimeInput", bool);
                    self.isOpen && positionCalendar();
                }
            });
        }
        function setupInputs() {
            self.input = self.config.wrap
                ? element.querySelector("[data-input]")
                : element;
            /* istanbul ignore next */
            if (!self.input) {
                self.config.errorHandler(new Error("Invalid input element specified"));
                return;
            }
            // hack: store previous type to restore it after destroy()
            self.input._type = self.input.type;
            self.input.type = "text";
            self.input.classList.add("flatpickr-input");
            self._input = self.input;
            if (self.config.altInput) {
                // replicate self.element
                self.altInput = createElement(self.input.nodeName, self.config.altInputClass);
                self._input = self.altInput;
                self.altInput.placeholder = self.input.placeholder;
                self.altInput.disabled = self.input.disabled;
                self.altInput.required = self.input.required;
                self.altInput.tabIndex = self.input.tabIndex;
                self.altInput.type = "text";
                self.input.setAttribute("type", "hidden");
                if (!self.config.static && self.input.parentNode)
                    self.input.parentNode.insertBefore(self.altInput, self.input.nextSibling);
            }
            if (!self.config.allowInput)
                self._input.setAttribute("readonly", "readonly");
            self._positionElement = self.config.positionElement || self._input;
        }
        function setupMobile() {
            var inputType = self.config.enableTime
                ? self.config.noCalendar
                    ? "time"
                    : "datetime-local"
                : "date";
            self.mobileInput = createElement("input", self.input.className + " flatpickr-mobile");
            self.mobileInput.step = self.input.getAttribute("step") || "any";
            self.mobileInput.tabIndex = 1;
            self.mobileInput.type = inputType;
            self.mobileInput.disabled = self.input.disabled;
            self.mobileInput.required = self.input.required;
            self.mobileInput.placeholder = self.input.placeholder;
            self.mobileFormatStr =
                inputType === "datetime-local"
                    ? "Y-m-d\\TH:i:S"
                    : inputType === "date"
                        ? "Y-m-d"
                        : "H:i:S";
            if (self.selectedDates.length > 0) {
                self.mobileInput.defaultValue = self.mobileInput.value = self.formatDate(self.selectedDates[0], self.mobileFormatStr);
            }
            if (self.config.minDate)
                self.mobileInput.min = self.formatDate(self.config.minDate, "Y-m-d");
            if (self.config.maxDate)
                self.mobileInput.max = self.formatDate(self.config.maxDate, "Y-m-d");
            self.input.type = "hidden";
            if (self.altInput !== undefined)
                self.altInput.type = "hidden";
            try {
                if (self.input.parentNode)
                    self.input.parentNode.insertBefore(self.mobileInput, self.input.nextSibling);
            }
            catch (_a) { }
            bind(self.mobileInput, "change", function (e) {
                self.setDate(e.target.value, false, self.mobileFormatStr);
                triggerEvent("onChange");
                triggerEvent("onClose");
            });
        }
        function toggle(e) {
            if (self.isOpen === true)
                return self.close();
            self.open(e);
        }
        function triggerEvent(event, data) {
            // If the instance has been destroyed already, all hooks have been removed
            if (self.config === undefined)
                return;
            var hooks = self.config[event];
            if (hooks !== undefined && hooks.length > 0) {
                for (var i = 0; hooks[i] && i < hooks.length; i++)
                    hooks[i](self.selectedDates, self.input.value, self, data);
            }
            if (event === "onChange") {
                self.input.dispatchEvent(createEvent("change"));
                // many front-end frameworks bind to the input event
                self.input.dispatchEvent(createEvent("input"));
            }
        }
        function createEvent(name) {
            var e = document.createEvent("Event");
            e.initEvent(name, true, true);
            return e;
        }
        function isDateSelected(date) {
            for (var i = 0; i < self.selectedDates.length; i++) {
                if (compareDates(self.selectedDates[i], date) === 0)
                    return "" + i;
            }
            return false;
        }
        function isDateInRange(date) {
            if (self.config.mode !== "range" || self.selectedDates.length < 2)
                return false;
            return (compareDates(date, self.selectedDates[0]) >= 0 &&
                compareDates(date, self.selectedDates[1]) <= 0);
        }
        function updateNavigationCurrentMonth() {
            if (self.config.noCalendar || self.isMobile || !self.monthNav)
                return;
            self.yearElements.forEach(function (yearElement, i) {
                var d = new Date(self.currentYear, self.currentMonth, 1);
                d.setMonth(self.currentMonth + i);
                if (self.config.showMonths > 1) {
                    self.monthElements[i].textContent =
                        monthToStr(d.getMonth(), self.config.shorthandCurrentMonth, self.l10n) + " ";
                }
                else {
                    self.monthsDropdownContainer.value = d.getMonth().toString();
                }
                yearElement.value = d.getFullYear().toString();
            });
            self._hidePrevMonthArrow =
                self.config.minDate !== undefined &&
                    (self.currentYear === self.config.minDate.getFullYear()
                        ? self.currentMonth <= self.config.minDate.getMonth()
                        : self.currentYear < self.config.minDate.getFullYear());
            self._hideNextMonthArrow =
                self.config.maxDate !== undefined &&
                    (self.currentYear === self.config.maxDate.getFullYear()
                        ? self.currentMonth + 1 > self.config.maxDate.getMonth()
                        : self.currentYear > self.config.maxDate.getFullYear());
        }
        function getDateStr(format) {
            return self.selectedDates
                .map(function (dObj) { return self.formatDate(dObj, format); })
                .filter(function (d, i, arr) {
                return self.config.mode !== "range" ||
                    self.config.enableTime ||
                    arr.indexOf(d) === i;
            })
                .join(self.config.mode !== "range"
                ? self.config.conjunction
                : self.l10n.rangeSeparator);
        }
        /**
         * Updates the values of inputs associated with the calendar
         */
        function updateValue(triggerChange) {
            if (triggerChange === void 0) { triggerChange = true; }
            if (self.mobileInput !== undefined && self.mobileFormatStr) {
                self.mobileInput.value =
                    self.latestSelectedDateObj !== undefined
                        ? self.formatDate(self.latestSelectedDateObj, self.mobileFormatStr)
                        : "";
            }
            self.input.value = getDateStr(self.config.dateFormat);
            if (self.altInput !== undefined) {
                self.altInput.value = getDateStr(self.config.altFormat);
            }
            if (triggerChange !== false)
                triggerEvent("onValueUpdate");
        }
        function onMonthNavClick(e) {
            var isPrevMonth = self.prevMonthNav.contains(e.target);
            var isNextMonth = self.nextMonthNav.contains(e.target);
            if (isPrevMonth || isNextMonth) {
                changeMonth(isPrevMonth ? -1 : 1);
            }
            else if (self.yearElements.indexOf(e.target) >= 0) {
                e.target.select();
            }
            else if (e.target.classList.contains("arrowUp")) {
                self.changeYear(self.currentYear + 1);
            }
            else if (e.target.classList.contains("arrowDown")) {
                self.changeYear(self.currentYear - 1);
            }
        }
        function timeWrapper(e) {
            e.preventDefault();
            var isKeyDown = e.type === "keydown", input = e.target;
            if (self.amPM !== undefined && e.target === self.amPM) {
                self.amPM.textContent =
                    self.l10n.amPM[int(self.amPM.textContent === self.l10n.amPM[0])];
            }
            var min = parseFloat(input.getAttribute("min")), max = parseFloat(input.getAttribute("max")), step = parseFloat(input.getAttribute("step")), curValue = parseInt(input.value, 10), delta = e.delta ||
                (isKeyDown ? (e.which === 38 ? 1 : -1) : 0);
            var newValue = curValue + step * delta;
            if (typeof input.value !== "undefined" && input.value.length === 2) {
                var isHourElem = input === self.hourElement, isMinuteElem = input === self.minuteElement;
                if (newValue < min) {
                    newValue =
                        max +
                            newValue +
                            int(!isHourElem) +
                            (int(isHourElem) && int(!self.amPM));
                    if (isMinuteElem)
                        incrementNumInput(undefined, -1, self.hourElement);
                }
                else if (newValue > max) {
                    newValue =
                        input === self.hourElement ? newValue - max - int(!self.amPM) : min;
                    if (isMinuteElem)
                        incrementNumInput(undefined, 1, self.hourElement);
                }
                if (self.amPM &&
                    isHourElem &&
                    (step === 1
                        ? newValue + curValue === 23
                        : Math.abs(newValue - curValue) > step)) {
                    self.amPM.textContent =
                        self.l10n.amPM[int(self.amPM.textContent === self.l10n.amPM[0])];
                }
                input.value = pad(newValue);
            }
        }
        init();
        return self;
    }
    /* istanbul ignore next */
    function _flatpickr(nodeList, config) {
        // static list
        var nodes = Array.prototype.slice
            .call(nodeList)
            .filter(function (x) { return x instanceof HTMLElement; });
        var instances = [];
        for (var i = 0; i < nodes.length; i++) {
            var node = nodes[i];
            try {
                if (node.getAttribute("data-fp-omit") !== null)
                    continue;
                if (node._flatpickr !== undefined) {
                    node._flatpickr.destroy();
                    node._flatpickr = undefined;
                }
                node._flatpickr = FlatpickrInstance(node, config || {});
                instances.push(node._flatpickr);
            }
            catch (e) {
                console.error(e);
            }
        }
        return instances.length === 1 ? instances[0] : instances;
    }
    /* istanbul ignore next */
    if (typeof HTMLElement !== "undefined" &&
        typeof HTMLCollection !== "undefined" &&
        typeof NodeList !== "undefined") {
        // browser env
        HTMLCollection.prototype.flatpickr = NodeList.prototype.flatpickr = function (config) {
            return _flatpickr(this, config);
        };
        HTMLElement.prototype.flatpickr = function (config) {
            return _flatpickr([this], config);
        };
    }
    /* istanbul ignore next */
    var flatpickr = function (selector, config) {
        if (typeof selector === "string") {
            return _flatpickr(window.document.querySelectorAll(selector), config);
        }
        else if (selector instanceof Node) {
            return _flatpickr([selector], config);
        }
        else {
            return _flatpickr(selector, config);
        }
    };
    /* istanbul ignore next */
    flatpickr.defaultConfig = {};
    flatpickr.l10ns = {
        en: __assign({}, english),
        "default": __assign({}, english)
    };
    flatpickr.localize = function (l10n) {
        flatpickr.l10ns["default"] = __assign({}, flatpickr.l10ns["default"], l10n);
    };
    flatpickr.setDefaults = function (config) {
        flatpickr.defaultConfig = __assign({}, flatpickr.defaultConfig, config);
    };
    flatpickr.parseDate = createDateParser({});
    flatpickr.formatDate = createDateFormatter({});
    flatpickr.compareDates = compareDates;
    /* istanbul ignore next */
    if (typeof jQuery !== "undefined" && typeof jQuery.fn !== "undefined") {
        jQuery.fn.flatpickr = function (config) {
            return _flatpickr(this, config);
        };
    }
    // eslint-disable-next-line @typescript-eslint/camelcase
    Date.prototype.fp_incr = function (days) {
        return new Date(this.getFullYear(), this.getMonth(), this.getDate() + (typeof days === "string" ? parseInt(days, 10) : days));
    };
    if (typeof window !== "undefined") {
        window.flatpickr = flatpickr;
    }

    return flatpickr;

}));


/***/ }),

/***/ "./node_modules/lodash.debounce/index.js":
/*!***********************************************!*\
  !*** ./node_modules/lodash.debounce/index.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the `TypeError` message for "Functions" methods. */
var FUNC_ERROR_TEXT = 'Expected a function';

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/** Used to match leading and trailing whitespace. */
var reTrim = /^\s+|\s+$/g;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        result = wait - timeSinceLastCall;

    return maxing ? nativeMin(result, maxWait - timeSinceLastInvoke) : result;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && objectToString.call(value) == symbolTag);
}

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = value.replace(reTrim, '');
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = debounce;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../webpack/buildin/global.js */ "./node_modules/webpack/buildin/global.js")))

/***/ }),

/***/ "./node_modules/preact/compat/dist/compat.module.js":
/*!**********************************************************!*\
  !*** ./node_modules/preact/compat/dist/compat.module.js ***!
  \**********************************************************/
/*! exports provided: useState, useReducer, useEffect, useLayoutEffect, useRef, useImperativeHandle, useMemo, useCallback, useContext, useDebugValue, useErrorBoundary, createElement, createContext, createRef, Fragment, Component, default, version, Children, render, hydrate, unmountComponentAtNode, createPortal, createFactory, cloneElement, isValidElement, findDOMNode, PureComponent, memo, forwardRef, unstable_batchedUpdates, StrictMode, Suspense, SuspenseList, lazy */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "version", function() { return G; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Children", function() { return F; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return V; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hydrate", function() { return Z; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unmountComponentAtNode", function() { return X; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createPortal", function() { return D; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createFactory", function() { return J; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cloneElement", function() { return Q; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isValidElement", function() { return K; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "findDOMNode", function() { return Y; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PureComponent", function() { return E; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "memo", function() { return C; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forwardRef", function() { return k; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unstable_batchedUpdates", function() { return nn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StrictMode", function() { return tn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Suspense", function() { return M; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuspenseList", function() { return O; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "lazy", function() { return L; });
/* harmony import */ var preact_hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! preact/hooks */ "./node_modules/preact/hooks/dist/hooks.module.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useState", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useState"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useReducer", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useReducer"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useEffect", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useEffect"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useLayoutEffect", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useLayoutEffect"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useRef", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useRef"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useImperativeHandle", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useImperativeHandle"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useMemo", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useMemo"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useCallback", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useCallback"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useContext", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useContext"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useDebugValue", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useDebugValue"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "useErrorBoundary", function() { return preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useErrorBoundary"]; });

/* harmony import */ var preact__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! preact */ "./node_modules/preact/dist/preact.module.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createElement", function() { return preact__WEBPACK_IMPORTED_MODULE_1__["createElement"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createContext", function() { return preact__WEBPACK_IMPORTED_MODULE_1__["createContext"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createRef", function() { return preact__WEBPACK_IMPORTED_MODULE_1__["createRef"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Fragment", function() { return preact__WEBPACK_IMPORTED_MODULE_1__["Fragment"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Component", function() { return preact__WEBPACK_IMPORTED_MODULE_1__["Component"]; });

function g(n,t){for(var e in t)n[e]=t[e];return n}function w(n,t){for(var e in n)if("__source"!==e&&!(e in t))return!0;for(var r in t)if("__source"!==r&&n[r]!==t[r])return!0;return!1}var E=function(n){var t,e;function r(t){var e;return(e=n.call(this,t)||this).isPureReactComponent=!0,e}return e=n,(t=r).prototype=Object.create(e.prototype),t.prototype.constructor=t,t.__proto__=e,r.prototype.shouldComponentUpdate=function(n,t){return w(this.props,n)||w(this.state,t)},r}(preact__WEBPACK_IMPORTED_MODULE_1__["Component"]);function C(n,t){function e(n){var e=this.props.ref,r=e==n.ref;return!r&&e&&(e.call?e(null):e.current=null),t?!t(this.props,n)||!r:w(this.props,n)}function r(t){return this.shouldComponentUpdate=e,Object(preact__WEBPACK_IMPORTED_MODULE_1__["createElement"])(n,t)}return r.prototype.isReactComponent=!0,r.displayName="Memo("+(n.displayName||n.name)+")",r.t=!0,r}var _=preact__WEBPACK_IMPORTED_MODULE_1__["options"].__b;preact__WEBPACK_IMPORTED_MODULE_1__["options"].__b=function(n){n.type&&n.type.t&&n.ref&&(n.props.ref=n.ref,n.ref=null),_&&_(n)};var A="undefined"!=typeof Symbol&&Symbol.for&&Symbol.for("react.forward_ref")||3911;function k(n){function t(t,e){var r=g({},t);return delete r.ref,n(r,"object"!=typeof(e=t.ref||e)||"current"in e?e:null)}return t.$$typeof=A,t.render=t,t.prototype.isReactComponent=t.t=!0,t.displayName="ForwardRef("+(n.displayName||n.name)+")",t}var R=function(n,t){return n?Object(preact__WEBPACK_IMPORTED_MODULE_1__["toChildArray"])(n).reduce(function(n,e,r){return n.concat(t(e,r))},[]):null},F={map:R,forEach:R,count:function(n){return n?Object(preact__WEBPACK_IMPORTED_MODULE_1__["toChildArray"])(n).length:0},only:function(n){if(1!==(n=Object(preact__WEBPACK_IMPORTED_MODULE_1__["toChildArray"])(n)).length)throw new Error("Children.only() expects only one child.");return n[0]},toArray:preact__WEBPACK_IMPORTED_MODULE_1__["toChildArray"]},N=preact__WEBPACK_IMPORTED_MODULE_1__["options"].__e;function U(n){return n&&((n=g({},n)).__c=null,n.__k=n.__k&&n.__k.map(U)),n}function M(){this.__u=0,this.o=null,this.__b=null}function j(n){var t=n.__.__c;return t&&t.u&&t.u(n)}function L(n){var t,e,r;function o(o){if(t||(t=n()).then(function(n){e=n.default||n},function(n){r=n}),r)throw r;if(!e)throw t;return Object(preact__WEBPACK_IMPORTED_MODULE_1__["createElement"])(e,o)}return o.displayName="Lazy",o.t=!0,o}function O(){this.i=null,this.l=null}preact__WEBPACK_IMPORTED_MODULE_1__["options"].__e=function(n,t,e){if(n.then)for(var r,o=t;o=o.__;)if((r=o.__c)&&r.__c)return r.__c(n,t.__c);N(n,t,e)},(M.prototype=new preact__WEBPACK_IMPORTED_MODULE_1__["Component"]).__c=function(n,t){var e=this;null==e.o&&(e.o=[]),e.o.push(t);var r=j(e.__v),o=!1,u=function(){o||(o=!0,r?r(i):i())};t.__c=t.componentWillUnmount,t.componentWillUnmount=function(){u(),t.__c&&t.__c()};var i=function(){var n;if(!--e.__u)for(e.__v.__k[0]=e.state.u,e.setState({u:e.__b=null});n=e.o.pop();)n.forceUpdate()};e.__u++||e.setState({u:e.__b=e.__v.__k[0]}),n.then(u,u)},M.prototype.render=function(n,t){return this.__b&&(this.__v.__k[0]=U(this.__b),this.__b=null),[Object(preact__WEBPACK_IMPORTED_MODULE_1__["createElement"])(preact__WEBPACK_IMPORTED_MODULE_1__["Fragment"],null,t.u?null:n.children),t.u&&n.fallback]};var P=function(n,t,e){if(++e[1]===e[0]&&n.l.delete(t),n.props.revealOrder&&("t"!==n.props.revealOrder[0]||!n.l.size))for(e=n.i;e;){for(;e.length>3;)e.pop()();if(e[1]<e[0])break;n.i=e=e[2]}};(O.prototype=new preact__WEBPACK_IMPORTED_MODULE_1__["Component"]).u=function(n){var t=this,e=j(t.__v),r=t.l.get(n);return r[0]++,function(o){var u=function(){t.props.revealOrder?(r.push(o),P(t,n,r)):o()};e?e(u):u()}},O.prototype.render=function(n){this.i=null,this.l=new Map;var t=Object(preact__WEBPACK_IMPORTED_MODULE_1__["toChildArray"])(n.children);n.revealOrder&&"b"===n.revealOrder[0]&&t.reverse();for(var e=t.length;e--;)this.l.set(t[e],this.i=[1,0,this.i]);return n.children},O.prototype.componentDidUpdate=O.prototype.componentDidMount=function(){var n=this;n.l.forEach(function(t,e){P(n,e,t)})};var W=function(){function n(){}var t=n.prototype;return t.getChildContext=function(){return this.props.context},t.render=function(n){return n.children},n}();function z(n){var t=this,e=n.container,r=Object(preact__WEBPACK_IMPORTED_MODULE_1__["createElement"])(W,{context:t.context},n.vnode);return t.s&&t.s!==e&&(t.v.parentNode&&t.s.removeChild(t.v),Object(preact__WEBPACK_IMPORTED_MODULE_1__["__u"])(t.h),t.p=!1),n.vnode?t.p?(e.__k=t.__k,Object(preact__WEBPACK_IMPORTED_MODULE_1__["render"])(r,e),t.__k=e.__k):(t.v=document.createTextNode(""),Object(preact__WEBPACK_IMPORTED_MODULE_1__["hydrate"])("",e),e.appendChild(t.v),t.p=!0,t.s=e,Object(preact__WEBPACK_IMPORTED_MODULE_1__["render"])(r,e,t.v),t.__k=t.v.__k):t.p&&(t.v.parentNode&&t.s.removeChild(t.v),Object(preact__WEBPACK_IMPORTED_MODULE_1__["__u"])(t.h)),t.h=r,t.componentWillUnmount=function(){t.v.parentNode&&t.s.removeChild(t.v),Object(preact__WEBPACK_IMPORTED_MODULE_1__["__u"])(t.h)},null}function D(n,t){return Object(preact__WEBPACK_IMPORTED_MODULE_1__["createElement"])(z,{vnode:n,container:t})}var H=/^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|fill|flood|font|glyph(?!R)|horiz|marker(?!H|W|U)|overline|paint|stop|strikethrough|stroke|text(?!L)|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/;preact__WEBPACK_IMPORTED_MODULE_1__["Component"].prototype.isReactComponent={};var T="undefined"!=typeof Symbol&&Symbol.for&&Symbol.for("react.element")||60103;function V(n,t,e){if(null==t.__k)for(;t.firstChild;)t.removeChild(t.firstChild);return Object(preact__WEBPACK_IMPORTED_MODULE_1__["render"])(n,t),"function"==typeof e&&e(),n?n.__c:null}function Z(n,t,e){return Object(preact__WEBPACK_IMPORTED_MODULE_1__["hydrate"])(n,t),"function"==typeof e&&e(),n?n.__c:null}var I=preact__WEBPACK_IMPORTED_MODULE_1__["options"].event;function $(n,t){n["UNSAFE_"+t]&&!n[t]&&Object.defineProperty(n,t,{configurable:!1,get:function(){return this["UNSAFE_"+t]},set:function(n){this["UNSAFE_"+t]=n}})}preact__WEBPACK_IMPORTED_MODULE_1__["options"].event=function(n){I&&(n=I(n)),n.persist=function(){};var t=!1,e=!1,r=n.stopPropagation;n.stopPropagation=function(){r.call(n),t=!0};var o=n.preventDefault;return n.preventDefault=function(){o.call(n),e=!0},n.isPropagationStopped=function(){return t},n.isDefaultPrevented=function(){return e},n.nativeEvent=n};var q={configurable:!0,get:function(){return this.class}},B=preact__WEBPACK_IMPORTED_MODULE_1__["options"].vnode;preact__WEBPACK_IMPORTED_MODULE_1__["options"].vnode=function(n){n.$$typeof=T;var t=n.type,e=n.props;if(t){if(e.class!=e.className&&(q.enumerable="className"in e,null!=e.className&&(e.class=e.className),Object.defineProperty(e,"className",q)),"function"!=typeof t){var r,o,u;for(u in e.defaultValue&&void 0!==e.value&&(e.value||0===e.value||(e.value=e.defaultValue),delete e.defaultValue),Array.isArray(e.value)&&e.multiple&&"select"===t&&(Object(preact__WEBPACK_IMPORTED_MODULE_1__["toChildArray"])(e.children).forEach(function(n){-1!=e.value.indexOf(n.props.value)&&(n.props.selected=!0)}),delete e.value),null!=e.value&&"textarea"===t&&(e.children=e.value,delete e.value),e)if(r=H.test(u))break;if(r)for(u in o=n.props={},e)o[H.test(u)?u.replace(/[A-Z0-9]/,"-$&").toLowerCase():u]=e[u]}!function(t){var e=n.type,r=n.props;if(r&&"string"==typeof e){var o={};for(var u in r)/^on(Ani|Tra|Tou)/.test(u)&&(r[u.toLowerCase()]=r[u],delete r[u]),o[u.toLowerCase()]=u;if(o.ondoubleclick&&(r.ondblclick=r[o.ondoubleclick],delete r[o.ondoubleclick]),o.onbeforeinput&&(r.onbeforeinput=r[o.onbeforeinput],delete r[o.onbeforeinput]),o.onchange&&("textarea"===e||"input"===e.toLowerCase()&&!/^fil|che|ra/i.test(r.type))){var i=o.oninput||"oninput";r[i]||(r[i]=r[o.onchange],delete r[o.onchange])}}}(),"function"==typeof t&&!t.m&&t.prototype&&($(t.prototype,"componentWillMount"),$(t.prototype,"componentWillReceiveProps"),$(t.prototype,"componentWillUpdate"),t.m=!0)}B&&B(n)};var G="16.8.0";function J(n){return preact__WEBPACK_IMPORTED_MODULE_1__["createElement"].bind(null,n)}function K(n){return!!n&&n.$$typeof===T}function Q(n){return K(n)?preact__WEBPACK_IMPORTED_MODULE_1__["cloneElement"].apply(null,arguments):n}function X(n){return!!n.__k&&(Object(preact__WEBPACK_IMPORTED_MODULE_1__["render"])(null,n),!0)}function Y(n){return n&&(n.base||1===n.nodeType&&n)||null}var nn=function(n,t){return n(t)},tn=preact__WEBPACK_IMPORTED_MODULE_1__["Fragment"];/* harmony default export */ __webpack_exports__["default"] = ({useState:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useState"],useReducer:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useReducer"],useEffect:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useEffect"],useLayoutEffect:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useLayoutEffect"],useRef:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useRef"],useImperativeHandle:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useImperativeHandle"],useMemo:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useMemo"],useCallback:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useCallback"],useContext:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useContext"],useDebugValue:preact_hooks__WEBPACK_IMPORTED_MODULE_0__["useDebugValue"],version:"16.8.0",Children:F,render:V,hydrate:Z,unmountComponentAtNode:X,createPortal:D,createElement:preact__WEBPACK_IMPORTED_MODULE_1__["createElement"],createContext:preact__WEBPACK_IMPORTED_MODULE_1__["createContext"],createFactory:J,cloneElement:Q,createRef:preact__WEBPACK_IMPORTED_MODULE_1__["createRef"],Fragment:preact__WEBPACK_IMPORTED_MODULE_1__["Fragment"],isValidElement:K,findDOMNode:Y,Component:preact__WEBPACK_IMPORTED_MODULE_1__["Component"],PureComponent:E,memo:C,forwardRef:k,unstable_batchedUpdates:nn,StrictMode:preact__WEBPACK_IMPORTED_MODULE_1__["Fragment"],Suspense:M,SuspenseList:O,lazy:L});
//# sourceMappingURL=compat.module.js.map


/***/ }),

/***/ "./node_modules/preact/dist/preact.module.js":
/*!***************************************************!*\
  !*** ./node_modules/preact/dist/preact.module.js ***!
  \***************************************************/
/*! exports provided: render, hydrate, createElement, h, Fragment, createRef, isValidElement, Component, cloneElement, createContext, toChildArray, __u, options */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return M; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hydrate", function() { return O; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createElement", function() { return v; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return v; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Fragment", function() { return p; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createRef", function() { return y; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isValidElement", function() { return l; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Component", function() { return d; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cloneElement", function() { return S; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createContext", function() { return q; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toChildArray", function() { return b; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__u", function() { return I; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "options", function() { return n; });
var n,l,u,i,t,r,o,f={},e=[],c=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;function s(n,l){for(var u in l)n[u]=l[u];return n}function a(n){var l=n.parentNode;l&&l.removeChild(n)}function v(n,l,u){var i,t=arguments,r={};for(i in l)"key"!==i&&"ref"!==i&&(r[i]=l[i]);if(arguments.length>3)for(u=[u],i=3;i<arguments.length;i++)u.push(t[i]);if(null!=u&&(r.children=u),"function"==typeof n&&null!=n.defaultProps)for(i in n.defaultProps)void 0===r[i]&&(r[i]=n.defaultProps[i]);return h(n,r,l&&l.key,l&&l.ref,null)}function h(l,u,i,t,r){var o={type:l,props:u,key:i,ref:t,__k:null,__:null,__b:0,__e:null,__d:void 0,__c:null,constructor:void 0,__v:r};return null==r&&(o.__v=o),n.vnode&&n.vnode(o),o}function y(){return{current:null}}function p(n){return n.children}function d(n,l){this.props=n,this.context=l}function _(n,l){if(null==l)return n.__?_(n.__,n.__.__k.indexOf(n)+1):null;for(var u;l<n.__k.length;l++)if(null!=(u=n.__k[l])&&null!=u.__e)return u.__e;return"function"==typeof n.type?_(n):null}function k(n){var l,u;if(null!=(n=n.__)&&null!=n.__c){for(n.__e=n.__c.base=null,l=0;l<n.__k.length;l++)if(null!=(u=n.__k[l])&&null!=u.__e){n.__e=n.__c.base=u.__e;break}return k(n)}}function w(l){(!l.__d&&(l.__d=!0)&&u.push(l)&&!m.__r++||t!==n.debounceRendering)&&((t=n.debounceRendering)||i)(m)}function m(){for(var n;m.__r=u.length;)n=u.sort(function(n,l){return n.__v.__b-l.__v.__b}),u=[],n.some(function(n){var l,u,i,t,r,o,f;n.__d&&(o=(r=(l=n).__v).__e,(f=l.__P)&&(u=[],(i=s({},r)).__v=i,t=T(f,r,i,l.__n,void 0!==f.ownerSVGElement,null,u,null==o?_(r):o),$(u,r),t!=o&&k(r)))})}function g(n,l,u,i,t,r,o,c,s,v){var y,d,k,w,m,g,b,A=i&&i.__k||e,P=A.length;for(s==f&&(s=null!=o?o[0]:P?_(i,0):null),u.__k=[],y=0;y<l.length;y++)if(null!=(w=u.__k[y]=null==(w=l[y])||"boolean"==typeof w?null:"string"==typeof w||"number"==typeof w?h(null,w,null,null,w):Array.isArray(w)?h(p,{children:w},null,null,null):null!=w.__e||null!=w.__c?h(w.type,w.props,w.key,null,w.__v):w)){if(w.__=u,w.__b=u.__b+1,null===(k=A[y])||k&&w.key==k.key&&w.type===k.type)A[y]=void 0;else for(d=0;d<P;d++){if((k=A[d])&&w.key==k.key&&w.type===k.type){A[d]=void 0;break}k=null}m=T(n,w,k=k||f,t,r,o,c,s,v),(d=w.ref)&&k.ref!=d&&(b||(b=[]),k.ref&&b.push(k.ref,null,w),b.push(d,w.__c||m,w)),null!=m?(null==g&&(g=m),s=x(n,w,k,A,o,m,s),"option"==u.type?n.value="":"function"==typeof u.type&&(u.__d=s)):s&&k.__e==s&&s.parentNode!=n&&(s=_(k))}if(u.__e=g,null!=o&&"function"!=typeof u.type)for(y=o.length;y--;)null!=o[y]&&a(o[y]);for(y=P;y--;)null!=A[y]&&I(A[y],A[y]);if(b)for(y=0;y<b.length;y++)H(b[y],b[++y],b[++y])}function b(n){return null==n||"boolean"==typeof n?[]:Array.isArray(n)?e.concat.apply([],n.map(b)):[n]}function x(n,l,u,i,t,r,o){var f,e,c;if(void 0!==l.__d)f=l.__d,l.__d=void 0;else if(t==u||r!=o||null==r.parentNode)n:if(null==o||o.parentNode!==n)n.appendChild(r),f=null;else{for(e=o,c=0;(e=e.nextSibling)&&c<i.length;c+=2)if(e==r)break n;n.insertBefore(r,o),f=o}return void 0!==f?f:r.nextSibling}function A(n,l,u,i,t){var r;for(r in u)"children"===r||"key"===r||r in l||C(n,r,null,u[r],i);for(r in l)t&&"function"!=typeof l[r]||"children"===r||"key"===r||"value"===r||"checked"===r||u[r]===l[r]||C(n,r,l[r],u[r],i)}function P(n,l,u){"-"===l[0]?n.setProperty(l,u):n[l]="number"==typeof u&&!1===c.test(l)?u+"px":null==u?"":u}function C(n,l,u,i,t){var r,o,f,e,c;if(t?"className"===l&&(l="class"):"class"===l&&(l="className"),"style"===l)if(r=n.style,"string"==typeof u)r.cssText=u;else{if("string"==typeof i&&(r.cssText="",i=null),i)for(e in i)u&&e in u||P(r,e,"");if(u)for(c in u)i&&u[c]===i[c]||P(r,c,u[c])}else"o"===l[0]&&"n"===l[1]?(o=l!==(l=l.replace(/Capture$/,"")),f=l.toLowerCase(),l=(f in n?f:l).slice(2),u?(i||n.addEventListener(l,N,o),(n.l||(n.l={}))[l]=u):n.removeEventListener(l,N,o)):"list"!==l&&"tagName"!==l&&"form"!==l&&"type"!==l&&"size"!==l&&!t&&l in n?n[l]=null==u?"":u:"function"!=typeof u&&"dangerouslySetInnerHTML"!==l&&(l!==(l=l.replace(/^xlink:?/,""))?null==u||!1===u?n.removeAttributeNS("http://www.w3.org/1999/xlink",l.toLowerCase()):n.setAttributeNS("http://www.w3.org/1999/xlink",l.toLowerCase(),u):null==u||!1===u&&!/^ar/.test(l)?n.removeAttribute(l):n.setAttribute(l,u))}function N(l){this.l[l.type](n.event?n.event(l):l)}function z(n,l,u){var i,t;for(i=0;i<n.__k.length;i++)(t=n.__k[i])&&(t.__=n,t.__e&&("function"==typeof t.type&&t.__k.length>1&&z(t,l,u),l=x(u,t,t,n.__k,null,t.__e,l),"function"==typeof n.type&&(n.__d=l)))}function T(l,u,i,t,r,o,f,e,c){var a,v,h,y,_,k,w,m,b,x,A,P=u.type;if(void 0!==u.constructor)return null;(a=n.__b)&&a(u);try{n:if("function"==typeof P){if(m=u.props,b=(a=P.contextType)&&t[a.__c],x=a?b?b.props.value:a.__:t,i.__c?w=(v=u.__c=i.__c).__=v.__E:("prototype"in P&&P.prototype.render?u.__c=v=new P(m,x):(u.__c=v=new d(m,x),v.constructor=P,v.render=L),b&&b.sub(v),v.props=m,v.state||(v.state={}),v.context=x,v.__n=t,h=v.__d=!0,v.__h=[]),null==v.__s&&(v.__s=v.state),null!=P.getDerivedStateFromProps&&(v.__s==v.state&&(v.__s=s({},v.__s)),s(v.__s,P.getDerivedStateFromProps(m,v.__s))),y=v.props,_=v.state,h)null==P.getDerivedStateFromProps&&null!=v.componentWillMount&&v.componentWillMount(),null!=v.componentDidMount&&v.__h.push(v.componentDidMount);else{if(null==P.getDerivedStateFromProps&&m!==y&&null!=v.componentWillReceiveProps&&v.componentWillReceiveProps(m,x),!v.__e&&null!=v.shouldComponentUpdate&&!1===v.shouldComponentUpdate(m,v.__s,x)||u.__v===i.__v){v.props=m,v.state=v.__s,u.__v!==i.__v&&(v.__d=!1),v.__v=u,u.__e=i.__e,u.__k=i.__k,v.__h.length&&f.push(v),z(u,e,l);break n}null!=v.componentWillUpdate&&v.componentWillUpdate(m,v.__s,x),null!=v.componentDidUpdate&&v.__h.push(function(){v.componentDidUpdate(y,_,k)})}v.context=x,v.props=m,v.state=v.__s,(a=n.__r)&&a(u),v.__d=!1,v.__v=u,v.__P=l,a=v.render(v.props,v.state,v.context),v.state=v.__s,null!=v.getChildContext&&(t=s(s({},t),v.getChildContext())),h||null==v.getSnapshotBeforeUpdate||(k=v.getSnapshotBeforeUpdate(y,_)),A=null!=a&&a.type==p&&null==a.key?a.props.children:a,g(l,Array.isArray(A)?A:[A],u,i,t,r,o,f,e,c),v.base=u.__e,v.__h.length&&f.push(v),w&&(v.__E=v.__=null),v.__e=!1}else null==o&&u.__v===i.__v?(u.__k=i.__k,u.__e=i.__e):u.__e=j(i.__e,u,i,t,r,o,f,c);(a=n.diffed)&&a(u)}catch(l){u.__v=null,n.__e(l,u,i)}return u.__e}function $(l,u){n.__c&&n.__c(u,l),l.some(function(u){try{l=u.__h,u.__h=[],l.some(function(n){n.call(u)})}catch(l){n.__e(l,u.__v)}})}function j(n,l,u,i,t,r,o,c){var s,a,v,h,y,p=u.props,d=l.props;if(t="svg"===l.type||t,null!=r)for(s=0;s<r.length;s++)if(null!=(a=r[s])&&((null===l.type?3===a.nodeType:a.localName===l.type)||n==a)){n=a,r[s]=null;break}if(null==n){if(null===l.type)return document.createTextNode(d);n=t?document.createElementNS("http://www.w3.org/2000/svg",l.type):document.createElement(l.type,d.is&&{is:d.is}),r=null,c=!1}if(null===l.type)p!==d&&n.data!=d&&(n.data=d);else{if(null!=r&&(r=e.slice.call(n.childNodes)),v=(p=u.props||f).dangerouslySetInnerHTML,h=d.dangerouslySetInnerHTML,!c){if(null!=r)for(p={},y=0;y<n.attributes.length;y++)p[n.attributes[y].name]=n.attributes[y].value;(h||v)&&(h&&v&&h.__html==v.__html||(n.innerHTML=h&&h.__html||""))}A(n,d,p,t,c),h?l.__k=[]:(s=l.props.children,g(n,Array.isArray(s)?s:[s],l,u,i,"foreignObject"!==l.type&&t,r,o,f,c)),c||("value"in d&&void 0!==(s=d.value)&&s!==n.value&&C(n,"value",s,p.value,!1),"checked"in d&&void 0!==(s=d.checked)&&s!==n.checked&&C(n,"checked",s,p.checked,!1))}return n}function H(l,u,i){try{"function"==typeof l?l(u):l.current=u}catch(l){n.__e(l,i)}}function I(l,u,i){var t,r,o;if(n.unmount&&n.unmount(l),(t=l.ref)&&(t.current&&t.current!==l.__e||H(t,null,u)),i||"function"==typeof l.type||(i=null!=(r=l.__e)),l.__e=l.__d=void 0,null!=(t=l.__c)){if(t.componentWillUnmount)try{t.componentWillUnmount()}catch(l){n.__e(l,u)}t.base=t.__P=null}if(t=l.__k)for(o=0;o<t.length;o++)t[o]&&I(t[o],u,i);null!=r&&a(r)}function L(n,l,u){return this.constructor(n,u)}function M(l,u,i){var t,o,c;n.__&&n.__(l,u),o=(t=i===r)?null:i&&i.__k||u.__k,l=v(p,null,[l]),c=[],T(u,(t?u:i||u).__k=l,o||f,f,void 0!==u.ownerSVGElement,i&&!t?[i]:o?null:u.childNodes.length?e.slice.call(u.childNodes):null,c,i||f,t),$(c,l)}function O(n,l){M(n,l,r)}function S(n,l){var u,i;for(i in l=s(s({},n.props),l),arguments.length>2&&(l.children=e.slice.call(arguments,2)),u={},l)"key"!==i&&"ref"!==i&&(u[i]=l[i]);return h(n.type,u,l.key||n.key,l.ref||n.ref,null)}function q(n){var l={},u={__c:"__cC"+o++,__:n,Consumer:function(n,l){return n.children(l)},Provider:function(n){var i,t=this;return this.getChildContext||(i=[],this.getChildContext=function(){return l[u.__c]=t,l},this.shouldComponentUpdate=function(n){t.props.value!==n.value&&i.some(function(l){l.context=n.value,w(l)})},this.sub=function(n){i.push(n);var l=n.componentWillUnmount;n.componentWillUnmount=function(){i.splice(i.indexOf(n),1),l&&l.call(n)}}),n.children}};return u.Consumer.contextType=u,u.Provider.__=u,u}n={__e:function(n,l){for(var u,i;l=l.__;)if((u=l.__c)&&!u.__)try{if(u.constructor&&null!=u.constructor.getDerivedStateFromError&&(i=!0,u.setState(u.constructor.getDerivedStateFromError(n))),null!=u.componentDidCatch&&(i=!0,u.componentDidCatch(n)),i)return w(u.__E=u)}catch(l){n=l}throw n}},l=function(n){return null!=n&&void 0===n.constructor},d.prototype.setState=function(n,l){var u;u=this.__s!==this.state?this.__s:this.__s=s({},this.state),"function"==typeof n&&(n=n(u,this.props)),n&&s(u,n),null!=n&&this.__v&&(l&&this.__h.push(l),w(this))},d.prototype.forceUpdate=function(n){this.__v&&(this.__e=!0,n&&this.__h.push(n),w(this))},d.prototype.render=p,u=[],i="function"==typeof Promise?Promise.prototype.then.bind(Promise.resolve()):setTimeout,m.__r=0,r=f,o=0;
//# sourceMappingURL=preact.module.js.map


/***/ }),

/***/ "./node_modules/preact/hooks/dist/hooks.module.js":
/*!********************************************************!*\
  !*** ./node_modules/preact/hooks/dist/hooks.module.js ***!
  \********************************************************/
/*! exports provided: useState, useReducer, useEffect, useLayoutEffect, useRef, useImperativeHandle, useMemo, useCallback, useContext, useDebugValue, useErrorBoundary */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useState", function() { return m; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useReducer", function() { return p; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useEffect", function() { return y; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useLayoutEffect", function() { return l; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useRef", function() { return h; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useImperativeHandle", function() { return s; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useMemo", function() { return _; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useCallback", function() { return A; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useContext", function() { return F; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useDebugValue", function() { return T; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useErrorBoundary", function() { return d; });
/* harmony import */ var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! preact */ "./node_modules/preact/dist/preact.module.js");
var t,u,r,o=0,i=[],c=preact__WEBPACK_IMPORTED_MODULE_0__["options"].__r,f=preact__WEBPACK_IMPORTED_MODULE_0__["options"].diffed,e=preact__WEBPACK_IMPORTED_MODULE_0__["options"].__c,a=preact__WEBPACK_IMPORTED_MODULE_0__["options"].unmount;function v(t,r){preact__WEBPACK_IMPORTED_MODULE_0__["options"].__h&&preact__WEBPACK_IMPORTED_MODULE_0__["options"].__h(u,t,o||r),o=0;var i=u.__H||(u.__H={__:[],__h:[]});return t>=i.__.length&&i.__.push({}),i.__[t]}function m(n){return o=1,p(k,n)}function p(n,r,o){var i=v(t++,2);return i.t=n,i.__c||(i.__c=u,i.__=[o?o(r):k(void 0,r),function(n){var t=i.t(i.__[0],n);i.__[0]!==t&&(i.__=[t,i.__[1]],i.__c.setState({}))}]),i.__}function y(r,o){var i=v(t++,3);!preact__WEBPACK_IMPORTED_MODULE_0__["options"].__s&&j(i.__H,o)&&(i.__=r,i.__H=o,u.__H.__h.push(i))}function l(r,o){var i=v(t++,4);!preact__WEBPACK_IMPORTED_MODULE_0__["options"].__s&&j(i.__H,o)&&(i.__=r,i.__H=o,u.__h.push(i))}function h(n){return o=5,_(function(){return{current:n}},[])}function s(n,t,u){o=6,l(function(){"function"==typeof n?n(t()):n&&(n.current=t())},null==u?u:u.concat(n))}function _(n,u){var r=v(t++,7);return j(r.__H,u)?(r.__H=u,r.__h=n,r.__=n()):r.__}function A(n,t){return o=8,_(function(){return n},t)}function F(n){var r=u.context[n.__c],o=v(t++,9);return o.__c=n,r?(null==o.__&&(o.__=!0,r.sub(u)),r.props.value):n.__}function T(t,u){preact__WEBPACK_IMPORTED_MODULE_0__["options"].useDebugValue&&preact__WEBPACK_IMPORTED_MODULE_0__["options"].useDebugValue(u?u(t):t)}function d(n){var r=v(t++,10),o=m();return r.__=n,u.componentDidCatch||(u.componentDidCatch=function(n){r.__&&r.__(n),o[1](n)}),[o[0],function(){o[1](void 0)}]}function q(){i.some(function(t){if(t.__P)try{t.__H.__h.forEach(b),t.__H.__h.forEach(g),t.__H.__h=[]}catch(u){return t.__H.__h=[],preact__WEBPACK_IMPORTED_MODULE_0__["options"].__e(u,t.__v),!0}}),i=[]}preact__WEBPACK_IMPORTED_MODULE_0__["options"].__r=function(n){c&&c(n),t=0;var r=(u=n.__c).__H;r&&(r.__h.forEach(b),r.__h.forEach(g),r.__h=[])},preact__WEBPACK_IMPORTED_MODULE_0__["options"].diffed=function(t){f&&f(t);var u=t.__c;u&&u.__H&&u.__H.__h.length&&(1!==i.push(u)&&r===preact__WEBPACK_IMPORTED_MODULE_0__["options"].requestAnimationFrame||((r=preact__WEBPACK_IMPORTED_MODULE_0__["options"].requestAnimationFrame)||function(n){var t,u=function(){clearTimeout(r),x&&cancelAnimationFrame(t),setTimeout(n)},r=setTimeout(u,100);x&&(t=requestAnimationFrame(u))})(q))},preact__WEBPACK_IMPORTED_MODULE_0__["options"].__c=function(t,u){u.some(function(t){try{t.__h.forEach(b),t.__h=t.__h.filter(function(n){return!n.__||g(n)})}catch(r){u.some(function(n){n.__h&&(n.__h=[])}),u=[],preact__WEBPACK_IMPORTED_MODULE_0__["options"].__e(r,t.__v)}}),e&&e(t,u)},preact__WEBPACK_IMPORTED_MODULE_0__["options"].unmount=function(t){a&&a(t);var u=t.__c;if(u&&u.__H)try{u.__H.__.forEach(b)}catch(t){preact__WEBPACK_IMPORTED_MODULE_0__["options"].__e(t,u.__v)}};var x="function"==typeof requestAnimationFrame;function b(n){"function"==typeof n.u&&n.u()}function g(n){n.u=n.__()}function j(n,t){return!n||t.some(function(t,u){return t!==n[u]})}function k(n,t){return"function"==typeof t?t(n):t}
//# sourceMappingURL=hooks.module.js.map


/***/ }),

/***/ "./node_modules/simple-swizzle/index.js":
/*!**********************************************!*\
  !*** ./node_modules/simple-swizzle/index.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var isArrayish = __webpack_require__(/*! is-arrayish */ "./node_modules/simple-swizzle/node_modules/is-arrayish/index.js");

var concat = Array.prototype.concat;
var slice = Array.prototype.slice;

var swizzle = module.exports = function swizzle(args) {
	var results = [];

	for (var i = 0, len = args.length; i < len; i++) {
		var arg = args[i];

		if (isArrayish(arg)) {
			// http://jsperf.com/javascript-array-concat-vs-push/98
			results = concat.call(results, slice.call(arg));
		} else {
			results.push(arg);
		}
	}

	return results;
};

swizzle.wrap = function (fn) {
	return function () {
		return fn(swizzle(arguments));
	};
};


/***/ }),

/***/ "./node_modules/simple-swizzle/node_modules/is-arrayish/index.js":
/*!***********************************************************************!*\
  !*** ./node_modules/simple-swizzle/node_modules/is-arrayish/index.js ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function isArrayish(obj) {
	if (!obj || typeof obj === 'string') {
		return false;
	}

	return obj instanceof Array || Array.isArray(obj) ||
		(obj.length >= 0 && (obj.splice instanceof Function ||
			(Object.getOwnPropertyDescriptor(obj, (obj.length - 1)) && obj.constructor.name !== 'String')));
};


/***/ }),

/***/ "./node_modules/warning/browser.js":
/*!*****************************************!*\
  !*** ./node_modules/warning/browser.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright 2014-2015, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 */



/**
 * Similar to invariant but only logs a warning if the condition is not met.
 * This can be used to log issues in development environments in critical
 * paths. Removing the logging code for production environments will keep the
 * same logic and follow the same code paths.
 */

var warning = function() {};

if (true) {
  warning = function(condition, format, args) {
    var len = arguments.length;
    args = new Array(len > 2 ? len - 2 : 0);
    for (var key = 2; key < len; key++) {
      args[key - 2] = arguments[key];
    }
    if (format === undefined) {
      throw new Error(
        '`warning(condition, format, ...args)` requires a warning ' +
        'message argument'
      );
    }

    if (format.length < 10 || (/^[s\W]*$/).test(format)) {
      throw new Error(
        'The warning format should be able to uniquely identify this ' +
        'warning. Please, use a more descriptive format than: ' + format
      );
    }

    if (!condition) {
      var argIndex = 0;
      var message = 'Warning: ' +
        format.replace(/%s/g, function() {
          return args[argIndex++];
        });
      if (typeof console !== 'undefined') {
        console.error(message);
      }
      try {
        // This error was thrown as a convenience so that you can use this stack
        // to find the callsite that caused this warning to fire.
        throw new Error(message);
      } catch(x) {}
    }
  };
}

module.exports = warning;


/***/ }),

/***/ "./node_modules/webpack/buildin/global.js":
/*!***********************************!*\
  !*** (webpack)/buildin/global.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || new Function("return this")();
} catch (e) {
	// This works if the window reference is available
	if (typeof window === "object") g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),

/***/ 4:
/*!******************************************************!*\
  !*** multi ./App/setPrefix.js ./App/inject/index.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(/*! ./App/setPrefix.js */"./App/setPrefix.js");
module.exports = __webpack_require__(/*! ./App/inject/index.js */"./App/inject/index.js");


/***/ })

/******/ });
//# sourceMappingURL=index.js.map